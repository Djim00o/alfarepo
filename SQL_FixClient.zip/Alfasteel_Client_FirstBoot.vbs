' First logon on CLIENT deploy: local user "alfasteel", display name "alfa steel".
' French and English: the Administrators group is resolved by SID S-1-5-32-544.
'
' The password is set through ADSI, never on a command line, so passwords
' containing & | < > ^ % or " are applied unchanged.
' This script never reboots: Alfasteel_Setup.cmd owns the reboot.

Option Explicit

Dim fso, sh, logPath, pwFile, pw, userName, displayName, ok, cachedAdminGroup

Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
userName = "alfasteel"
displayName = "alfa steel"
pwFile = "C:\alfasteel.client.pw"
logPath = ChooseLogPath()

LogLine "start"

pw = ReadPasswordFile(pwFile)
If pw = "" Then
  LogLine "ERROR: missing or empty " & pwFile
  WScript.Quit 1
End If
LogLine "password file length: " & Len(pw) & " character(s)"

RelaxClientPasswordPolicy

CreateLocalUser userName, displayName, pw
If Not EnforcePasswordViaNet(userName, pw) Then
  LogLine "ERROR: could not set alfasteel password via net user"
  WScript.Quit 1
End If
AddToAdminGroup userName
ok = VerifyUser(userName, displayName)
If ok Then RetireFormerLoginAccounts userName

If fso.FileExists("C:\SQL_WipeEmServers.vbs") Then
  LogLine "Running SQL_WipeEmServers.vbs ..."
  sh.Run "cscript //nologo //B C:\SQL_WipeEmServers.vbs", 0, True
Else
  LogLine "ERROR: missing C:\SQL_WipeEmServers.vbs"
  ok = False
End If

FlushNetworkCaches

On Error Resume Next
If fso.FileExists(pwFile) Then fso.DeleteFile pwFile, True
On Error GoTo 0

If ok Then
  LogLine "done"
  WScript.Quit 0
End If
LogLine "done with errors"
WScript.Quit 1


' --- SUBROUTINES ---

' Same file as Alfasteel_Setup.cmd so the operator has one log to read.
Function ChooseLogPath()
  Dim candidates, p, probe
  candidates = Array("C:\Alfasteel_Setup_log.txt", _
                     sh.ExpandEnvironmentStrings("%TEMP%") & "\Alfasteel_Setup_log.txt")
  For Each p In candidates
    On Error Resume Next
    Err.Clear
    Set probe = fso.OpenTextFile(p, 8, True)
    If Err.Number = 0 Then
      probe.Close
      On Error GoTo 0
      ChooseLogPath = p
      Exit Function
    End If
    On Error GoTo 0
  Next
  ChooseLogPath = ""
End Function

' Opened and closed per line: the setup console appends to the same file.
Sub LogLine(msg)
  Dim f
  On Error Resume Next
  If logPath = "" Then Exit Sub
  Set f = fso.OpenTextFile(logPath, 8, True)
  If Err.Number <> 0 Then Exit Sub
  f.WriteLine "[" & Time & "] Client_FirstBoot: " & msg
  f.Close
End Sub

Function ReadPasswordFile(path)
  Dim tf
  ReadPasswordFile = ""
  If Not fso.FileExists(path) Then Exit Function
  On Error Resume Next
  Set tf = fso.OpenTextFile(path, 1)
  If Err.Number <> 0 Then Exit Function
  ReadPasswordFile = Trim(tf.ReadAll)
  tf.Close
End Function

Sub CreateLocalUser(u, fullName, password)
  Dim comp, acct, computer
  On Error Resume Next
  computer = sh.ExpandEnvironmentStrings("%COMPUTERNAME%")

  Err.Clear
  Set acct = GetObject("WinNT://" & computer & "/" & u & ",user")
  If Err.Number = 0 Then
    Err.Clear
    acct.FullName = fullName
    acct.SetPassword password
    acct.UserFlags = acct.UserFlags Or 65536
    acct.AccountDisabled = False
    acct.SetInfo
    If Err.Number = 0 Then
      LogLine "existing user updated (ADSI): " & u & " (" & fullName & ")"
      Exit Sub
    End If
    LogLine "ADSI update failed: " & Err.Description
    CreateUserNet u, fullName, password
    Exit Sub
  End If

  Err.Clear
  Set comp = GetObject("WinNT://" & computer & ",computer")
  If Err.Number <> 0 Then
    Err.Clear
    Set comp = GetObject("WinNT://.")
  End If
  If Err.Number <> 0 Then
    LogLine "ADSI computer bind failed: " & Err.Description
    CreateUserNet u, fullName, password
    Exit Sub
  End If

  Err.Clear
  Set acct = comp.Create("user", u)
  acct.SetPassword password
  acct.FullName = fullName
  acct.UserFlags = 512 Or 65536
  acct.AccountDisabled = False
  acct.SetInfo
  If Err.Number <> 0 Then
    LogLine "ADSI create failed: " & Err.Description
    CreateUserNet u, fullName, password
    Exit Sub
  End If
  LogLine "user created: " & u & " (" & fullName & ")"
End Sub

' Fallback only. net.exe cannot carry every password character, so the display
' name is applied in a separate call that has no password on the command line.
Sub RelaxClientPasswordPolicy()
  Dim inf, db, rc, tf
  inf = sh.ExpandEnvironmentStrings("%TEMP%") & "\alfasteel_pwd_policy.inf"
  db = sh.ExpandEnvironmentStrings("%TEMP%") & "\alfasteel_pwd_policy.sdb"
  On Error Resume Next
  LogLine "relaxing local password policy for simple passwords ..."
  sh.Run "%ComSpec% /c net accounts /minpwlen:0", 0, True
  Set tf = fso.CreateTextFile(inf, True)
  tf.WriteLine "[Unicode]"
  tf.WriteLine "Unicode=yes"
  tf.WriteLine "[Version]"
  tf.WriteLine "signature=""$CHICAGO$"""
  tf.WriteLine "Revision=1"
  tf.WriteLine "[System Access]"
  tf.WriteLine "PasswordComplexity = 0"
  tf.WriteLine "MinimumPasswordLength = 0"
  tf.Close
  rc = sh.Run("%ComSpec% /c secedit /configure /db """ & db & """ /cfg """ & inf & """ /areas SECURITYPOLICY", 0, True)
  LogLine "secedit PasswordComplexity=0 rc=" & rc
  On Error GoTo 0
End Sub

Function EnforcePasswordViaNet(u, password)
  Dim rc
  EnforcePasswordViaNet = False
  rc = sh.Run("%ComSpec% /c net user """ & u & """ """ & password & """", 0, True)
  LogLine "enforce password via net user rc=" & rc
  If rc = 0 Then EnforcePasswordViaNet = True
End Function

Sub CreateUserNet(u, fullName, password)
  Dim rc
  On Error Resume Next
  LogLine "WARNING: using net user fallback - passwords with & | < > ^ % may fail; ADSI is preferred"
  rc = sh.Run("%ComSpec% /c net user """ & u & """ """ & password & """", 0, True)
  If rc <> 0 Then
    rc = sh.Run("%ComSpec% /c net user """ & u & """ """ & password & """ /add /expires:never", 0, True)
    LogLine "net user /add rc=" & rc
  Else
    LogLine "net user password set rc=" & rc
  End If
  sh.Run "%ComSpec% /c net user """ & u & """ /active:yes /fullname:""" & fullName & """", 0, True
End Sub

Sub AddToAdminGroup(u)
  Dim g, grpName, rc
  grpName = AdminGroupName()
  LogLine "Administrators group: " & grpName
  On Error Resume Next
  Set g = GetObject("WinNT://./" & grpName & ",group")
  If Err.Number = 0 Then
    Err.Clear
    g.Add "WinNT://./" & u & ",user"
    If Err.Number = 0 Or InStr(LCase(Err.Description), "already") > 0 Then
      LogLine "added to " & grpName & " via ADSI"
      Exit Sub
    End If
  End If
  rc = sh.Run("%ComSpec% /c net localgroup """ & grpName & """ """ & u & """ /add", 0, True)
  LogLine "net localgroup add rc=" & rc
End Sub

' SID S-1-5-32-544 is the same on every language: Administrateurs / Administrators.
' Resolved once: the lookup starts a PowerShell process and is called again by
' the verification pass.
Function AdminGroupName()
  Dim tmp, tf, n
  If cachedAdminGroup <> "" Then
    AdminGroupName = cachedAdminGroup
    Exit Function
  End If
  AdminGroupName = "Administrateurs"
  tmp = sh.ExpandEnvironmentStrings("%TEMP%") & "\alf_admgrp.txt"
  On Error Resume Next
  sh.Run "%ComSpec% /c powershell -NoProfile -Command " & _
         """([System.Security.Principal.SecurityIdentifier]'S-1-5-32-544').Translate([System.Security.Principal.NTAccount]).Value""" & _
         " > """ & tmp & """ 2>&1", 0, True
  If Not fso.FileExists(tmp) Then Exit Function
  Set tf = fso.OpenTextFile(tmp, 1)
  n = Trim(tf.ReadAll)
  tf.Close
  fso.DeleteFile tmp, True
  n = Trim(Replace(Replace(n, vbCr, ""), vbLf, ""))
  If InStr(n, "\") > 0 Then n = Mid(n, InStrRev(n, "\") + 1)
  If n <> "" And InStr(n, " ") = 0 Then AdminGroupName = n
  cachedAdminGroup = AdminGroupName
End Function

Function VerifyUser(u, fullName)
  Dim acct, members, m, inAdmins
  VerifyUser = False
  On Error Resume Next
  Err.Clear
  Set acct = GetObject("WinNT://./" & u & ",user")
  If Err.Number <> 0 Then
    LogLine "ERROR: user " & u & " does not exist after setup"
    Exit Function
  End If
  If Trim(acct.FullName) <> fullName Then
    LogLine "ERROR: display name is """ & acct.FullName & """, expected """ & fullName & """"
    Exit Function
  End If

  inAdmins = False
  Err.Clear
  Set members = GetObject("WinNT://./" & AdminGroupName() & ",group")
  If Err.Number = 0 Then
    For Each m In members.Members
      If LCase(m.Name) = LCase(u) Then inAdmins = True
    Next
  End If
  If Not inAdmins Then
    LogLine "ERROR: " & u & " is not a member of the administrators group"
    Exit Function
  End If

  LogLine "verified: user " & u & ", display name """ & fullName & """, administrator"
  VerifyUser = True
End Function

Sub RetireFormerLoginAccounts(keepUser)
  Dim listPath, tf, line, u
  listPath = "C:\alfasteel.retire.users"
  If fso.FileExists(listPath) Then
    Set tf = fso.OpenTextFile(listPath, 1)
    Do Until tf.AtEndOfStream
      line = Trim(tf.ReadLine)
      If line <> "" Then RetireOneUser line, keepUser
    Loop
    tf.Close
  Else
    RetireOneUser "pc-com", keepUser
  End If
End Sub

Sub RetireOneUser(u, keepUser)
  Dim rc, acct
  If LCase(Trim(u)) = LCase(keepUser) Then Exit Sub
  On Error Resume Next
  Err.Clear
  Set acct = GetObject("WinNT://./" & u & ",user")
  If Err.Number <> 0 Then
    LogLine "retire: user " & u & " not present (ok)"
    Exit Sub
  End If
  LogLine "retire: disabling " & u & " ..."
  rc = sh.Run("%ComSpec% /c net user """ & u & """ /active:no", 0, True)
  LogLine "retire: net user /active:no rc=" & rc
  LogLine "retire: deleting " & u & " (profile may remain until reboot) ..."
  rc = sh.Run("%ComSpec% /c net user """ & u & """ /delete", 0, True)
  If rc = 0 Then
    LogLine "retire: deleted " & u
  Else
    LogLine "retire: delete failed rc=" & rc & " - account left disabled"
  End If
End Sub

Sub FlushNetworkCaches()
  LogLine "flushing DNS / NetBIOS / ARP caches"
  sh.Run "%ComSpec% /c ipconfig /flushdns", 0, True
  sh.Run "%ComSpec% /c nbtstat -R", 0, True
  sh.Run "%ComSpec% /c nbtstat -RR", 0, True
  sh.Run "%ComSpec% /c arp -d *", 0, True
End Sub
