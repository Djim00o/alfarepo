@echo off
@echo off
:: The line above is duplicated on purpose: if this file is ever re-saved with a
:: UTF-8 BOM, cmd.exe swallows the first line and echo would stay on.
wpeinit

:: cmd /c so deploy.bat is the top-level script (CALL :label then works).
:: Prefer a volume that has both deploy.bat and the registered kit disk id.
for %%D in (E D F G H I J) do (
  if exist %%D:\deploy.bat if exist %%D:\alfasteel.kit.diskid (
    cmd /c %%D:\deploy.bat
    exit /b 0
  )
)

:: No kit id found: fall back to any volume that carries deploy.bat.
for %%D in (E D F G H I J) do (
  if exist %%D:\deploy.bat (
    echo [WARN] alfasteel.kit.diskid not found next to deploy.bat on %%D:.
    cmd /c %%D:\deploy.bat
    exit /b 0
  )
)

echo [ERR] deploy.bat not found on D: to J:. Run it manually, e.g. E:\deploy.bat
pause
exit /b 1
