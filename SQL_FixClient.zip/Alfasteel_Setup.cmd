@echo off
:: Winlogon shell entry (kit 3.1). Runs PowerShell setup; legacy batch is fallback only.
setlocal
cd /d C:\
set "FLAG=%~1"
if exist "C:\Alfasteel-Setup.ps1" if exist "C:\Alfasteel-Lib.ps1" (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Alfasteel-Setup.ps1" -ElevatedFlag "%FLAG%"
  if errorlevel 1 if exist "C:\Alfasteel-Setup-Legacy.cmd" (
    call "C:\Alfasteel-Setup-Legacy.cmd" %FLAG%
    exit /b %ERRORLEVEL%
  )
  exit /b %ERRORLEVEL%
)
if exist "C:\Alfasteel-Setup-Legacy.cmd" (
  call "C:\Alfasteel-Setup-Legacy.cmd" %FLAG%
  exit /b %ERRORLEVEL%
)
echo [ERR] Missing Alfasteel-Setup.ps1 and Alfasteel-Lib.ps1 on C:\ - refresh the Ventoy kit.
exit /b 1
