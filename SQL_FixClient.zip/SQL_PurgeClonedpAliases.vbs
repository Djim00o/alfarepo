' Remove SQL Client ConnectTo aliases and ODBC DSNs that reference CLONEDP.
' Works from 32-bit or 64-bit cscript/wscript (uses reg.exe /reg:32 and /reg:64).
' French and English Windows: reg.exe type names (REG_SZ) are not localized.

Option Explicit

Dim fso, sh, args, i, logPath, net, curUser, deletedCount, isWinPE, isWscript, dumpSeq

Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
Set net = CreateObject("WScript.Network")
curUser = net.UserName
deletedCount = 0
dumpSeq = 0
isWinPE = fso.FolderExists("X:\Windows")
isWscript = (InStr(LCase(WScript.FullName), "wscript") > 0)

logPath = ChooseLogPath()
LogLine "start computer=" & net.ComputerName & " user=" & curUser

Set args = WScript.Arguments
If args.Count = 0 Then
  PurgeConnectTo "HKLM\SOFTWARE\Microsoft\MSSQLServer\Client\ConnectTo", "/reg:64"
  PurgeConnectTo "HKLM\SOFTWARE\Microsoft\MSSQLServer\Client\ConnectTo", "/reg:32"
  PurgeConnectTo "HKCU\SOFTWARE\Microsoft\MSSQLServer\Client\ConnectTo", "/reg:64"
  PurgeConnectTo "HKCU\SOFTWARE\Microsoft\MSSQLServer\Client\ConnectTo", "/reg:32"
  PurgeOdbc "HKLM\SOFTWARE\ODBC", "/reg:64"
  PurgeOdbc "HKLM\SOFTWARE\ODBC", "/reg:32"
  PurgeOdbc "HKCU\SOFTWARE\ODBC", "/reg:64"
  PurgeOdbc "HKCU\SOFTWARE\ODBC", "/reg:32"
Else
  For i = 0 To args.Count - 1
    PurgeConnectTo args(i), ""
  Next
End If

If Not isWinPE Then
  PurgeClonedpInUserProfiles curUser
End If

LogLine "done deleted=" & deletedCount

If isWscript Then
  MsgBox "CLONEDP SQL aliases removed: " & deletedCount & vbCrLf & "Log: " & logPath, vbInformation, "Alfasteel"
End If
WScript.Quit 0

Function ChooseLogPath()
  Dim t, p
  If isWinPE Then
    ChooseLogPath = "X:\SQL_PurgeClonedp_log.txt"
    Exit Function
  End If
  ' Same file as Alfasteel_Setup.cmd so the operator has one log to read.
  p = "C:\Alfasteel_Setup_log.txt"
  If CanWrite(p) Then
    ChooseLogPath = p
    Exit Function
  End If
  t = sh.ExpandEnvironmentStrings("%TEMP%")
  ChooseLogPath = t & "\Alfasteel_Setup_log.txt"
End Function

Function CanWrite(path)
  Dim tf
  On Error Resume Next
  Err.Clear
  Set tf = fso.OpenTextFile(path, 8, True)
  If Err.Number = 0 Then
    tf.Close
    CanWrite = True
  Else
    CanWrite = False
  End If
End Function

' Opened and closed per line: Alfasteel_Setup.cmd appends to the same file, and
' a handle held open for the whole run would block it.
Sub LogLine(msg)
  Dim f
  On Error Resume Next
  If logPath = "" Then Exit Sub
  Set f = fso.OpenTextFile(logPath, 8, True)
  If Err.Number <> 0 Then Exit Sub
  f.WriteLine "[" & Time & "] PurgeClonedp: " & msg
  f.Close
  On Error GoTo 0
End Sub

Sub PurgeConnectTo(keyPath, regView)
  Dim cmd, line, name, uname, rc, tf, tmp
  If Trim(keyPath) = "" Then Exit Sub
  tmp = DumpRegQuery(keyPath, regView)
  If tmp = "" Then Exit Sub
  Set tf = fso.OpenTextFile(tmp, 1)
  Do While Not tf.AtEndOfStream
    line = Trim(tf.ReadLine)
    name = ValueNameFromRegLine(line)
    If name <> "" Then
      uname = UCase(Replace(name, " ", ""))
      If uname <> "DSQUERY" And InStr(uname, "CLONEDP") > 0 Then
        rc = DeleteRegValue(keyPath, name, regView)
        LogLine "Delete ConnectTo " & keyPath & " /v " & name & " view=" & regView & " rc=" & rc
        If rc = 0 Then deletedCount = deletedCount + 1
      End If
    End If
  Loop
  tf.Close
  On Error Resume Next
  fso.DeleteFile tmp, True
  On Error GoTo 0
End Sub

Function DumpRegQuery(keyPath, regView)
  Dim cmd, tmp, folder
  dumpSeq = dumpSeq + 1
  If isWinPE Then
    folder = "X:"
  Else
    folder = sh.ExpandEnvironmentStrings("%TEMP%")
  End If
  tmp = folder & "\alf_reg_" & dumpSeq & ".txt"
  cmd = "reg query """ & keyPath & """"
  If regView <> "" Then cmd = cmd & " " & regView
  sh.Run "%ComSpec% /c " & cmd & " > """ & tmp & """ 2>&1", 0, True
  If fso.FileExists(tmp) Then
    DumpRegQuery = tmp
  Else
    DumpRegQuery = ""
  End If
End Function

Function ValueNameFromRegLine(line)
  Dim p, raw
  ValueNameFromRegLine = ""
  p = InStr(1, line, "REG_SZ", vbTextCompare)
  If p = 0 Then p = InStr(1, line, "REG_EXPAND_SZ", vbTextCompare)
  If p = 0 Then Exit Function
  raw = Trim(Left(line, p - 1))
  If raw = "" Then Exit Function
  If Left(UCase(raw), 5) = "HKEY_" Then Exit Function
  ValueNameFromRegLine = raw
End Function

Function DeleteRegValue(keyPath, valueName, regView)
  Dim cmd, rc
  cmd = "reg delete """ & keyPath & """ /v """ & valueName & """ /f"
  If regView <> "" Then cmd = cmd & " " & regView
  rc = sh.Run(cmd, 0, True)
  DeleteRegValue = rc
End Function

Sub PurgeOdbc(odbcRoot, regView)
  Dim sourcesKey
  sourcesKey = odbcRoot & "\ODBC.INI\ODBC Data Sources"
  PurgeConnectTo sourcesKey, regView
  DeleteClonedpSubkeys odbcRoot & "\ODBC.INI", regView
End Sub

Sub DeleteClonedpSubkeys(iniKey, regView)
  Dim line, k, uname, rc, tf, tmp
  tmp = DumpRegQuery(iniKey, regView)
  If tmp = "" Then Exit Sub
  Set tf = fso.OpenTextFile(tmp, 1)
  Do While Not tf.AtEndOfStream
    line = Trim(tf.ReadLine)
    If InStr(1, line, "HKEY_", vbTextCompare) = 1 Then
      k = line
      uname = UCase(k)
      If InStr(uname, "CLONEDP") > 0 Then
        rc = sh.Run("reg delete """ & k & """ /f " & regView, 0, True)
        LogLine "Delete ODBC key " & k & " rc=" & rc
        If rc = 0 Then deletedCount = deletedCount + 1
      End If
    End If
  Loop
  tf.Close
  On Error Resume Next
  fso.DeleteFile tmp, True
  On Error GoTo 0
End Sub

Sub PurgeClonedpInUserProfiles(skipUserName)
  Dim usersDir, folder, hivePath, hiveName, skip
  usersDir = "C:\Users"
  If Not fso.FolderExists(usersDir) Then Exit Sub
  For Each folder In fso.GetFolder(usersDir).SubFolders
    skip = SkipProfileName(folder.Name, skipUserName)
    If Not skip Then
      hivePath = folder.Path & "\NTUSER.DAT"
      If fso.FileExists(hivePath) Then
        hiveName = SafeHiveName(folder.Name)
        If sh.Run("reg load ""HKU\" & hiveName & """ """ & hivePath & """", 0, True) = 0 Then
          PurgeConnectTo "HKU\" & hiveName & "\Software\Microsoft\MSSQLServer\Client\ConnectTo", ""
          PurgeConnectTo "HKU\" & hiveName & "\Software\Wow6432Node\Microsoft\MSSQLServer\Client\ConnectTo", ""
          PurgeOdbc "HKU\" & hiveName & "\Software\ODBC", ""
          PurgeOdbc "HKU\" & hiveName & "\Software\Wow6432Node\ODBC", ""
          sh.Run "reg unload ""HKU\" & hiveName & """", 0, True
        Else
          LogLine "Skip locked hive: " & folder.Name
        End If
      End If
    End If
  Next
End Sub

Function SkipProfileName(name, skipUserName)
  Dim u
  u = UCase(Trim(name))
  SkipProfileName = True
  If u = "PUBLIC" Then Exit Function
  If u = "DEFAULT" Then Exit Function
  If u = "DEFAULT USER" Then Exit Function
  If u = "ALL USERS" Then Exit Function
  If u = UCase(Trim(skipUserName)) Then Exit Function
  SkipProfileName = False
End Function

Function SafeHiveName(name)
  Dim s, ch, i, c
  s = "AlfP"
  For i = 1 To Len(name)
    ch = Mid(name, i, 1)
    c = Asc(ch)
    If (c >= 48 And c <= 57) Or (c >= 65 And c <= 90) Or (c >= 97 And c <= 122) Then
      s = s & ch
    End If
  Next
  If s = "AlfP" Then s = "AlfPUser"
  SafeHiveName = Left(s, 30)
End Function
