@echo off
@echo off
:: The line above is duplicated on purpose: if this file is ever re-saved with a
:: UTF-8 BOM, cmd.exe swallows the first line and echo would stay on.
setlocal
:: Run as Administrator - Deployment and Imaging Tools Environment.
set "VENTOY=E:"
set "ISO_NAME=Alfasteel-WinPE.iso"
set "MOUNT=C:\WinPE_mount"
set "WIM=C:\WinPE_amd64\media\sources\boot.wim"
set "OUT=C:\Alfasteel-WinPE.iso"
set "HERE=%~dp0"

if not exist "%WIM%" (
  echo [ERR] Missing %WIM% - run: copype amd64 C:\WinPE_amd64
  pause
  exit /b 1
)
if not exist "%MOUNT%" mkdir "%MOUNT%"

dism /Cleanup-Mountpoints >nul 2>&1
dism /Get-MountedImageInfo | findstr /i /c:"%MOUNT%" >nul
if errorlevel 1 (
  dism /Mount-Image /ImageFile:"%WIM%" /Index:1 /MountDir:"%MOUNT%"
  if errorlevel 1 pause & exit /b 1
)

copy /y C:\Windows\System32\findstr.exe "%MOUNT%\Windows\System32\" >nul

if exist "%HERE%startnet.cmd" (
  copy /y "%HERE%startnet.cmd" "%MOUNT%\Windows\System32\startnet.cmd"
) else (
  echo [ERR] Put startnet.cmd next to this script.
  pause
  exit /b 1
)

type "%MOUNT%\Windows\System32\startnet.cmd"
echo.
cd /d C:\
dism /Unmount-Image /MountDir:"%MOUNT%" /Commit
if errorlevel 1 (
  echo [ERR] Commit failed - close Explorer on %MOUNT%
  pause
  exit /b 1
)

MakeWinPEMedia /ISO C:\WinPE_amd64 "%OUT%"
if exist "%VENTOY%\" copy /y "%OUT%" "%VENTOY%\%ISO_NAME%"
echo Done.
pause
