@echo off
@echo off
:: The line above is duplicated on purpose: if this file is ever re-saved with a
:: UTF-8 BOM, cmd.exe swallows the first line and echo would stay on.
setlocal enabledelayedexpansion
color 1F
cls

:: ---------------------------------------------------------------------------
:: Alfasteel WinPE deployment - run ONLY from Ventoy USB (e.g. E:\deploy.bat)
:: Auto-selects the single internal disk; never wipes the registered kit SSD.
:: ---------------------------------------------------------------------------

:START
echo ======================================================
echo           ALFASTEEL SYSTEM DEPLOYMENT MENU
echo           Alfasteel kit 3.1.2  (Deploy-WinPE.bat)
echo ======================================================
echo.
echo   [1] Restore SERVER Image
echo   [2] Restore CLIENT (Server.wim, no local SQL)
echo   [3] Exit to Command Prompt
echo.
echo ======================================================
set "choice="
set /p choice="Select an option (1, 2, or 3): "

if "%choice%"=="1" (
  set "WIM_FILE=Server.wim"
  set "DEPLOY_MODE=SERVER"
  goto GET_NAME
)
if "%choice%"=="2" (
  set "WIM_FILE=Server.wim"
  set "DEPLOY_MODE=CLIENT"
  goto GET_NAME
)
if "%choice%"=="3" goto EXIT_PROMPT
goto INVALID

:GET_NAME
echo.
set "NEW_PC_NAME="
set /p NEW_PC_NAME="Enter the new Computer Name for this target: "
if not defined NEW_PC_NAME (
  echo [WARN] Computer name is required.
  pause
  goto START
)
for /f "tokens=* delims= " %%A in ("%NEW_PC_NAME%") do set "NEW_PC_NAME=%%A"
echo(%NEW_PC_NAME%| findstr /r /i "^[A-Z0-9][A-Z0-9-]*$" >nul
if errorlevel 1 (
  echo [WARN] Use letters, numbers, and hyphen only ^(no spaces^).
  pause
  goto START
)
if /i "%DEPLOY_MODE%"=="CLIENT" (
  if /i not "!NEW_PC_NAME:~-3!"=="-cl" set "NEW_PC_NAME=!NEW_PC_NAME!-cl"
  set "CLIENT_USER_PASSWORD="
  echo   This password is for the local account alfasteel only ^(not pc-com^).
  set /p CLIENT_USER_PASSWORD="Password for alfasteel login (display name alfa steel): "
  if not defined CLIENT_USER_PASSWORD (
    echo [WARN] Password is required for client deploy.
    pause
    goto START
  )
)
set "NEW_PC_REEL=!NEW_PC_NAME!^%\REEL"
if not "!NEW_PC_NAME!"=="" if not "!NEW_PC_NAME:~15!"=="" (
  echo [WARN] NetBIOS name must be 15 characters or less ^(checked after any -cl suffix^).
  pause
  goto START
)

:: Name that Desktop\oasys\prefs.ini must point at. A server serves itself; a
:: client points at the SQL server PC on the network.
set "SQL_SERVER_NAME=%NEW_PC_NAME%"
if /i "%DEPLOY_MODE%"=="CLIENT" (
  echo.
  echo   Which SQL server does this client use? Enter the server PC name only,
  echo   without \REEL. Leave blank to keep prefs.ini exactly as it is.
  set "SQL_SERVER_NAME="
  set /p SQL_SERVER_NAME="SQL server name for this client: "
)
if defined SQL_SERVER_NAME (
  for /f "tokens=* delims= " %%A in ("!SQL_SERVER_NAME!") do set "SQL_SERVER_NAME=%%A"
  echo(!SQL_SERVER_NAME!| findstr /r /i "^[A-Z0-9][A-Z0-9-]*$" >nul
  if errorlevel 1 (
    echo [WARN] Server name: letters, numbers and hyphen only, and no \REEL suffix.
    pause
    goto START
  )
)

echo.
echo [*] Deploy mode: %DEPLOY_MODE%
echo [*] Target Name: %NEW_PC_NAME%
echo [*] Target Image: %WIM_FILE%
if defined SQL_SERVER_NAME (
  echo [*] prefs.ini server:       !SQL_SERVER_NAME!
) else (
  echo [*] prefs.ini server:       unchanged
)

call :REQUIRE_WINPE
if errorlevel 1 goto FAIL_EXIT

call :RESOLVE_DEPLOY_DRIVE
if errorlevel 1 goto FAIL_EXIT

echo.
set "DO_CLEAN_DESKTOP=1"
set "DO_COPY_OASYS=1"
if not exist "%DEPLOY_VOL%oasys\" (
  echo [WARN] %DEPLOY_VOL%oasys\ not found - oasys copy will be skipped.
  set "DO_COPY_OASYS=0"
)

call :RESOLVE_PROTECTED_USB_DISK
if errorlevel 1 goto FAIL_EXIT

call :LOAD_AND_VERIFY_KIT_DISK_ID
if errorlevel 1 goto FAIL_EXIT

call :RESOLVE_TARGET_DISK
if errorlevel 1 goto FAIL_EXIT

call :ASSERT_TARGET_NOT_KIT_DISK
if errorlevel 1 goto FAIL_EXIT

if not exist "%DEPLOY_VOL%%WIM_FILE%" (
  echo [ERR] %WIM_FILE% not found on %DEPLOY_VOL%
  goto FAIL_EXIT
)

call :PREFLIGHT_KIT_FILES
if errorlevel 1 goto FAIL_EXIT

call :VALIDATE_DEPLOY_NAMES
if errorlevel 1 goto FAIL_EXIT

call :PICK_TARGET_LETTERS

echo.
echo ======================================================
echo                 PRE-WIPE SUMMARY
echo ======================================================
if /i "%DEPLOY_MODE%"=="SERVER" (
  echo # # # # # # # # # # # # # # # # # # # # # # # # # # # #
  echo   DEPLOY MODE:  SERVER  ^(menu option 1^)
  echo   Local SQL Server stays ON. First boot = 8 steps.
  echo # # # # # # # # # # # # # # # # # # # # # # # # # # # #
) else (
  echo # # # # # # # # # # # # # # # # # # # # # # # # # # # #
  echo   DEPLOY MODE:  CLIENT  ^(menu option 2^)
  echo   Local SQL services OFF. First boot = 6 steps.
  echo # # # # # # # # # # # # # # # # # # # # # # # # # # # #
)
echo.
echo [*] Image kit:              %DEPLOY_VOL%%WIM_FILE%
echo [*] Protected USB disk #:   %USB_DISK%
echo [*] Protected GPT disk ID:  %KIT_DISK_ID%
echo [*] Deploy mode:            %DEPLOY_MODE%
echo [*] Target PC name:         %NEW_PC_NAME%
echo [*] Target install disk #:  %TARGET_DISK%
echo [*] EFI letter:             %EFI_LTR%:
echo [*] Windows letter:         %WIN_LTR%:
echo [*] Clean desktop:          %DO_CLEAN_DESKTOP%
echo [*] Copy oasys to desktop:  %DO_COPY_OASYS%
echo.
echo --- Target disk details ---
call :SHOW_DISK_DETAIL %TARGET_DISK%
echo.
echo [WARN] Disk %TARGET_DISK% will be COMPLETELY ERASED.
echo     Disk %USB_DISK% (Ventoy kit) will NOT be touched.
echo ======================================================
echo.
set "CONFIRM_MODE="
set /p CONFIRM_MODE="Type %DEPLOY_MODE% to confirm this mode, or anything else to abort: "
if /i not "%CONFIRM_MODE%"=="%DEPLOY_MODE%" (
  echo [*] Aborted. Mode was not confirmed. No disks were changed.
  goto FAIL_EXIT
)
set "CONFIRM_WIPE="
set /p CONFIRM_WIPE="Type WIPE to erase disk %TARGET_DISK%, or anything else to abort: "
if /i not "%CONFIRM_WIPE%"=="WIPE" (
  echo [*] Aborted. No disks were changed.
  goto FAIL_EXIT
)

echo [*] Partitioning Disk %TARGET_DISK% (UEFI/GPT)...
if "%TARGET_DISK%"=="%USB_DISK%" (
  echo [FATAL] Target equals protected USB disk. Aborting.
  goto FAIL_EXIT
)
call :GET_DISK_GPT_ID %TARGET_DISK%
if defined DISK_GPT_ID if /i "%DISK_GPT_ID%"=="%KIT_DISK_ID%" (
  echo [FATAL] Target disk ID matches kit SSD. Aborting.
  goto FAIL_EXIT
)

(
echo select disk %TARGET_DISK%
echo clean
echo convert gpt
echo create partition efi size=300
echo format quick fs=fat32 label="System"
echo assign letter=%EFI_LTR%
echo create partition msr size=128
echo create partition primary
echo format quick fs=ntfs label="Windows"
echo assign letter=%WIN_LTR%
echo exit
) > X:\diskpart_setup.txt

diskpart /s X:\diskpart_setup.txt
if errorlevel 1 (
  echo [ERR] Disk partitioning failed
  goto FAIL_EXIT
)
if not exist "%WIN_LTR%:\" (
  echo [ERR] Windows partition letter %WIN_LTR%: was not assigned.
  echo     USB is %VOL% - pick a machine where S: and W: are free, or this is a diskpart failure.
  goto FAIL_EXIT
)

echo [*] Applying %WIM_FILE% to %WIN_LTR%:\ ...
dism /Apply-Image /ImageFile:"%DEPLOY_VOL%%WIM_FILE%" /Index:1 /ApplyDir:%WIN_LTR%:\
if errorlevel 1 (
  echo [ERR] DISM Image Apply failed
  goto FAIL_EXIT
)
if not exist "%WIN_LTR%:\Windows\System32\config\SYSTEM" (
  echo [ERR] DISM finished but %WIN_LTR%:\Windows is missing. Image may be corrupt.
  goto FAIL_EXIT
)

echo [*] Resetting offline re-image counters (unlimited DISM restores)...
call :RESET_OFFLINE_REIMAGE_COUNTERS

echo [*] Creating UEFI boot entries...
%WIN_LTR%:\Windows\System32\bcdboot %WIN_LTR%:\Windows /s %EFI_LTR%: /f UEFI /l fr-FR
if errorlevel 1 (
  %WIN_LTR%:\Windows\System32\bcdboot %WIN_LTR%:\Windows /s %EFI_LTR%: /f UEFI
)
if errorlevel 1 (
  echo [ERR] BCDBoot failed to write boot files
  goto FAIL_EXIT
)

:: After bcdboot, so the entry to keep ({bootmgr}) already exists and every
:: other bootmgfw.efi entry in NVRAM is a leftover from an earlier deploy.
echo [*] Removing duplicate UEFI boot entries from firmware NVRAM...
if exist "%DEPLOY_VOL%Clean-UefiDuplicates.cmd" (
  call "%DEPLOY_VOL%Clean-UefiDuplicates.cmd"
) else (
  echo [WARN] Clean-UefiDuplicates.cmd is missing from the USB - F12 duplicates will remain.
)

echo [*] Injecting Windows Registry Hostname: %NEW_PC_NAME%...
reg load HKLM\OfflineSys %WIN_LTR%:\Windows\System32\config\SYSTEM
if errorlevel 1 (
  echo [ERR] Could not load offline SYSTEM hive. Aborting before registry writes.
  goto FAIL_EXIT
)
for %%C in (ControlSet001 ControlSet002) do (
  reg query "HKLM\OfflineSys\%%C" >nul 2>&1
  if not errorlevel 1 (
    reg add "HKLM\OfflineSys\%%C\Control\ComputerName\ComputerName" /v ComputerName /t REG_SZ /d "%NEW_PC_NAME%" /f
    reg add "HKLM\OfflineSys\%%C\Control\ComputerName\ActiveComputerName" /v ComputerName /t REG_SZ /d "%NEW_PC_NAME%" /f
    reg add "HKLM\OfflineSys\%%C\Services\Tcpip\Parameters" /v Hostname /t REG_SZ /d "%NEW_PC_NAME%" /f
    reg add "HKLM\OfflineSys\%%C\Services\Tcpip\Parameters" /v "NV Hostname" /t REG_SZ /d "%NEW_PC_NAME%" /f
  )
)

echo [*] Forcing DHCP on all offline network interfaces...
for %%C in (ControlSet001 ControlSet002) do (
  for /f "tokens=*" %%k in ('reg query HKLM\OfflineSys\%%C\Services\Tcpip\Parameters\Interfaces 2^>nul ^| findstr /c:"{"') do (
    reg add "%%k" /v EnableDHCP /t REG_DWORD /d 1 /f >nul 2>&1
  )
)
reg unload HKLM\OfflineSys

if "%DO_CLEAN_DESKTOP%"=="1" (
  echo [*] Cleaning offline desktops ^(keep default shell icons^)...
  call :CLEAN_OFFLINE_DESKTOPS
)
if "%DO_COPY_OASYS%"=="1" (
  echo [*] Copying oasys to Public desktop...
  call :COPY_OASYS_TO_DESKTOP
)
echo [*] Snapshotting oasys .ini files while they are still pristine...
call :BACKUP_OASYS_INI

if exist "%DEPLOY_VOL%SQL_PurgeClonedpAliases.vbs" copy /y "%DEPLOY_VOL%SQL_PurgeClonedpAliases.vbs" %WIN_LTR%:\SQL_PurgeClonedpAliases.vbs >nul

echo [*] Stripping CLONEDP SQL client aliases from offline registry...
call :PURGE_SQL_CLONEDP_OFFLINE

if /i "%DEPLOY_MODE%"=="SERVER" (
  echo [*] Preparing SERVER SQL first-boot...
  call :COPY_SERVER_SQL_KIT
  if errorlevel 1 goto FAIL_EXIT
  call :WIPE_EM_OFFLINE_ALL_PROFILES
  call :REGISTER_EM_OFFLINE_ALL_PROFILES
) else (
  echo [*] Preparing CLIENT workstation ^(no local SQL services^)...
  call :DISABLE_SQL_SERVICES_OFFLINE
  call :WIPE_EM_OFFLINE_ALL_PROFILES
  call :WRITE_CLIENT_FIRSTBOOT
  if errorlevel 1 goto FAIL_EXIT
  if exist "%DEPLOY_VOL%SQL_WipeEmServers.vbs" copy /y "%DEPLOY_VOL%SQL_WipeEmServers.vbs" "%WIN_LTR%:\SQL_WipeEmServers.vbs" >nul
  if exist "%DEPLOY_VOL%Alfasteel_Client_FirstBoot.vbs" (
    copy /y "%DEPLOY_VOL%Alfasteel_Client_FirstBoot.vbs" "%WIN_LTR%:\alfclientfb.vbs" >nul
    copy /y "%DEPLOY_VOL%Alfasteel_Client_FirstBoot.vbs" "%WIN_LTR%:\Alfasteel_Client_FirstBoot.vbs" >nul
  )
  if not exist "%WIN_LTR%:\alfclientfb.vbs" (
    echo [ERR] Alfasteel_Client_FirstBoot.vbs was not copied. Put it next to deploy.bat.
    goto FAIL_EXIT
  )
)

echo [*] Installing first-boot setup ^(desktop stays hidden until it finishes^)...
call :INSTALL_FIRSTBOOT_SHELL
if errorlevel 1 goto FAIL_EXIT

echo.
echo ======================================================
echo [*] Deployment Complete
echo [*] You may remove the Ventoy SSD after this PC shuts down.
echo ======================================================
call :COUNTDOWN_REBOOT 15
goto :EOF

:COUNTDOWN_REBOOT
set "CD_SEC=%~1"
if not defined CD_SEC set "CD_SEC=15"
echo.
echo [*] Rebooting in %CD_SEC% seconds ^(remove USB when the PC shuts down^) ...
:CD_LOOP
echo     %CD_SEC% ...
ping -n 2 127.0.0.1 >nul
set /a CD_SEC-=1
if %CD_SEC% gtr 0 goto CD_LOOP
wpeutil reboot
exit /b 0

:: ---------------------------------------------------------------------------
:REQUIRE_WINPE
if exist "%SystemRoot%\System32\wpeutil.exe" exit /b 0
if exist "X:\Windows\System32\wpeutil.exe" exit /b 0
echo.
echo [ERR] deploy.bat must run from Windows PE, not from full Windows.
echo     Boot Alfasteel-WinPE.iso from Ventoy, then use the menu
echo     ^(or run E:\deploy.bat from the WinPE command prompt^).
echo     Nothing was wiped.
echo.
exit /b 1

:: ---------------------------------------------------------------------------
:RESOLVE_DEPLOY_DRIVE
set "DEPLOY_VOL=%~d0"
if not defined DEPLOY_VOL (
  echo [ERR] Could not determine script drive.
  exit /b 1
)
if /i "%DEPLOY_VOL%"=="X:" (
  echo [ERR] Run deploy.bat from the Ventoy USB, not from WinPE X:
  echo     Example: E:\deploy.bat
  exit /b 1
)
if not "%DEPLOY_VOL:~-1%"=="\" set "DEPLOY_VOL=%DEPLOY_VOL%\"
set "HAS_WIM=0"
if exist "%DEPLOY_VOL%Server.wim" set "HAS_WIM=1"
if "%HAS_WIM%"=="0" (
  echo [ERR] Server.wim not found on %DEPLOY_VOL%
  echo     Server and Client restore both apply Server.wim from the Ventoy data partition.
  exit /b 1
)
exit /b 0

:: ---------------------------------------------------------------------------
:RESOLVE_PROTECTED_USB_DISK
set "USB_DISK="
set "VOL=%DEPLOY_VOL:~0,2%"
(
echo select volume %VOL%
echo detail volume
echo exit
) > X:\deploy_usb_probe.txt
diskpart /s X:\deploy_usb_probe.txt > X:\deploy_usb_detail.txt 2>&1
if errorlevel 1 (
  echo [ERR] diskpart could not identify the USB volume %VOL%.
  type X:\deploy_usb_detail.txt
  exit /b 1
)
call :DISKPART_FILE_TO_ANSI X:\deploy_usb_detail.txt X:\deploy_usb_detail_ansi.txt
call :FIRST_DISK_NUMBER_IN_FILE X:\deploy_usb_detail_ansi.txt
set "USB_DISK=%FOUND_DISK%"
if not defined USB_DISK (
  echo [ERR] Could not read disk number for deploy USB volume %VOL%.
  type X:\deploy_usb_detail.txt
  exit /b 1
)

call :GET_DISK_GPT_ID %USB_DISK%
set "USB_DISK_GPT_ID=%DISK_GPT_ID%"
if not defined USB_DISK_GPT_ID (
  echo [ERR] Could not read disk ID for protected disk %USB_DISK%.
  type X:\disk_gpt_detail_out.txt
  exit /b 1
)
exit /b 0

:: ---------------------------------------------------------------------------
:: DiskPart marks the selected item with * (e.g. "* Disk 1"). Never use
:: "call :sub %%L" unquoted or "for %%T in (%%L)" - cmd expands * as a wildcard.
:: Tokenise each line with FOR /F "tokens=... delims= " (no CALL inside that loop).
:: diskpart redirected to a file is often UTF-16; findstr and some FOR /F reads miss it.
:: TYPE/MORE produce an ANSI copy cmd can parse reliably.
:DISKPART_FILE_TO_ANSI
set "DP_SRC=%~1"
set "DP_DST=%~2"
:: Never keep a UTF-16 copy: findstr can match it while FOR /F still fails on "Disk 0" lines.
type "%DP_SRC%" > "%DP_DST%" 2>nul
findstr /i /c:"Disk" /c:"Disque" "%DP_DST%" >nul 2>&1
if not errorlevel 1 exit /b 0
more < "%DP_SRC%" > "%DP_DST%" 2>nul
exit /b 0

:: %1 = disk number, %2 = ANSI list disk output from DiskPart
:DISK_LIST_HAS_NUMBER
set "WANT=%~1"
for /f "usebackq tokens=1,2,3,4,5,6,7 delims= " %%a in ("%~2") do (
  if /i "%%a"=="Disk" (
    echo %%b| findstr /r "^%WANT%$" >nul
    if not errorlevel 1 exit /b 0
  )
  if /i "%%a"=="Disque" (
    echo %%b| findstr /r "^%WANT%$" >nul
    if not errorlevel 1 exit /b 0
  )
  if /i "%%a"=="*" if /i "%%b"=="Disk" if "%%c"=="%WANT%" exit /b 0
  if /i "%%a"=="*" if /i "%%b"=="Disque" if "%%c"=="%WANT%" exit /b 0
  if /i "%%b"=="Disk" if "%%c"=="%WANT%" exit /b 0
  if /i "%%c"=="Disk" if "%%d"=="%WANT%" exit /b 0
  if /i "%%b"=="Disque" if "%%c"=="%WANT%" exit /b 0
  if /i "%%c"=="Disque" if "%%d"=="%WANT%" exit /b 0
)
exit /b 1

:FIRST_DISK_NUMBER_IN_FILE
set "FOUND_DISK="
for /f "usebackq tokens=1,2,3,4,5,6,7 delims= " %%a in ("%~1") do (
  if defined FOUND_DISK goto :FIRST_DISK_DONE
  if /i "%%a"=="*" if /i "%%b"=="Disk" (
    echo %%c| findstr /r "^[0-9][0-9]*$" >nul
    if not errorlevel 1 set "FOUND_DISK=%%c"
  )
  if not defined FOUND_DISK if /i "%%a"=="*" if /i "%%b"=="Disque" (
    echo %%c| findstr /r "^[0-9][0-9]*$" >nul
    if not errorlevel 1 set "FOUND_DISK=%%c"
  )
  if not defined FOUND_DISK if /i "%%a"=="Disk" (
    echo %%b| findstr /r "^[0-9][0-9]*$" >nul
    if not errorlevel 1 set "FOUND_DISK=%%b"
  )
  if not defined FOUND_DISK if /i "%%a"=="Disque" (
    echo %%b| findstr /r "^[0-9][0-9]*$" >nul
    if not errorlevel 1 set "FOUND_DISK=%%b"
  )
  if not defined FOUND_DISK if /i "%%b"=="Disk" (
    echo %%c| findstr /r "^[0-9][0-9]*$" >nul
    if not errorlevel 1 set "FOUND_DISK=%%c"
  )
  if not defined FOUND_DISK if /i "%%c"=="Disk" (
    echo %%d| findstr /r "^[0-9][0-9]*$" >nul
    if not errorlevel 1 set "FOUND_DISK=%%d"
  )
  if not defined FOUND_DISK if /i "%%b"=="Disque" (
    echo %%c| findstr /r "^[0-9][0-9]*$" >nul
    if not errorlevel 1 set "FOUND_DISK=%%c"
  )
  if not defined FOUND_DISK if /i "%%c"=="Disque" (
    echo %%d| findstr /r "^[0-9][0-9]*$" >nul
    if not errorlevel 1 set "FOUND_DISK=%%d"
  )
)
:FIRST_DISK_DONE
exit /b 0

:: ---------------------------------------------------------------------------
:LOAD_AND_VERIFY_KIT_DISK_ID
set "KIT_DISK_ID="
if not exist "%DEPLOY_VOL%alfasteel.kit.diskid" (
  echo [ERR] Missing %DEPLOY_VOL%alfasteel.kit.diskid
  echo     On the Ventoy SSD run write-kit-diskid.bat once ^(same folder as deploy.bat^).
  exit /b 1
)
set /p KIT_DISK_ID=<"%DEPLOY_VOL%alfasteel.kit.diskid"
for /f "tokens=* delims= " %%A in ("%KIT_DISK_ID%") do set "KIT_DISK_ID=%%A"
if not defined KIT_DISK_ID (
  echo [ERR] alfasteel.kit.diskid is empty.
  exit /b 1
)
if /i not "%USB_DISK_GPT_ID%"=="%KIT_DISK_ID%" (
  echo [ERR] This USB is not the registered Alfasteel kit SSD.
  echo     File ID: %KIT_DISK_ID%
  echo     This USB disk ID: %USB_DISK_GPT_ID%
  echo     Run write-kit-diskid.bat only on the master Ventoy stick, or fix the file.
  exit /b 1
)
exit /b 0

:: ---------------------------------------------------------------------------
:ASSERT_TARGET_NOT_KIT_DISK
call :GET_DISK_GPT_ID %TARGET_DISK%
if defined DISK_GPT_ID if /i "%DISK_GPT_ID%"=="%KIT_DISK_ID%" (
  echo [FATAL] Target disk has the same GPT ID as the kit SSD. Refusing to wipe.
  exit /b 1
)
exit /b 0

:: ---------------------------------------------------------------------------
:GET_DISK_GPT_ID
set "DISK_GPT_ID="
(
echo select disk %~1
echo detail disk
echo exit
) > X:\disk_gpt_detail.txt
diskpart /s X:\disk_gpt_detail.txt > X:\disk_gpt_detail_out.txt 2>&1
call :DISKPART_FILE_TO_ANSI X:\disk_gpt_detail_out.txt X:\disk_gpt_detail_ansi.txt
findstr /i /c:"not valid" /c:"n'est pas valide" /c:"not a valid" X:\disk_gpt_detail_ansi.txt >nul
if not errorlevel 1 exit /b 1
call :PARSE_GPT_GUID X:\disk_gpt_detail_ansi.txt
exit /b 0

:: ---------------------------------------------------------------------------
:PARSE_GPT_GUID
set "DISK_GPT_ID="
for /f "usebackq delims=" %%L in ("%~1") do (
  if not defined DISK_GPT_ID for /f "tokens=1,2,3,4,5,6,7,8 delims= " %%a in ("%%L") do (
    if not defined DISK_GPT_ID if "%%a:~0,1!"=="{" set "DISK_GPT_ID=%%a"
    if not defined DISK_GPT_ID if "%%b:~0,1!"=="{" set "DISK_GPT_ID=%%b"
    if not defined DISK_GPT_ID if "%%c:~0,1!"=="{" set "DISK_GPT_ID=%%c"
    if not defined DISK_GPT_ID if "%%d:~0,1!"=="{" set "DISK_GPT_ID=%%d"
    if not defined DISK_GPT_ID if "%%e:~0,1!"=="{" set "DISK_GPT_ID=%%e"
    if not defined DISK_GPT_ID if "%%f:~0,1!"=="{" set "DISK_GPT_ID=%%f"
    if not defined DISK_GPT_ID if "%%g:~0,1!"=="{" set "DISK_GPT_ID=%%g"
    if not defined DISK_GPT_ID if "%%h:~0,1!"=="{" set "DISK_GPT_ID=%%h"
  )
)
if not defined DISK_GPT_ID (
  for /f "usebackq delims=" %%L in ("%~1") do (
    if not defined DISK_GPT_ID for /f "tokens=1,2,3,4,5,6,7,8 delims= " %%a in ("%%L") do (
      if not defined DISK_GPT_ID (
        echo %%a| findstr /r /i "^[0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F]$" >nul
        if not errorlevel 1 set "DISK_GPT_ID=%%a"
      )
      if not defined DISK_GPT_ID (
        echo %%b| findstr /r /i "^[0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F]$" >nul
        if not errorlevel 1 set "DISK_GPT_ID=%%b"
      )
      if not defined DISK_GPT_ID (
        echo %%c| findstr /r /i "^[0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F]$" >nul
        if not errorlevel 1 set "DISK_GPT_ID=%%c"
      )
      if not defined DISK_GPT_ID (
        echo %%d| findstr /r /i "^[0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F]$" >nul
        if not errorlevel 1 set "DISK_GPT_ID=%%d"
      )
    )
  )
)
exit /b 0

:: ---------------------------------------------------------------------------
:SHOW_DISK_DETAIL
(
echo select disk %~1
echo detail disk
echo exit
) > X:\show_disk.txt
diskpart /s X:\show_disk.txt
exit /b 0

:: ---------------------------------------------------------------------------
:RESOLVE_TARGET_DISK
set "TARGET_DISK="
set "OTHER_COUNT=0"

(
echo list disk
echo exit
) > X:\list_disk.txt
diskpart /s X:\list_disk.txt > X:\list_disk_out.txt
call :DISKPART_FILE_TO_ANSI X:\list_disk_out.txt X:\list_disk_ansi.txt
echo.
echo ======================================================
echo                 DISKS ON THIS PC
echo ======================================================
type X:\list_disk_out.txt
echo ======================================================
echo [WARN] DO NOT WIPE Disk %USB_DISK% - it contains Ventoy and %WIM_FILE%
echo ======================================================
echo.

if /i "%MANUAL_DISK%"=="1" goto :RESOLVE_TARGET_MANUAL

:: Never call :GET_DISK_GPT_ID from inside a ( ) block. Walk disk numbers 0-31
:: with goto so each GET_DISK_GPT_ID runs at top level (skip= in for /f broke WinPE).
set /a DISK_NUM=-1
:RESOLVE_TARGET_SCAN_DISK
set /a DISK_NUM+=1
if !DISK_NUM! gtr 31 goto :RESOLVE_TARGET_FINISH
call :DISK_LIST_HAS_NUMBER !DISK_NUM! X:\list_disk_ansi.txt
if errorlevel 1 goto :RESOLVE_TARGET_SCAN_DISK
if /i "!DISK_NUM!"=="%USB_DISK%" goto :RESOLVE_TARGET_SCAN_DISK
call :GET_DISK_GPT_ID !DISK_NUM!
if defined DISK_GPT_ID if /i "!DISK_GPT_ID!"=="%KIT_DISK_ID%" (
  echo [*] Skipping disk !DISK_NUM! - matches kit disk ID ^(protected^).
  goto :RESOLVE_TARGET_SCAN_DISK
)
if not defined DISK_GPT_ID (
  echo [*] Disk !DISK_NUM! is a deploy candidate ^(MBR or no GPT GUID in detail^).
) else (
  echo [*] Disk !DISK_NUM! is a deploy candidate.
)
set /a OTHER_COUNT+=1
set "TARGET_DISK=!DISK_NUM!"
goto :RESOLVE_TARGET_SCAN_DISK

:RESOLVE_TARGET_MANUAL
set "TARGET_DISK="
set /p TARGET_DISK="IT manual mode - enter target disk number (NOT %USB_DISK%): "
if not defined TARGET_DISK exit /b 1
if "%TARGET_DISK%"=="%USB_DISK%" (
  echo [WARN] Refused: that is the protected USB disk.
  exit /b 1
)
call :DISK_LIST_HAS_NUMBER %TARGET_DISK% X:\list_disk_ansi.txt
if errorlevel 1 (
  echo [ERR] Disk %TARGET_DISK% is not in the DiskPart list.
  exit /b 1
)
call :GET_DISK_GPT_ID %TARGET_DISK%
if defined DISK_GPT_ID if /i "%DISK_GPT_ID%"=="%KIT_DISK_ID%" (
  echo [WARN] Refused: that disk is the registered kit SSD.
  exit /b 1
)
exit /b 0

:RESOLVE_TARGET_FINISH

if "!OTHER_COUNT!"=="0" (
  echo [ERR] No target disk found besides the USB kit ^(disk %USB_DISK%^).
  echo     Connect the internal SSD and try again.
  echo     If Disk 0 appears above, copy deploy.bat v32+ from the kit onto the USB.
  exit /b 1
)
if not "!OTHER_COUNT!"=="1" (
  echo [ERR] Found !OTHER_COUNT! candidate disks besides the USB. Unplug extra drives
  echo     or set MANUAL_DISK=1 for IT-only manual selection.
  exit /b 1
)
exit /b 0

:: ---------------------------------------------------------------------------
:CLEAN_OFFLINE_DESKTOPS
if exist "%WIN_LTR%:\Users\Public\Desktop" call :CLEAN_ONE_DESKTOP "%WIN_LTR%:\Users\Public\Desktop"
if exist "%WIN_LTR%:\Users\Default\Desktop" call :CLEAN_ONE_DESKTOP "%WIN_LTR%:\Users\Default\Desktop"
for /d %%U in ("%WIN_LTR%:\Users\*") do (
  set "PN=%%~nxU"
  if /i not "!PN!"=="Public" if /i not "!PN!"=="Default" if /i not "!PN!"=="All Users" if /i not "!PN!"=="Default User" (
    if exist "%%U\Desktop" call :CLEAN_ONE_DESKTOP "%%U\Desktop"
  )
)
exit /b 0

:CLEAN_ONE_DESKTOP
set "DD=%~1"
if not exist "%DD%" exit /b 0
if exist "X:\deskkeep" rd /s /q "X:\deskkeep"
mkdir "X:\deskkeep" >nul
:: Inline keeps - do not CALL extra labels (WinPE misses them when startnet used CALL deploy.bat)
if exist "%DD%\desktop.ini" move /y "%DD%\desktop.ini" "X:\deskkeep\" >nul 2>&1
if exist "%DD%\Ordinateur.lnk" move /y "%DD%\Ordinateur.lnk" "X:\deskkeep\" >nul 2>&1
if exist "%DD%\Computer.lnk" move /y "%DD%\Computer.lnk" "X:\deskkeep\" >nul 2>&1
if exist "%DD%\This PC.lnk" move /y "%DD%\This PC.lnk" "X:\deskkeep\" >nul 2>&1
if exist "%DD%\Network.lnk" move /y "%DD%\Network.lnk" "X:\deskkeep\" >nul 2>&1
if exist "%DD%\Reseau.lnk" move /y "%DD%\Reseau.lnk" "X:\deskkeep\" >nul 2>&1
if exist "%DD%\Corbeille.lnk" move /y "%DD%\Corbeille.lnk" "X:\deskkeep\" >nul 2>&1
if exist "%DD%\Libraries.lnk" move /y "%DD%\Libraries.lnk" "X:\deskkeep\" >nul 2>&1
for %%F in ("%DD%\*seau.lnk") do if exist "%%~fF" move /y "%%~fF" "X:\deskkeep\" >nul 2>&1
for %%F in ("%DD%\Panneau*.lnk") do if exist "%%~fF" move /y "%%~fF" "X:\deskkeep\" >nul 2>&1
for %%F in ("%DD%\Control*.lnk") do if exist "%%~fF" move /y "%%~fF" "X:\deskkeep\" >nul 2>&1
for %%F in ("%DD%\Fichiers*.lnk") do if exist "%%~fF" move /y "%%~fF" "X:\deskkeep\" >nul 2>&1
for %%F in ("%DD%\*utilisateur*.lnk") do if exist "%%~fF" move /y "%%~fF" "X:\deskkeep\" >nul 2>&1
for %%F in ("%DD%\User*.lnk") do if exist "%%~fF" move /y "%%~fF" "X:\deskkeep\" >nul 2>&1
for %%F in ("%DD%\Recycle*.lnk") do if exist "%%~fF" move /y "%%~fF" "X:\deskkeep\" >nul 2>&1
for %%F in ("%DD%\Biblioth*.lnk") do if exist "%%~fF" move /y "%%~fF" "X:\deskkeep\" >nul 2>&1
if exist "%DEPLOY_VOL%desktop-keep.txt" (
  for /f "usebackq delims=" %%K in ("%DEPLOY_VOL%desktop-keep.txt") do (
    if exist "%DD%\%%K" move /y "%DD%\%%K" "X:\deskkeep\" >nul 2>&1
  )
)
if exist "%DD%\oasys\" move /y "%DD%\oasys" "X:\deskkeep\oasys" >nul 2>&1
for /f "delims=" %%F in ('dir /b /a "%DD%" 2^>nul') do (
  if exist "%DD%\%%F\" (
    rd /s /q "%DD%\%%F" 2>nul
  ) else (
    del /f /q "%DD%\%%F" 2>nul
  )
)
for /f "delims=" %%F in ('dir /b /a "X:\deskkeep" 2^>nul') do (
  move /y "X:\deskkeep\%%F" "%DD%\" >nul 2>&1
)
rd /s /q "X:\deskkeep" 2>nul
exit /b 0

:COPY_OASYS_TO_DESKTOP
if not exist "%WIN_LTR%:\Users\Public\Desktop" mkdir "%WIN_LTR%:\Users\Public\Desktop" 2>nul
if exist "%SystemRoot%\System32\robocopy.exe" (
  robocopy "%DEPLOY_VOL%oasys" "%WIN_LTR%:\Users\Public\Desktop\oasys" /E /R:2 /W:2 /NFL /NDL /NJH /NJS /NC /NS /NP
  if errorlevel 8 echo [WARN] robocopy reported errors copying oasys.
) else (
  xcopy /e /i /y "%DEPLOY_VOL%oasys" "%WIN_LTR%:\Users\Public\Desktop\oasys\"
)
if exist "%WIN_LTR%:\Users\Public\Desktop\oasys" (
  echo [*] oasys copied. Fixing permissions for standard users...
  icacls "%WIN_LTR%:\Users\Public\Desktop\oasys" /grant *S-1-1-0:^(OI^)^(CI^)F /T /C /Q >nul 2>&1
)
exit /b 0

:: Snapshot every oasys .ini while it is still pristine. The application blanks
:: PATH= and SERVERNAME= when a connection attempt fails, so this copy is what
:: Set_OasysPrefs.vbs reads to recover the instance name at first boot. It runs
:: whether or not oasys was copied from the USB, because an image that already
:: carries oasys needs the same snapshot.
:BACKUP_OASYS_INI
for /d %%U in ("%WIN_LTR%:\Users\*") do (
  for %%D in (Desktop Bureau) do (
    if exist "%%~U\%%D\oasys" call :BACKUP_INI_TREE "%%~U\%%D\oasys"
  )
)
exit /b 0

:BACKUP_INI_TREE
for /f "delims=" %%F in ('dir /s /b "%~1\*.ini" 2^>nul') do (
  if not exist "%%F.alfasteel.bak" copy /y "%%F" "%%F.alfasteel.bak" >nul 2>&1
)
exit /b 0

:: ---------------------------------------------------------------------------
:PURGE_SQL_CLONEDP_OFFLINE
reg load HKLM\OfflineSoft %WIN_LTR%:\Windows\System32\config\SOFTWARE >nul 2>&1
if exist "%SystemRoot%\System32\cscript.exe" if exist "%WIN_LTR%:\SQL_PurgeClonedpAliases.vbs" (
  cscript //nologo %WIN_LTR%:\SQL_PurgeClonedpAliases.vbs "HKLM\OfflineSoft\Microsoft\MSSQLServer\Client\ConnectTo" "HKLM\OfflineSoft\Wow6432Node\Microsoft\MSSQLServer\Client\ConnectTo"
) else (
  call :REG_DELETE_CLONEDP_CONNECTTO "HKLM\OfflineSoft\Microsoft\MSSQLServer\Client\ConnectTo"
  call :REG_DELETE_CLONEDP_CONNECTTO "HKLM\OfflineSoft\Wow6432Node\Microsoft\MSSQLServer\Client\ConnectTo"
)
reg unload HKLM\OfflineSoft >nul 2>&1

if exist "%WIN_LTR%:\Users\Default\NTUSER.DAT" (
  reg load HKU\AlfDef "%WIN_LTR%:\Users\Default\NTUSER.DAT" >nul 2>&1
  call :REG_DELETE_CLONEDP_CONNECTTO "HKU\AlfDef\Software\Microsoft\MSSQLServer\Client\ConnectTo"
  call :REG_DELETE_CLONEDP_CONNECTTO "HKU\AlfDef\Software\Wow6432Node\Microsoft\MSSQLServer\Client\ConnectTo"
  reg unload HKU\AlfDef >nul 2>&1
)
for /d %%U in ("%WIN_LTR%:\Users\*") do (
  set "PN=%%~nxU"
  if /i not "!PN!"=="Public" if /i not "!PN!"=="Default" if /i not "!PN!"=="All Users" if /i not "!PN!"=="Default User" (
    if exist "%%U\NTUSER.DAT" (
      set "SAFE=!PN: =!"
      set "SAFE=!SAFE:.=!"
      reg load "HKU\AlfOff!SAFE!" "%%U\NTUSER.DAT" >nul 2>&1
      if not errorlevel 1 (
        call :REG_DELETE_CLONEDP_CONNECTTO "HKU\AlfOff!SAFE!\Software\Microsoft\MSSQLServer\Client\ConnectTo"
        call :REG_DELETE_CLONEDP_CONNECTTO "HKU\AlfOff!SAFE!\Software\Wow6432Node\Microsoft\MSSQLServer\Client\ConnectTo"
        reg unload "HKU\AlfOff!SAFE!" >nul 2>&1
      )
    )
  )
)
exit /b 0

:REG_DELETE_CLONEDP_CONNECTTO
reg delete "%~1" /v CLONEDP /f >nul 2>&1
reg delete "%~1" /v clonedp /f >nul 2>&1
reg delete "%~1" /v "CLONEDP\REEL" /f >nul 2>&1
reg delete "%~1" /v "CLONEDP\reel" /f >nul 2>&1
reg delete "%~1" /v "clonedp\reel" /f >nul 2>&1
reg delete "%~1" /v "clonedp\REEL" /f >nul 2>&1
exit /b 0

:: ---------------------------------------------------------------------------
:RESET_OFFLINE_REIMAGE_COUNTERS
reg load HKLM\OfflineSys %WIN_LTR%:\Windows\System32\config\SYSTEM >nul 2>&1
reg delete "HKLM\OfflineSys\Setup\CloneTag" /f >nul 2>&1
reg delete "HKLM\OfflineSys\Setup\Status\SysprepStatus" /f >nul 2>&1
reg add "HKLM\OfflineSys\Setup\State" /v ImageState /t REG_SZ /d "IMAGE_STATE_COMPLETE" /f >nul 2>&1
reg add "HKLM\OfflineSys\Setup\State" /v SetupType /t REG_DWORD /d 0 /f >nul 2>&1
reg unload HKLM\OfflineSys >nul 2>&1
reg load HKLM\OfflineSoft %WIN_LTR%:\Windows\System32\config\SOFTWARE >nul 2>&1
reg add "HKLM\OfflineSoft\Microsoft\Windows NT\CurrentVersion\SoftwareProtectionPlatform" /v SkipRearm /t REG_DWORD /d 1 /f >nul 2>&1
reg delete "HKLM\OfflineSoft\Microsoft\Windows\CurrentVersion\Setup\State" /v ImageState /f >nul 2>&1
reg unload HKLM\OfflineSoft >nul 2>&1
exit /b 0

:: ---------------------------------------------------------------------------
:DISABLE_SQL_SERVICES_OFFLINE
set "DOLLAR=$"
set "SQL_REEL_SVC=MSSQL%DOLLAR%REEL"
set "SQL_AGENT_SVC=SQLAgent%DOLLAR%REEL"
reg load HKLM\OfflineSys %WIN_LTR%:\Windows\System32\config\SYSTEM >nul 2>&1
for %%C in (ControlSet001 ControlSet002) do (
  reg query "HKLM\OfflineSys\%%C" >nul 2>&1
  if not errorlevel 1 (
    for %%S in (MSSQLSERVER "%SQL_REEL_SVC%" SQLSERVERAGENT "%SQL_AGENT_SVC%" SQLBrowser) do (
      reg add "HKLM\OfflineSys\%%C\Services\%%~S" /v Start /t REG_DWORD /d 4 /f >nul 2>&1
    )
  )
)
reg unload HKLM\OfflineSys >nul 2>&1
for /f "delims=" %%F in ('dir /s /b "%WIN_LTR%:\Users\*sqlmangr*.lnk" 2^>nul') do del /f /q "%%F" 2>nul
for /f "delims=" %%F in ('dir /s /b "%WIN_LTR%:\ProgramData\*sqlmangr*.lnk" 2^>nul') do del /f /q "%%F" 2>nul
exit /b 0

:: ---------------------------------------------------------------------------
:WIPE_EM_OFFLINE_ALL_PROFILES
reg load HKLM\OfflineSoft %WIN_LTR%:\Windows\System32\config\SOFTWARE >nul 2>&1
reg delete "HKLM\OfflineSoft\Microsoft\MSSQLServer\SQLEW" /f >nul 2>&1
reg delete "HKLM\OfflineSoft\Wow6432Node\Microsoft\MSSQLServer\SQLEW" /f >nul 2>&1
call :DISABLE_SQL_RUN_KEYS "HKLM\OfflineSoft"
reg unload HKLM\OfflineSoft >nul 2>&1

if exist "%WIN_LTR%:\Users\Default\NTUSER.DAT" (
  reg load HKU\AlfEmDef "%WIN_LTR%:\Users\Default\NTUSER.DAT" >nul 2>&1
  call :WIPE_EM_USER_HIVE "HKU\AlfEmDef"
  reg unload HKU\AlfEmDef >nul 2>&1
)
for /d %%U in ("%WIN_LTR%:\Users\*") do (
  set "PN=%%~nxU"
  if /i not "!PN!"=="Public" if /i not "!PN!"=="Default" if /i not "!PN!"=="All Users" if /i not "!PN!"=="Default User" (
    if exist "%%U\NTUSER.DAT" (
      set "SAFE=!PN: =!"
      set "SAFE=!SAFE:.=!"
      reg load "HKU\AlfEm!SAFE!" "%%U\NTUSER.DAT" >nul 2>&1
      if not errorlevel 1 (
        call :WIPE_EM_USER_HIVE "HKU\AlfEm!SAFE!"
        reg unload "HKU\AlfEm!SAFE!" >nul 2>&1
      )
    )
  )
)
exit /b 0

:WIPE_EM_USER_HIVE
reg delete "%~1\Software\Microsoft\MSSQLServer\SQLEW\Registered Servers SQL Server" /f >nul 2>&1
reg delete "%~1\Software\Wow6432Node\Microsoft\MSSQLServer\SQLEW\Registered Servers SQL Server" /f >nul 2>&1
exit /b 0

:DISABLE_SQL_RUN_KEYS
for %%V in ("SQL Server Service Manager") do (
  reg delete "%~1\Microsoft\Windows\CurrentVersion\Run" /v %%V /f >nul 2>&1
  reg delete "%~1\Wow6432Node\Microsoft\Windows\CurrentVersion\Run" /v %%V /f >nul 2>&1
)
exit /b 0

:: ---------------------------------------------------------------------------
:WRITE_CLIENT_FIRSTBOOT
setlocal EnableDelayedExpansion
if not defined CLIENT_USER_PASSWORD (
  echo [ERR] CLIENT_USER_PASSWORD is empty - client deploy cannot continue.
  endlocal
  exit /b 1
)
> "!WIN_LTR!:\alfasteel.client.pw" set /p="!CLIENT_USER_PASSWORD!" <nul
> "!WIN_LTR!:\alfasteel.retire.users" echo pc-com
set "PW_BYTES=0"
for %%Z in ("!WIN_LTR!:\alfasteel.client.pw") do set "PW_BYTES=%%~zZ"
if "!PW_BYTES!"=="0" (
  echo [ERR] alfasteel.client.pw was not written on !WIN_LTR!:\
  endlocal
  exit /b 1
)
echo [*] alfasteel.client.pw written on !WIN_LTR!:\ ^(!PW_BYTES! bytes^)
endlocal
exit /b 0

:: ---------------------------------------------------------------------------
:INSTALL_FIRSTBOOT_SHELL
copy /y "%DEPLOY_VOL%Alfasteel_Setup.cmd" "%WIN_LTR%:\Alfasteel_Setup.cmd" >nul
copy /y "%DEPLOY_VOL%Alfasteel-Setup.ps1" "%WIN_LTR%:\Alfasteel-Setup.ps1" >nul
copy /y "%DEPLOY_VOL%Alfasteel-Lib.ps1" "%WIN_LTR%:\Alfasteel-Lib.ps1" >nul
if exist "%DEPLOY_VOL%Alfasteel-Setup-Legacy.cmd" copy /y "%DEPLOY_VOL%Alfasteel-Setup-Legacy.cmd" "%WIN_LTR%:\Alfasteel-Setup-Legacy.cmd" >nul
if not exist "%WIN_LTR%:\Alfasteel_Setup.cmd" (
  echo [ERR] Alfasteel_Setup.cmd was not copied. Put it next to deploy.bat.
  exit /b 1
)
if not exist "%WIN_LTR%:\Alfasteel-Setup.ps1" (
  echo [ERR] Alfasteel-Setup.ps1 was not copied. Put it next to deploy.bat.
  exit /b 1
)
if not exist "%WIN_LTR%:\Alfasteel-Lib.ps1" (
  echo [ERR] Alfasteel-Lib.ps1 was not copied. Put it next to deploy.bat.
  exit /b 1
)
copy /y "%DEPLOY_VOL%Set_OasysPrefs.vbs" "%WIN_LTR%:\Set_OasysPrefs.vbs" >nul
if not exist "%WIN_LTR%:\Set_OasysPrefs.vbs" (
  echo [ERR] Set_OasysPrefs.vbs was not copied. Put it next to deploy.bat.
  exit /b 1
)
> "%WIN_LTR%:\alfasteel.mode" echo %DEPLOY_MODE%
> "%WIN_LTR%:\alfasteel.pcname" echo %NEW_PC_NAME%
del /f /q "%WIN_LTR%:\alfasteel.sqlserver" >nul 2>&1
if defined SQL_SERVER_NAME > "%WIN_LTR%:\alfasteel.sqlserver" echo %SQL_SERVER_NAME%
if exist "%DEPLOY_VOL%kit-version.txt" copy /y "%DEPLOY_VOL%kit-version.txt" "%WIN_LTR%:\kit-version.txt" >nul
> "%WIN_LTR%:\Alfasteel_deploy_info.txt" echo Alfasteel kit 3.1.2 %DEPLOY_MODE% %NEW_PC_NAME% %DATE% %TIME%
echo [*] First-boot mode: %DEPLOY_MODE% ^(see %WIN_LTR%:\alfasteel.mode and Alfasteel_deploy_info.txt^)
echo [*] SERVER = 8 setup steps ^| CLIENT = 6 setup steps on first logon.
del /f /q "%WIN_LTR%:\alfasteel.setup.done" >nul 2>&1
:: Leftover from kits deployed with v16 or earlier.
del /f /q "%WIN_LTR%:\SQL_Rename.bat" >nul 2>&1

reg load HKLM\OfflineSoft %WIN_LTR%:\Windows\System32\config\SOFTWARE
if errorlevel 1 (
  echo [ERR] Could not load offline SOFTWARE hive.
  exit /b 1
)
:: A Winlogon shell inherits the filtered token while UAC is on, so sc, reg on
:: HKLM and osql -E would all be denied and the operator would get a consent
:: prompt. Turn UAC off for the setup boot only; Alfasteel_Setup.cmd restores
:: the image's value on its first lines, and the value only takes effect at the
:: next boot, so privileges hold for the whole run and nothing is left disabled.
set "OLD_LUA="
for /f "tokens=3" %%A in ('reg query "HKLM\OfflineSoft\Microsoft\Windows\CurrentVersion\Policies\System" /v EnableLUA 2^>nul ^| findstr /i "EnableLUA"') do set "OLD_LUA=%%A"
if not defined OLD_LUA set "OLD_LUA=0x1"
> "%WIN_LTR%:\alfasteel.uac.bak" echo %OLD_LUA%
reg add "HKLM\OfflineSoft\Microsoft\Windows\CurrentVersion\Policies\System" /v EnableLUA /t REG_DWORD /d 0 /f >nul
echo [*] UAC recorded as %OLD_LUA% and disabled for the setup boot only.

:: Remember the image's real shell so first boot restores exactly that.
set "OLD_SHELL="
for /f "tokens=2*" %%A in ('reg query "HKLM\OfflineSoft\Microsoft\Windows NT\CurrentVersion\Winlogon" /v Shell 2^>nul ^| findstr /i "REG_SZ"') do set "OLD_SHELL=%%B"
if not defined OLD_SHELL set "OLD_SHELL=explorer.exe"
if /i "%OLD_SHELL:~0,7%"=="cmd.exe" set "OLD_SHELL=explorer.exe"
> "%WIN_LTR%:\alfasteel.shell.bak" echo %OLD_SHELL%
echo [*] Image shell recorded: %OLD_SHELL%
:: The setup script replaces explorer.exe for the first logon only, so nobody
:: can use a half-configured desktop. Its first action is to put Shell back to
:: explorer.exe, so a crash can never leave the PC without a shell.
reg add "HKLM\OfflineSoft\Microsoft\Windows NT\CurrentVersion\Winlogon" /v Shell /t REG_SZ /d "cmd.exe /c C:\Alfasteel_Setup.cmd" /f
:: Retries are armed only on the Winlogon shell (never RunOnce: explorer consumes
:: RunOnce and would restart setup in the same session or again after give-up).
reg delete "HKLM\OfflineSoft\Microsoft\Windows\CurrentVersion\RunOnce" /v "AlfasteelSetup" /f >nul 2>&1
reg delete "HKLM\OfflineSoft\Microsoft\Windows\CurrentVersion\RunOnce" /v "SQLRenameTask" /f >nul 2>&1
reg delete "HKLM\OfflineSoft\Microsoft\Windows\CurrentVersion\Run" /v "SQLRenameTask" /f >nul 2>&1
reg unload HKLM\OfflineSoft

:: A per-user Shell value would override the machine one.
call :CLEAR_USER_SHELL_ALL_PROFILES
exit /b 0

:CLEAR_USER_SHELL_ALL_PROFILES
if exist "%WIN_LTR%:\Users\Default\NTUSER.DAT" (
  reg load HKU\AlfShDef "%WIN_LTR%:\Users\Default\NTUSER.DAT" >nul 2>&1
  reg delete "HKU\AlfShDef\Software\Microsoft\Windows NT\CurrentVersion\Winlogon" /v Shell /f >nul 2>&1
  reg unload HKU\AlfShDef >nul 2>&1
)
for /d %%U in ("%WIN_LTR%:\Users\*") do (
  set "PN=%%~nxU"
  if /i not "!PN!"=="Public" if /i not "!PN!"=="Default" if /i not "!PN!"=="All Users" if /i not "!PN!"=="Default User" (
    if exist "%%U\NTUSER.DAT" (
      set "SAFE=!PN: =!"
      set "SAFE=!SAFE:.=!"
      reg load "HKU\AlfSh!SAFE!" "%%U\NTUSER.DAT" >nul 2>&1
      if not errorlevel 1 (
        reg delete "HKU\AlfSh!SAFE!\Software\Microsoft\Windows NT\CurrentVersion\Winlogon" /v Shell /f >nul 2>&1
        reg unload "HKU\AlfSh!SAFE!" >nul 2>&1
      )
    )
  )
)
exit /b 0

:VALIDATE_DEPLOY_NAMES
if not defined NEW_PC_NAME (
  echo [ERR] Computer name is missing. Start deploy again from the menu.
  exit /b 1
)
for /f "tokens=* delims= " %%A in ("%NEW_PC_NAME%") do set "NEW_PC_NAME=%%A"
echo(%NEW_PC_NAME%| findstr /r /i "^[A-Z0-9][A-Z0-9-]*$" >nul
if errorlevel 1 (
  echo [ERR] Computer name must use letters, numbers, and hyphen only.
  exit /b 1
)
if not "%NEW_PC_NAME%"=="" if not "%NEW_PC_NAME:~15%"=="" (
  echo [ERR] NetBIOS name must be 15 characters or less: %NEW_PC_NAME%
  exit /b 1
)
if defined SQL_SERVER_NAME (
  for /f "tokens=* delims= " %%A in ("%SQL_SERVER_NAME%") do set "SQL_SERVER_NAME=%%A"
  echo(!SQL_SERVER_NAME!| findstr /r /i "^[A-Z0-9][A-Z0-9-]*$" >nul
  if errorlevel 1 (
    echo [ERR] SQL server name must use letters, numbers, and hyphen only.
    exit /b 1
  )
  if not "!SQL_SERVER_NAME!"=="" if not "!SQL_SERVER_NAME:~15!"=="" (
    echo [ERR] SQL server NetBIOS name must be 15 characters or less.
    exit /b 1
  )
)
if /i "%DEPLOY_MODE%"=="CLIENT" (
  if not defined CLIENT_USER_PASSWORD (
    echo [ERR] Client deploy password is missing. Start deploy again from menu option 2.
    exit /b 1
  )
)
exit /b 0

:PREFLIGHT_KIT_FILES
set "KIT_MISS=0"
if exist "%DEPLOY_VOL%kit-version.txt" (
  for /f "usebackq delims=" %%V in ("%DEPLOY_VOL%kit-version.txt") do echo [*] Kit version on USB: %%V
) else (
  echo [WARN] kit-version.txt not on USB - add it so operators can verify the stick.
)
if not exist "%SystemRoot%\System32\findstr.exe" if not exist "X:\Windows\System32\findstr.exe" (
  echo [ERR] findstr.exe is missing from this WinPE. Add it to boot.wim and rebuild the ISO.
  set "KIT_MISS=1"
)
for %%F in (Alfasteel_Setup.cmd Alfasteel-Setup.ps1 Alfasteel-Lib.ps1 Set_OasysPrefs.vbs Clean-UefiDuplicates.cmd) do (
  if not exist "%DEPLOY_VOL%%%F" (
    echo [ERR] Missing on Ventoy: %DEPLOY_VOL%%%F
    set "KIT_MISS=1"
  )
)
if /i "%DEPLOY_MODE%"=="SERVER" (
  for %%F in (SQL_EmReset.vbs SQL_PurgeClonedpAliases.vbs) do (
    if not exist "%DEPLOY_VOL%%%F" (
      echo [ERR] Missing on Ventoy: %DEPLOY_VOL%%%F
      set "KIT_MISS=1"
    )
  )
)
if /i "%DEPLOY_MODE%"=="CLIENT" (
  for %%F in (Alfasteel_Client_FirstBoot.vbs SQL_WipeEmServers.vbs SQL_PurgeClonedpAliases.vbs) do (
    if not exist "%DEPLOY_VOL%%%F" (
      echo [ERR] Missing on Ventoy: %DEPLOY_VOL%%%F
      set "KIT_MISS=1"
    )
  )
)
if "%KIT_MISS%"=="1" (
  echo [ERR] Fix the kit files, then run deploy again. Nothing was wiped.
  exit /b 1
)
exit /b 0

:PICK_TARGET_LETTERS
if not defined VOL set "VOL=%DEPLOY_VOL:~0,2%"
set "EFI_LTR=S"
set "WIN_LTR=W"
if /i "%VOL%"=="S:" set "EFI_LTR=T"
if /i "%VOL%"=="W:" set "WIN_LTR=V"
if /i "%VOL%"=="T:" set "EFI_LTR=U"
if /i "%VOL%"=="V:" set "WIN_LTR=Y"
echo [*] Partition letters: EFI=%EFI_LTR%:  Windows=%WIN_LTR%:  ^(USB is %VOL%^)
exit /b 0

:COPY_SERVER_SQL_KIT
copy /y "%DEPLOY_VOL%SQL_EmReset.vbs" "%WIN_LTR%:\SQL_EmReset.vbs" >nul
copy /y "%DEPLOY_VOL%SQL_PurgeClonedpAliases.vbs" "%WIN_LTR%:\SQL_PurgeClonedpAliases.vbs" >nul
if exist "%DEPLOY_VOL%SQL_FixClient.vbs" copy /y "%DEPLOY_VOL%SQL_FixClient.vbs" "%WIN_LTR%:\SQL_FixClient.vbs" >nul
if not exist "%WIN_LTR%:\SQL_EmReset.vbs" (
  echo [ERR] SQL_EmReset.vbs was not copied to the target. Put it next to deploy.bat.
  exit /b 1
)
exit /b 0

:REGISTER_EM_OFFLINE_ALL_PROFILES
echo [*] Registering Enterprise Manager servers offline: %NEW_PC_NAME% and %NEW_PC_REEL%
if exist "%WIN_LTR%:\Users\Default\NTUSER.DAT" (
  reg load HKU\AlfRegDef "%WIN_LTR%:\Users\Default\NTUSER.DAT" >nul 2>&1
  call :REGISTER_EM_HIVE "HKU\AlfRegDef"
  reg unload HKU\AlfRegDef >nul 2>&1
)
for /d %%U in ("%WIN_LTR%:\Users\*") do (
  set "PN=%%~nxU"
  if /i not "!PN!"=="Public" if /i not "!PN!"=="Default" if /i not "!PN!"=="All Users" if /i not "!PN!"=="Default User" (
    if exist "%%U\NTUSER.DAT" (
      set "SAFE=!PN: =!"
      set "SAFE=!SAFE:.=!"
      reg load "HKU\AlfReg!SAFE!" "%%U\NTUSER.DAT" >nul 2>&1
      if not errorlevel 1 (
        call :REGISTER_EM_HIVE "HKU\AlfReg!SAFE!"
        reg unload "HKU\AlfReg!SAFE!" >nul 2>&1
      )
    )
  )
)
exit /b 0

:REGISTER_EM_HIVE
for %%W in (Software "Software\Wow6432Node") do (
  for %%G in ("Groupe SQL Server" "SQL Server Group") do (
    call :REGISTER_EM_SERVER "%~1" "%%~W" "%%~G" "%NEW_PC_NAME%"
    call :REGISTER_EM_SERVER "%~1" "%%~W" "%%~G" "%NEW_PC_REEL%"
  )
)
exit /b 0

:REGISTER_EM_SERVER
set "ROOT=%~1\%~2\Microsoft\MSSQLServer\SQLEW\Registered Servers SQL Server\%~3"
set "SVR=%~4"
echo(!SVR!| findstr /c:"\\" >nul
if errorlevel 1 (
  reg add "%ROOT%\%SVR%" /f >nul 2>&1
  reg add "%ROOT%\%SVR%" /v Authentication /t REG_DWORD /d 1 /f >nul 2>&1
  reg add "%ROOT%\%SVR%" /v UseSSPI /t REG_DWORD /d 1 /f >nul 2>&1
) else (
  for /f "tokens=1,2 delims=\" %%H in ("%SVR%") do (
    reg add "%ROOT%\%%H\%%I" /f >nul 2>&1
    reg add "%ROOT%\%%H\%%I" /v Authentication /t REG_DWORD /d 1 /f >nul 2>&1
    reg add "%ROOT%\%%H\%%I" /v UseSSPI /t REG_DWORD /d 1 /f >nul 2>&1
  )
)
exit /b 0

:: ---------------------------------------------------------------------------
:INVALID
echo Invalid option selected.
pause
goto START

:FAIL_EXIT
pause
goto EXIT_PROMPT

:EXIT_PROMPT
echo Exiting to command line...
exit /b 0
