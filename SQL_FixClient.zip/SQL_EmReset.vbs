' Reset Enterprise Manager server list (SQL Server 2000).
' After registration: flush DNS/NBT/ARP, then restart SQL services one by one
' mimicking the exact manual Enterprise Manager clicking order.
' After stopping REEL: osql to clonedp\reel while it is down (clears stale client cache).

Option Explicit
On Error Resume Next

Dim fso, sh, net, pc, sysRoot, wowCscript, logPath, app, grp, i, n, groupName, purgeScript

Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
Set net = CreateObject("WScript.Network")
pc = Trim(net.ComputerName)
sysRoot = sh.ExpandEnvironmentStrings("%SystemRoot%")
wowCscript = sysRoot & "\SysWOW64\cscript.exe"

If fso.FileExists(wowCscript) Then
  If InStr(LCase(WScript.FullName), "\system32\cscript.exe") > 0 Then
    sh.Run """" & wowCscript & """ //nologo //B """ & WScript.ScriptFullName & """", 0, True
    WScript.Quit 0
  End If
End If

logPath = ChooseLogPath()

LogLine "computer=" & pc

sh.Run "reg add ""HKLM\SOFTWARE\Wow6432Node\Microsoft\MSSQLServer\Client\ConnectTo"" /v DSQUERY /t REG_SZ /d DBNMPNTW /f", 0, True

purgeScript = fso.GetParentFolderName(WScript.ScriptFullName) & "\SQL_PurgeClonedpAliases.vbs"
If fso.FileExists(purgeScript) Then
  sh.Run "cscript //nologo //B """ & purgeScript & """", 0, True
  LogLine "ran SQL_PurgeClonedpAliases.vbs"
End If

groupName = DetectEmGroupName()
If groupName = "" Then groupName = "Groupe SQL Server"

WipeEmGroup groupName
WipeEmGroup "Groupe SQL Server"
WipeEmGroup "SQL Server Group"
DeleteClonedpEmKeys

Set app = CreateObject("SQLDMO.Application")
If Err.Number = 0 Then
  For Each grp In app.ServerGroups
    i = grp.RegisteredServers.Count
    Do While i >= 1
      n = grp.RegisteredServers.Item(i).Name
      LogLine "SQLDMO remove: " & n
      grp.RegisteredServers.Remove n
      i = i - 1
    Loop
  Next
End If

RegAddEmServer groupName, pc
RegAddEmServer groupName, pc & "\REEL"

FlushNetworkCaches
RestartSqlServicesSequentially

LogLine "done. Close Enterprise Manager, reopen. You should see only:"
LogLine "  " & pc & "  and  " & pc & "\REEL"

WScript.Quit 0


' --- SUBROUTINES ---

' The log is opened, appended and closed for every line: the deployment
' console tails this file, and a buffered stream would look frozen.
Function ChooseLogPath()
  Dim candidates, p, probe
  candidates = Array("C:\Alfasteel_Setup_log.txt", _
                     sh.ExpandEnvironmentStrings("%TEMP%") & "\Alfasteel_Setup_log.txt")
  For Each p In candidates
    Err.Clear
    Set probe = fso.OpenTextFile(p, 8, True)
    If Err.Number = 0 Then
      probe.Close
      ChooseLogPath = p
      Exit Function
    End If
  Next
  ChooseLogPath = ""
End Function

Sub LogLine(msg)
  Dim f
  On Error Resume Next
  If logPath = "" Then Exit Sub
  Set f = fso.OpenTextFile(logPath, 8, True)
  If Err.Number <> 0 Then Exit Sub
  f.WriteLine "[" & Time & "] SQL_EmReset: " & msg
  f.Close
End Sub

' Locale-safe: sc.exe translates its labels but not the numeric state codes.
Function SvcState(svc)
  Dim tmp, tf, txt
  SvcState = "ABSENT"
  tmp = sh.ExpandEnvironmentStrings("%TEMP%") & "\alf_sc_" & Replace(svc, "$", "_") & ".txt"
  sh.Run "%ComSpec% /c sc query """ & svc & """ > """ & tmp & """ 2>&1", 0, True
  If Not fso.FileExists(tmp) Then Exit Function
  Set tf = fso.OpenTextFile(tmp, 1)
  txt = tf.ReadAll
  tf.Close
  fso.DeleteFile tmp, True
  If InStr(txt, ": 1 ") > 0 Then SvcState = "STOPPED"
  If InStr(txt, ": 2 ") > 0 Then SvcState = "START_PENDING"
  If InStr(txt, ": 3 ") > 0 Then SvcState = "STOP_PENDING"
  If InStr(txt, ": 4 ") > 0 Then SvcState = "RUNNING"
End Function

' Bounded wait. "net stop" can block indefinitely, sc + polling cannot.
Function SvcWait(svc, wanted, maxSeconds)
  Dim waited, state
  waited = 0
  Do
    state = SvcState(svc)
    If state = wanted Then
      SvcWait = True
      LogLine "  " & svc & " is " & wanted & " after " & waited & "s."
      Exit Function
    End If
    If state = "ABSENT" Then
      SvcWait = True
      Exit Function
    End If
    If waited >= maxSeconds Then
      LogLine "  [ERR] timeout: " & svc & " is " & state & " after " & waited & "s, expected " & wanted
      SvcWait = False
      Exit Function
    End If
    WScript.Sleep 3000
    waited = waited + 3
  Loop
End Function

Sub SvcStop(svc, dependent)
  Dim state
  state = SvcState(svc)
  If state = "ABSENT" Then Exit Sub
  If state = "STOPPED" Then
    LogLine svc & " already stopped."
    Exit Sub
  End If
  If dependent <> "" Then
    If SvcState(dependent) = "RUNNING" Then
      LogLine "Stopping dependent " & dependent & " ..."
      sh.Run "%ComSpec% /c sc stop """ & dependent & """", 0, True
      SvcWait dependent, "STOPPED", 60
    End If
  End If
  LogLine "Stopping " & svc & " ..."
  sh.Run "%ComSpec% /c sc stop """ & svc & """", 0, True
  If Not SvcWait(svc, "STOPPED", 120) Then
    LogLine "  killing " & svc & " process"
    sh.Run "%ComSpec% /c taskkill /f /fi ""SERVICES eq " & svc & """", 0, True
    SvcWait svc, "STOPPED", 30
  End If
End Sub

Sub SvcStart(svc)
  If SvcState(svc) = "ABSENT" Then Exit Sub
  LogLine "Starting " & svc & " ..."
  sh.Run "%ComSpec% /c sc start """ & svc & """", 0, True
  SvcWait svc, "RUNNING", 180
End Sub

Sub FlushNetworkCaches()
  LogLine "Flushing DNS/NBT/ARP caches..."
  sh.Run "%ComSpec% /c ipconfig /flushdns", 0, True
  sh.Run "%ComSpec% /c nbtstat -R", 0, True
  sh.Run "%ComSpec% /c nbtstat -RR", 0, True
  sh.Run "%ComSpec% /c arp -d *", 0, True
End Sub

Sub RestartSqlServicesSequentially()
  LogLine "Restarting services mimicking exact Enterprise Manager manual order..."

  ' 1. Stop REEL
  SvcStop "MSSQL$REEL", "SQLAgent$REEL"

  ' osql is SQL 2000 cmdline (not BDE). Launch the factory .exe too - that is what
  ' actually cleared clonedp on your PC.
  LogLine "osql probe clonedp\reel while REEL is OFF (must fail; not the BDE app)..."
  sh.Run "%ComSpec% /c osql -E -S clonedp\reel -l 10 -t 20 -Q ""SELECT 1""", 0, True
  sh.Run "%ComSpec% /c osql -E -S CLONEDP\REEL -l 10 -t 20 -Q ""SELECT 1""", 0, True
  LaunchMektebWhileReelDown
  FlushNetworkCaches

  ' 2. Stop LOCAL
  SvcStop "MSSQLSERVER", "SQLSERVERAGENT"

  LogLine "osql probe clonedp while default instance is OFF (must fail)..."
  sh.Run "%ComSpec% /c osql -E -S clonedp -l 10 -t 20 -Q ""SELECT 1""", 0, True

  ' 3. Start REEL
  SvcStart "MSSQL$REEL"

  ' 4. Start LOCAL
  SvcStart "MSSQLSERVER"
End Sub

Function DetectEmGroupName()
  Dim tmp, tf, txt
  DetectEmGroupName = ""
  tmp = sh.ExpandEnvironmentStrings("%TEMP%") & "\alf_em_groups.txt"
  sh.Run "%ComSpec% /c reg query ""HKCU\Software\Microsoft\MSSQLServer\SQLEW\Registered Servers SQL Server"" > """ & tmp & """ 2>&1", 0, True
  If fso.FileExists(tmp) Then
    Set tf = fso.OpenTextFile(tmp, 1)
    txt = tf.ReadAll
    tf.Close
    fso.DeleteFile tmp, True
    If InStr(txt, "Groupe SQL Server") > 0 Then DetectEmGroupName = "Groupe SQL Server"
    If InStr(txt, "SQL Server Group") > 0 Then DetectEmGroupName = "SQL Server Group"
  End If
  If DetectEmGroupName = "" Then DetectEmGroupName = "Groupe SQL Server"
End Function

Sub WipeEmGroup(groupName)
  If groupName = "" Then Exit Sub
  LogLine "Wipe EM group: " & groupName
  sh.Run "reg delete ""HKCU\Software\Microsoft\MSSQLServer\SQLEW\Registered Servers SQL Server\" & groupName & """ /f /reg:32", 0, True
  sh.Run "reg delete ""HKCU\Software\Microsoft\MSSQLServer\SQLEW\Registered Servers SQL Server\" & groupName & """ /f /reg:64", 0, True
  sh.RegWrite "HKCU\Software\Microsoft\MSSQLServer\SQLEW\Registered Servers SQL Server\" & groupName & "\", "", "REG_SZ"
End Sub

Sub RegAddEmServer(groupName, serverName)
  Dim base, dot, host, inst, k
  base = "HKCU\Software\Microsoft\MSSQLServer\SQLEW\Registered Servers SQL Server\" & groupName & "\"
  dot = InStr(serverName, "\")
  If dot > 0 Then
    host = Left(serverName, dot - 1)
    inst = Mid(serverName, dot + 1)
    k = base & host & "\" & inst
  Else
    k = base & serverName
  End If
  Err.Clear
  sh.RegWrite k, "", "REG_SZ"
  sh.RegWrite k & "\Authentication", 1, "REG_DWORD"
  sh.RegWrite k & "\UseSSPI", 1, "REG_DWORD"
  If Err.Number = 0 Then
    LogLine "Registry EM added: " & serverName
  Else
    LogLine "Registry EM failed " & serverName & ": " & Err.Description
  End If
End Sub

Sub DeleteClonedpEmKeys()
  Dim tmp, tf, line, rc
  tmp = sh.ExpandEnvironmentStrings("%TEMP%") & "\alf_em_sqlew.txt"
  sh.Run "%ComSpec% /c reg query ""HKCU\Software\Microsoft\MSSQLServer\SQLEW"" /s > """ & tmp & """ 2>&1", 0, True
  If Not fso.FileExists(tmp) Then Exit Sub
  Set tf = fso.OpenTextFile(tmp, 1)
  Do While Not tf.AtEndOfStream
    line = Trim(tf.ReadLine)
    If InStr(1, line, "HKEY_", vbTextCompare) = 1 Then
      If InStr(UCase(line), "CLONEDP") > 0 Then
        rc = sh.Run("reg delete """ & line & """ /f", 0, True)
        LogLine "Deleted EM CLONEDP key: " & line & " rc=" & rc
      End If
    End If
  Loop
  tf.Close
  On Error Resume Next
  fso.DeleteFile tmp, True
End Sub

Sub LaunchMektebWhileReelDown()
  Dim folder, exePath, prefs, launched
  launched = False
  For Each folder In Array( _
      "C:\Users\Public\Desktop\oasys", _
      sh.ExpandEnvironmentStrings("%USERPROFILE%") & "\Desktop\oasys")
    exePath = folder & "\mekteb.exe"
    If fso.FileExists(exePath) Then
      prefs = folder & "\prefs.ini"
      LogLine "prefs.ini: " & prefs & " exists=" & CStr(fso.FileExists(prefs))
      LogLine "Starting mekteb.exe while MSSQL$REEL is stopped (self-close after probe): " & exePath
      sh.CurrentDirectory = folder
      sh.Run """" & exePath & """", 1, False
      WScript.Sleep 20000
      sh.Run "%ComSpec% /c taskkill /f /im mekteb.exe", 0, True
      LogLine "mekteb.exe closed. It usually blanks PATH= and SERVERNAME= in prefs.ini"
      LogLine "after a failed connection - Set_OasysPrefs.vbs fills them in next."
      launched = True
      Exit For
    End If
  Next
  If Not launched Then
    LogLine "mekteb.exe not found in Public Desktop\oasys or user Desktop\oasys. Copy oasys to the desktop before first logon."
  End If
End Sub
