@echo off
@echo off
:: The line above is duplicated on purpose: if this file is ever re-saved with a
:: UTF-8 BOM, cmd.exe swallows the first line and echo would stay on.
setlocal enabledelayedexpansion

:: ---------------------------------------------------------------------------
:: Remove duplicate "Windows Boot Manager" entries from UEFI firmware NVRAM.
::
:: Every deploy recreates the EFI partition with a new partition GUID, so the
:: firmware cannot match the new bootmgfw.efi to its existing NVRAM variable
:: and adds another one. The old ones point at a partition that no longer
:: exists and pile up in the F12 menu.
::
:: Entries are matched on their path ending in bootmgfw.efi, which is not
:: localised, instead of the description text. The live entry {bootmgr} is
:: always kept; if it is not present nothing is deleted at all.
::
:: Works in WinPE and in full Windows (run as Administrator).
::   Clean-UefiDuplicates.cmd           delete duplicates
::   Clean-UefiDuplicates.cmd /list     report only, change nothing
:: ---------------------------------------------------------------------------

set "MODE=DELETE"
if /i "%~1"=="/list" set "MODE=LIST"

call :PICK_WORK_DIR
set "RAW=%WORK%\alfasteel_fw_raw.txt"
set "ENUM=%WORK%\alfasteel_fw_enum.txt"
set "DELLIST=%WORK%\alfasteel_fw_delete.txt"
set "LOG=%WORK%\alfasteel_fw_log.txt"

echo.
echo ======================================================
echo   UEFI firmware boot entry cleanup   (%MODE%)
echo   Log: %LOG%
echo ======================================================
call :LOG "---- start %DATE% %TIME% mode=%MODE% on %COMPUTERNAME%"

bcdedit /enum firmware > "%RAW%" 2>&1
if errorlevel 1 (
  echo [ERR] bcdedit /enum firmware failed. Output:
  type "%RAW%"
  call :LOG "bcdedit /enum firmware failed"
  type "%RAW%" >> "%LOG%" 2>&1
  echo [WARN] On a BIOS/legacy boot there is no firmware store to clean.
  set "KEEPRAW=1"
  goto :DONE
)

:: bcdedit writes UTF-16 when its output is redirected, and FOR /F cannot
:: tokenise that: it matches nothing and the cleanup silently does nothing.
:: Try the file as-is, then TYPE and MORE (both convert a byte order mark to
:: the console code page), and verify each candidate really is readable.
call :MAKE_READABLE
if errorlevel 1 (
  echo [ERR] The firmware list is not readable as text ^(bcdedit wrote UTF-16^).
  echo [WARN] Keeping %RAW% - send that file so the parser can be adjusted.
  call :LOG "unreadable enum output"
  set "KEEPRAW=1"
  goto :DONE
)
type "%ENUM%" >> "%LOG%" 2>&1

set "CUR_ID="
set "CUR_PATH="
set "CUR_DESC="
set "CUR_DEV="
set /a FOUND=0
set /a KEEP=0
set /a MARKED=0
type nul > "%DELLIST%"

for /f "usebackq tokens=1*" %%A in ("%ENUM%") do call :PARSE_FW_LINE "%%A" "%%B"
call :EVAL_BLOCK

echo.
echo   Windows Boot Manager entries found : !FOUND!
echo   Live entry {bootmgr} present       : !KEEP!
echo   Duplicates to remove               : !MARKED!
call :LOG "found=!FOUND! keep=!KEEP! marked=!MARKED!"

if !MARKED! equ 0 (
  echo.
  echo [*] Nothing to remove.
  goto :DONE
)

if !KEEP! equ 0 (
  echo.
  echo [ERR] The live {bootmgr} entry was not found, so nothing was deleted.
  echo [WARN] Deleting every bootmgfw.efi entry here could leave this PC unbootable.
  echo [WARN] Send %LOG% for a look.
  call :LOG "aborted: no {bootmgr} entry present"
  goto :DONE
)

if /i "%MODE%"=="LIST" (
  echo.
  echo   Entries that would be deleted:
  type "%DELLIST%"
  goto :DONE
)

echo.
set /a GONE=0
set /a FAILED=0
for /f "usebackq tokens=1" %%G in ("%DELLIST%") do (
  echo   removing %%G ...
  call :LOG "removing %%G"
  bcdedit /set {fwbootmgr} displayorder %%G /remove >> "%LOG%" 2>&1
  bcdedit /delete %%G /f >> "%LOG%" 2>&1
  if errorlevel 1 (
    bcdedit /delete %%G /f >> "%LOG%" 2>&1
    if errorlevel 1 (
      echo   [ERR] could not delete %%G
      call :LOG "FAILED %%G"
      set /a FAILED+=1
    ) else (
      set /a GONE+=1
    )
  ) else (
    set /a GONE+=1
  )
)

echo.
echo   Deleted: !GONE!    Failed: !FAILED!
call :LOG "deleted=!GONE! failed=!FAILED!"

:DONE
call :LOG "---- end"
del /f /q "%ENUM%" "%DELLIST%" >nul 2>&1
if not defined KEEPRAW del /f /q "%RAW%" >nul 2>&1
endlocal
exit /b 0


:: ---------------------------------------------------------------------------
:: Produce an ANSI copy of the bcdedit output in %ENUM%. A candidate counts as
:: readable only when a known ASCII marker can be found in it.
:MAKE_READABLE
copy /y "%RAW%" "%ENUM%" >nul 2>&1
call :IS_READABLE && exit /b 0
call :LOG "raw output not ASCII, trying TYPE"
type "%RAW%" > "%ENUM%" 2>nul
call :IS_READABLE && exit /b 0
call :LOG "TYPE did not help, trying MORE"
more < "%RAW%" > "%ENUM%" 2>nul
call :IS_READABLE && exit /b 0
exit /b 1

:IS_READABLE
if not exist "%ENUM%" exit /b 1
findstr /i /c:"bootmgfw.efi" "%ENUM%" >nul 2>&1
if not errorlevel 1 exit /b 0
findstr /i /c:"identif" "%ENUM%" >nul 2>&1
if not errorlevel 1 exit /b 0
exit /b 1


:: ---------------------------------------------------------------------------
:: One line of bcdedit output (call from FOR /F do - never call :EVAL_BLOCK from inside a ( ) block).
:PARSE_FW_LINE
set "K=%~1"
set "V=%~2"
if /i "%K%"=="identifier" (
  call :EVAL_BLOCK
  set "CUR_ID=%V%"
  exit /b 0
)
if /i "%K%"=="identificateur" (
  call :EVAL_BLOCK
  set "CUR_ID=%V%"
  exit /b 0
)
if /i "%K%"=="path" (
  set "CUR_PATH=%V%"
  exit /b 0
)
if /i "%K%"=="chemin" (
  set "CUR_PATH=%V%"
  exit /b 0
)
if /i "%K%"=="device" (
  set "CUR_DEV=%V%"
  exit /b 0
)
if /i "%K%"=="peripherique" (
  set "CUR_DEV=%V%"
  exit /b 0
)
if /i "%K%"=="description" (
  set "CUR_DESC=%V%"
  exit /b 0
)
exit /b 0

:: ---------------------------------------------------------------------------
:: Decide on one block once the next identifier (or the end of file) is seen.
:EVAL_BLOCK
if not defined CUR_ID goto :EVAL_RESET
for /f "tokens=* delims= " %%T in ("!CUR_ID!") do set "CUR_ID=%%T"
if /i "!CUR_ID!"=="{fwbootmgr}" goto :EVAL_RESET
if not defined CUR_PATH goto :EVAL_RESET

echo(!CUR_PATH!| findstr /i /c:"bootmgfw.efi" >nul 2>&1
if errorlevel 1 goto :EVAL_RESET

set /a FOUND+=1
call :LOG "entry !CUR_ID! desc=!CUR_DESC! dev=!CUR_DEV! path=!CUR_PATH!"
if /i "!CUR_ID!"=="{bootmgr}" (
  set /a KEEP=1
  echo   keep    !CUR_ID!  ^(live entry^)
  goto :EVAL_RESET
)
echo   marked  !CUR_ID!  !CUR_DESC!
>> "%DELLIST%" echo !CUR_ID!
set /a MARKED+=1

:EVAL_RESET
set "CUR_ID="
set "CUR_PATH="
set "CUR_DESC="
set "CUR_DEV="
goto :EOF

:: ---------------------------------------------------------------------------
:: Prefer the folder this script runs from (the Ventoy stick keeps the log for
:: later), then WinPE scratch space, then TEMP.
:PICK_WORK_DIR
set "WORK=%~dp0"
if "%WORK:~-1%"=="\" set "WORK=%WORK:~0,-1%"
copy /y nul "%WORK%\alfasteel_fw_probe.tmp" >nul 2>&1
if exist "%WORK%\alfasteel_fw_probe.tmp" (
  del /f /q "%WORK%\alfasteel_fw_probe.tmp" >nul 2>&1
  goto :EOF
)
if exist X:\Windows (
  set "WORK=X:"
  goto :EOF
)
set "WORK=%TEMP%"
goto :EOF

:LOG
>> "%LOG%" echo [%TIME%] %~1
goto :EOF
