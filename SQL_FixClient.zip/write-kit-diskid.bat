@echo off
@echo off
:: The line above is duplicated on purpose: if this file is ever re-saved with a
:: UTF-8 BOM, cmd.exe swallows the first line and echo would stay on.
setlocal enabledelayedexpansion
:: Run ONCE from the Alfasteel Ventoy data drive:
::   E:\write-kit-diskid.bat
:: Creates alfasteel.kit.diskid (GPT disk GUID) next to deploy.bat.

set "SCRATCH=%TEMP%"
if not defined SCRATCH set "SCRATCH=X:"
if exist "X:\" set "SCRATCH=X:"

set "DEPLOY_VOL=%~d0"
if /i "%DEPLOY_VOL%"=="X:" (
  echo [ERR] Run from the Ventoy data drive, not X:
  exit /b 1
)
if not "%DEPLOY_VOL:~-1%"=="\" set "DEPLOY_VOL=%DEPLOY_VOL%\"

set "VOL=%DEPLOY_VOL:~0,2%"
set "USB_DISK="

(
echo select volume %VOL%
echo detail volume
echo exit
) > "%SCRATCH%\kit_probe.txt"
diskpart /s "%SCRATCH%\kit_probe.txt" > "%SCRATCH%\kit_probe_out.txt" 2>&1

call :FIRST_DISK_NUMBER_IN_FILE "%SCRATCH%\kit_probe_out.txt"
set "USB_DISK=%FOUND_DISK%"
if not defined USB_DISK (
  echo [ERR] Could not resolve physical disk for %VOL%
  type "%SCRATCH%\kit_probe_out.txt"
  exit /b 1
)

call :GET_DISK_GPT_ID %USB_DISK%
if not defined DISK_GPT_ID (
  echo [ERR] Could not read GPT disk ID for disk %USB_DISK%
  type "%SCRATCH%\kit_disk_detail_out.txt"
  exit /b 1
)

set "KIT_ID_FILE=%DEPLOY_VOL%alfasteel.kit.diskid"
> "%KIT_ID_FILE%" echo/%DISK_GPT_ID%
attrib -h -s -r "%KIT_ID_FILE%" >nul 2>&1

if not exist "%KIT_ID_FILE%" (
  echo [ERR] Failed to create %KIT_ID_FILE%
  exit /b 1
)

echo.
echo [*] Kit disk number ^(this PC^): %USB_DISK%
echo [*] File is NOT hidden - normal text file on the Ventoy data partition.
echo [*] Full path:
echo     %KIT_ID_FILE%
echo.
echo --- Verify in this window ---
dir /a "%KIT_ID_FILE%"
echo Contents:
type "%KIT_ID_FILE%"
echo.
echo Keep this file next to deploy.bat. deploy.bat must be started from the same drive
echo ^(e.g. if file is E:\alfasteel.kit.diskid, run E:\deploy.bat^).
pause
exit /b 0

:GET_DISK_GPT_ID
set "DISK_GPT_ID="
(
echo select disk %~1
echo detail disk
echo exit
) > "%SCRATCH%\kit_disk_detail.txt"
diskpart /s "%SCRATCH%\kit_disk_detail.txt" > "%SCRATCH%\kit_disk_detail_out.txt" 2>&1
findstr /i /c:"not valid" /c:"n'est pas valide" /c:"not a valid" "%SCRATCH%\kit_disk_detail_out.txt" >nul
if not errorlevel 1 exit /b 1
call :PARSE_GPT_GUID "%SCRATCH%\kit_disk_detail_out.txt"
if not defined DISK_GPT_ID exit /b 1
exit /b 0

:: DiskPart marks the selected item with * (e.g. "* Disk 1"). Never use
:: "call :sub %%L" unquoted or "for %%T in (%%L)" - cmd expands * as a wildcard.
:FIRST_DISK_NUMBER_IN_FILE
set "FOUND_DISK="
for /f "usebackq tokens=1,2,3,4,5,6,7 delims= " %%a in ("%~1") do (
  if defined FOUND_DISK goto :FIRST_DISK_DONE
  if /i "%%a"=="*" if /i "%%b"=="Disk" (
    echo %%c| findstr /r "^[0-9][0-9]*$" >nul
    if not errorlevel 1 set "FOUND_DISK=%%c"
  )
  if not defined FOUND_DISK if /i "%%a"=="*" if /i "%%b"=="Disque" (
    echo %%c| findstr /r "^[0-9][0-9]*$" >nul
    if not errorlevel 1 set "FOUND_DISK=%%c"
  )
  if not defined FOUND_DISK if /i "%%a"=="Disk" (
    echo %%b| findstr /r "^[0-9][0-9]*$" >nul
    if not errorlevel 1 set "FOUND_DISK=%%b"
  )
  if not defined FOUND_DISK if /i "%%a"=="Disque" (
    echo %%b| findstr /r "^[0-9][0-9]*$" >nul
    if not errorlevel 1 set "FOUND_DISK=%%b"
  )
  if not defined FOUND_DISK if /i "%%b"=="Disk" (
    echo %%c| findstr /r "^[0-9][0-9]*$" >nul
    if not errorlevel 1 set "FOUND_DISK=%%c"
  )
  if not defined FOUND_DISK if /i "%%c"=="Disk" (
    echo %%d| findstr /r "^[0-9][0-9]*$" >nul
    if not errorlevel 1 set "FOUND_DISK=%%d"
  )
  if not defined FOUND_DISK if /i "%%b"=="Disque" (
    echo %%c| findstr /r "^[0-9][0-9]*$" >nul
    if not errorlevel 1 set "FOUND_DISK=%%c"
  )
  if not defined FOUND_DISK if /i "%%c"=="Disque" (
    echo %%d| findstr /r "^[0-9][0-9]*$" >nul
    if not errorlevel 1 set "FOUND_DISK=%%d"
  )
)
:FIRST_DISK_DONE
exit /b 0

:PARSE_GPT_GUID
set "DISK_GPT_ID="
for /f "usebackq delims=" %%L in ("%~1") do (
  if not defined DISK_GPT_ID for /f "tokens=1,2,3,4,5,6,7,8 delims= " %%a in ("%%L") do (
    if not defined DISK_GPT_ID if "%%a:~0,1!"=="{" set "DISK_GPT_ID=%%a"
    if not defined DISK_GPT_ID if "%%b:~0,1!"=="{" set "DISK_GPT_ID=%%b"
    if not defined DISK_GPT_ID if "%%c:~0,1!"=="{" set "DISK_GPT_ID=%%c"
    if not defined DISK_GPT_ID if "%%d:~0,1!"=="{" set "DISK_GPT_ID=%%d"
    if not defined DISK_GPT_ID if "%%e:~0,1!"=="{" set "DISK_GPT_ID=%%e"
    if not defined DISK_GPT_ID if "%%f:~0,1!"=="{" set "DISK_GPT_ID=%%f"
    if not defined DISK_GPT_ID if "%%g:~0,1!"=="{" set "DISK_GPT_ID=%%g"
    if not defined DISK_GPT_ID if "%%h:~0,1!"=="{" set "DISK_GPT_ID=%%h"
  )
)
if not defined DISK_GPT_ID (
  for /f "usebackq delims=" %%L in ("%~1") do (
    if not defined DISK_GPT_ID for /f "tokens=1,2,3,4,5,6,7,8 delims= " %%a in ("%%L") do (
      if not defined DISK_GPT_ID (
        echo %%a| findstr /r /i "^[0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F]$" >nul
        if not errorlevel 1 set "DISK_GPT_ID=%%a"
      )
      if not defined DISK_GPT_ID (
        echo %%b| findstr /r /i "^[0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F]$" >nul
        if not errorlevel 1 set "DISK_GPT_ID=%%b"
      )
      if not defined DISK_GPT_ID (
        echo %%c| findstr /r /i "^[0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F]$" >nul
        if not errorlevel 1 set "DISK_GPT_ID=%%c"
      )
      if not defined DISK_GPT_ID (
        echo %%d| findstr /r /i "^[0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F][0-9A-F]$" >nul
        if not errorlevel 1 set "DISK_GPT_ID=%%d"
      )
    )
  )
)
exit /b 0
