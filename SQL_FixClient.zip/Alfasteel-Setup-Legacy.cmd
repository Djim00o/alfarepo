@echo off
@echo off
:: The line above is duplicated on purpose: if this file is ever re-saved with a
:: UTF-8 BOM, cmd.exe swallows the first line and echo would stay on.
setlocal enabledelayedexpansion
title Alfasteel - Configuration en cours / Setup in progress - NE PAS ETEINDRE
color 1F
mode con: cols=110 lines=45

:: ---------------------------------------------------------------------------
:: Alfasteel first-boot setup. Registered by deploy.bat as the Winlogon shell
:: so the operator never sees a half-configured desktop: explorer.exe only
:: starts on the reboot that follows a completed run.
::
:: Every service action is done with sc + bounded polling (never "net stop",
:: which can block forever) and every step is timestamped so the log always
:: advances while work is happening.
::
:: STRUCTURE RULE - do not break it: no CALL inside a ( ) block, anywhere in
:: this file. cmd.exe keeps the batch file open and tracks where it is by byte
:: offset; calling a subroutine from inside a parenthesised block corrupts that
:: bookkeeping, and a later "call :LOG" jumped into the middle of a VBS runner
:: instead of :LOG. The log then read
::   [ERR] Stopping MSSQLSERVER ... was still running after s and was killed.
:: for a service that had stopped perfectly well three seconds later, and the
:: bogus error count sent the whole run down the retry path. Branch with
:: "if not <cond> goto :label" and keep every call at the top level.
:: ---------------------------------------------------------------------------

set "LOG=C:\Alfasteel_Setup_log.txt"
set "MARK=C:\alfasteel.setup.done"
set "WORK=C:"
set "TMPQ=%WORK%\alfasteel.scquery.tmp"
set "TMPO=%WORK%\alfasteel.osql.tmp"
set "VBSOUT=%WORK%\alfasteel.vbs.out"
set "VBSERR=%WORK%\alfasteel.vbs.err"
set "DOLLAR=$"
set "SVC_DEF=MSSQLSERVER"
set "SVC_DEF_AGENT=SQLSERVERAGENT"
set "SVC_REEL=MSSQL%DOLLAR%REEL"
set "SVC_REEL_AGENT=SQLAgent%DOLLAR%REEL"
set /a SETUP_ERRORS=0
set "STATE=ABSENT"

:: Keep the setup shell until setup finishes so explorer does not run underneath.
set "RESTORE_SHELL=explorer.exe"
if not exist C:\alfasteel.shell.bak goto :SHELL_READY
for /f "usebackq tokens=* delims= " %%A in ("C:\alfasteel.shell.bak") do set "RESTORE_SHELL=%%A"
:SHELL_READY
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v Shell /t REG_SZ /d "cmd.exe /c C:\Alfasteel_Setup.cmd" /f >nul 2>&1
taskkill /f /im explorer.exe >nul 2>&1

:: deploy.bat switched UAC off for this one boot so the Winlogon shell gets a
:: full administrator token instead of the filtered one. Put the image's own
:: value back right now: EnableLUA is only read at boot, so this run keeps its
:: privileges while the machine is never left with UAC off.
set "ORIG_LUA=1"
if not exist C:\alfasteel.uac.bak (
  reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v EnableLUA /t REG_DWORD /d 1 /f >nul 2>&1
  goto :UAC_READY
)
for /f "usebackq tokens=1" %%A in ("C:\alfasteel.uac.bak") do set "ORIG_LUA=%%A"
if /i "%ORIG_LUA%"=="0x0" set "ORIG_LUA=0"
if /i "%ORIG_LUA%"=="0x1" set "ORIG_LUA=1"
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v EnableLUA /t REG_DWORD /d %ORIG_LUA% /f >nul 2>&1
:UAC_READY

set "MODE=SERVER"
if not exist C:\alfasteel.mode goto :MODE_READY
for /f "usebackq tokens=* delims= " %%A in ("C:\alfasteel.mode") do set "MODE=%%A"
:MODE_READY
set "MODE_RAW=%MODE%"
for /f "tokens=* delims= " %%A in ("%MODE%") do set "MODE=%%A"
if /i not "%MODE%"=="SERVER" if /i not "%MODE%"=="CLIENT" (
  set "MODE=SERVER"
  set "MODE_WAS_INVALID=1"
)

set "PCNAME=%COMPUTERNAME%"
if not exist C:\alfasteel.pcname goto :NAME_READY
for /f "usebackq tokens=* delims= " %%A in ("C:\alfasteel.pcname") do set "PCNAME=%%A"
:NAME_READY
:: cmd.exe treats \R in %PCNAME%\REEL as a carriage return when the name is
:: expanded next to a backslash. That split step 3 off the batch file, skipped
:: REEL rename/verify, and left two silent SETUP_ERRORS with no [ERR] lines.
set "INST_REEL=%PCNAME%^%\REEL"
set "SQL_REEL_NAME=%PCNAME%^%\REEL"
set "VBS_PURGE=C:\SQL_PurgeClonedpAliases.vbs"
set "VBS_EM=C:\SQL_EmReset.vbs"
set "VBS_PREFS=C:\Set_OasysPrefs.vbs"
:: Short name on C:\ - a long path on the same line as call :ALF_CSCRIPT made cmd
:: treat RUN_VBS as an external command (client step 2 / FirstBoot never ran).
set "VBS_CLIENT=C:\alfclientfb.vbs"

:: The log must never be what breaks the run. If this token cannot append to
:: C:\, every redirection would make cmd print "Access denied" after each line,
:: so probe once and fall back to a directory the current user always owns.
:: "2>nul" comes first on purpose: redirections are opened left to right, so a
:: later one cannot silence a failure reported by an earlier one.
2>nul >> "%LOG%" echo(
if not errorlevel 1 goto :LOG_READY
set "WORK=%TEMP%"
set "LOG=%TEMP%\Alfasteel_Setup_log.txt"
set "TMPQ=%TEMP%\alfasteel.scquery.tmp"
set "TMPO=%TEMP%\alfasteel.osql.tmp"
set "VBSOUT=%TEMP%\alfasteel.vbs.out"
set "VBSERR=%TEMP%\alfasteel.vbs.err"
:LOG_READY

call :LOG "=========================================================="
call :LOG "Alfasteel setup start  mode=%MODE%  name=%PCNAME%  shell=%RESTORE_SHELL%  date=%DATE% %TIME%"
if defined MODE_WAS_INVALID call :LOG "[WARN] alfasteel.mode was invalid (""%MODE_RAW%"") - using SERVER. Re-deploy with menu [1] or [2] if wrong."
if exist C:\Alfasteel_deploy_info.txt type C:\Alfasteel_deploy_info.txt >> "%LOG%" 2>&1

echo(
echo ==========================================================
if /i "%MODE%"=="CLIENT" goto :SHOW_CLIENT_BANNER
echo   SERVEUR / SERVER  -  Alfasteel  8 etapes / 8 steps
echo   SQL local actif, renommage des instances, Enterprise Manager
echo   Local SQL stays on; instances renamed; Enterprise Manager rebuilt
goto :SHOW_BANNER_DONE
:SHOW_CLIENT_BANNER
echo   CLIENT  -  Alfasteel  6 etapes / 6 steps
echo   SQL local arrete, utilisateur alfasteel, pas de renommage SQL
echo   Local SQL stopped; alfasteel user; no SQL instance rename
:SHOW_BANNER_DONE
echo   PC: %PCNAME%    mode=%MODE%
echo   Journal / Log: %LOG%
echo ==========================================================
echo(

:: A Winlogon shell inherits the filtered (non-elevated) token when UAC is on.
:: sc, reg HKLM and osql -E all need the full token, so re-launch once.
reg query "HKU\S-1-5-19" >nul 2>&1
if not errorlevel 1 goto :ELEVATED_OK
if /i "%~1"=="ELEVATED" goto :ELEVATED_OK
call :LOG "Not running elevated - restarting with administrator rights."
powershell -NoProfile -Command "$p = Start-Process -FilePath 'cmd.exe' -ArgumentList '/c','C:\Alfasteel_Setup.cmd','ELEVATED' -Verb RunAs -PassThru; $p.WaitForExit()"
:: The non-elevated Winlogon parent must exit here. Starting explorer while the
:: elevated child is still in SERVER_SETUP caused a second setup instance and
:: looked like steps 2-4 looping dozens of times in one session.
goto :EOF
:ELEVATED_OK

if not exist "%MARK%" goto :RUN_SETUP
call :LOG "Setup already completed on this machine. Nothing to do."
goto :LAUNCH_DESKTOP

:RUN_SETUP
if exist C:\alfasteel.setup.active goto :RUN_SETUP_BUSY
2>nul > C:\alfasteel.setup.active echo %DATE% %TIME% %MODE% %PCNAME%
:: deploy.bat used to register this under RunOnce as well as the shell. If it
:: is still present when we hand back explorer.exe, setup starts again.
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce" /v AlfasteelSetup /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v AlfasteelSetup /f >nul 2>&1
if /i "%MODE%"=="CLIENT" goto :RUN_CLIENT
call :SERVER_SETUP
goto :FINISH
:RUN_CLIENT
call :CLIENT_SETUP
goto :FINISH
:RUN_SETUP_BUSY
call :LOG "[ERR] Setup is already active - delete C:\alfasteel.setup.active only if no setup window is running."
goto :EOF

:FINISH
del /f /q C:\alfasteel.setup.active >nul 2>&1
call :LOG "----------------------------------------------------------"
if not %SETUP_ERRORS% equ 0 call :RECONCILE_ERRORS
if not %SETUP_ERRORS% equ 0 goto :FINISH_WITH_ERRORS

call :LOG "Setup finished with no errors."
2>nul > "%MARK%" echo %DATE% %TIME% %MODE% %PCNAME%
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v Shell /t REG_SZ /d "%RESTORE_SHELL%" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce" /v AlfasteelSetup /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v AlfasteelSetup /f >nul 2>&1
del /f /q C:\alfasteel.pcname C:\alfasteel.mode C:\alfasteel.client.pw C:\alfasteel.retire.users C:\alfasteel.shell.bak C:\alfasteel.sqlserver C:\alfasteel.uac.bak >nul 2>&1
del /f /q C:\alfasteel.setup.tries >nul 2>&1
call :CLEANUP_SCRATCH
call :CLEANUP_KIT_COPIES
echo(
echo   Configuration terminee. Redemarrage dans 15 secondes...
echo   Setup complete. Rebooting in 15 seconds...
echo(
shutdown /r /t 15 /c "Alfasteel setup complete."
ping -n 30 127.0.0.1 >nul
goto :EOF

:FINISH_WITH_ERRORS
del /f /q C:\alfasteel.setup.active >nul 2>&1
call :LOG "[ERR] Setup finished with %SETUP_ERRORS% error(s)."

:: A retry must never be armed with RunOnce and then followed by starting
:: explorer: explorer is the process that consumes RunOnce, so setup would
:: restart from step 1 in the same session, again and again. A retry is armed
:: on the Winlogon shell instead, which cannot fire before the next boot, and
:: there are at most three attempts.
set "TRIES_RAW="
if not exist C:\alfasteel.setup.tries goto :TRIES_PARSE
for /f "usebackq tokens=1" %%A in ("C:\alfasteel.setup.tries") do set "TRIES_RAW=%%A"
:TRIES_PARSE
set /a TRIES=0
echo(%TRIES_RAW%| findstr /r /c:"^[0-9][0-9]*$" >nul 2>&1
if errorlevel 1 goto :TRIES_BUMP
set /a TRIES=%TRIES_RAW%
:TRIES_BUMP
set /a TRIES+=1
2>nul > C:\alfasteel.setup.tries echo %TRIES%
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce" /v AlfasteelSetup /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v AlfasteelSetup /f >nul 2>&1
if %TRIES% geq 3 goto :GIVE_UP

reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v Shell /t REG_SZ /d "cmd.exe /c C:\Alfasteel_Setup.cmd" /f >nul 2>&1
if not exist C:\alfasteel.uac.bak goto :RETRY_ANNOUNCE
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v EnableLUA /t REG_DWORD /d 0 /f >nul 2>&1
:RETRY_ANNOUNCE
call :LOG "Attempt %TRIES% of 3 finished with errors. Rebooting to try again."
echo(
echo   %SETUP_ERRORS% erreur(s) - tentative %TRIES%/3. Redemarrage dans 20 s. Voir %LOG%
echo   %SETUP_ERRORS% error(s) - attempt %TRIES%/3. Rebooting in 20 s. See %LOG%
echo(
shutdown /r /t 20 /c "Alfasteel setup will retry after this restart."
ping -n 40 127.0.0.1 >nul
goto :EOF

:GIVE_UP
del /f /q C:\alfasteel.setup.active >nul 2>&1
:: Work may already be done while the error count is stale (old kit bugs / retries).
if not %SETUP_ERRORS% equ 0 call :RECONCILE_ERRORS
if not %SETUP_ERRORS% equ 0 goto :GIVE_UP_STOP
call :LOG "[WARN] Give-up reconciled to success - finishing normally."
goto :FINISH
:GIVE_UP_STOP
:: Out of attempts: hand the PC back in a normal, usable state and stop
:: touching it. Whatever is wrong needs a person and the log.
call :LOG "[ERR] Giving up after %TRIES% attempts. No retry armed; the shell and UAC are back to the image values."
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce" /v AlfasteelSetup /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v AlfasteelSetup /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v Shell /t REG_SZ /d "%RESTORE_SHELL%" /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v EnableLUA /t REG_DWORD /d %ORIG_LUA% /f >nul 2>&1
del /f /q C:\alfasteel.uac.bak >nul 2>&1
echo(
echo   ATTENTION: %SETUP_ERRORS% erreur(s) apres %TRIES% tentatives. Rien ne sera reessaye.
echo   WARNING:   %SETUP_ERRORS% error(s) after %TRIES% attempts. No further retry.
echo(
echo   Log: %LOG%
echo   Corrigez la cause, puis relancez C:\Alfasteel_Setup.cmd en administrateur.
echo   Fix the cause, then run C:\Alfasteel_Setup.cmd again as administrator.
echo   Opening the desktop in 10 seconds (no keypress required)...
echo(
call :CLEANUP_SCRATCH
ping -n 21 127.0.0.1 >nul
goto :LAUNCH_DESKTOP

:LAUNCH_DESKTOP
:: The elevated relaunch must not start explorer: its parent (the shell
:: process, running with the normal token) does that.
if /i "%~1"=="ELEVATED" goto :EOF
start "" %RESTORE_SHELL%
goto :EOF


:: ===========================================================================
:: SERVER
:: ===========================================================================
:SERVER_SETUP
call :ALF_STEP "1/8 Waiting for the SQL Server services to start"
call :SVC_START "%SVC_DEF%" 240
call :SVC_START "%SVC_REEL%" 240

call :ALF_STEP "2/8 Renaming the default instance to %PCNAME%"
call :OSQL_RENAME_INSTANCE "" "%PCNAME%"

call :ALF_STEP "3/8 Renaming the REEL instance to %INST_REEL%"
call :SVC_START "%SVC_REEL%" 240
call :OSQL_RENAME_INSTANCE ".\REEL" "%SQL_REEL_NAME%"

call :ALF_STEP "4/8 Restarting both instances so the new names take effect"
call :SQL_RESTART "%SVC_REEL%" "%SVC_REEL_AGENT%"
call :SQL_RESTART "%SVC_DEF%" "%SVC_DEF_AGENT%"

call :ALF_STEP "5/8 Removing CLONEDP client aliases"
call :ALF_CSCRIPT "%VBS_PURGE%" 240

call :ALF_STEP "6/8 Rebuilding Enterprise Manager and breaking the CLONEDP name cache"
call :ALF_CSCRIPT "%VBS_EM%" 900

call :ALF_STEP "7/8 Pointing Desktop\oasys\prefs.ini at %PCNAME%"
call :ALF_CSCRIPT "%VBS_PREFS%" 180

call :ALF_STEP "8/8 Verifying the instance names"
call :VERIFY_NAME "" "%PCNAME%"
call :VERIFY_NAME ".\REEL" "%INST_REEL%"
call :VERIFY_NO_CLONEDP_INI
call :GRANT_LOCAL_ADMINS
exit /b 0


:: ===========================================================================
:: CLIENT
:: ===========================================================================
:CLIENT_SETUP
call :ALF_STEP "1/6 Making sure no local SQL service is running"
call :SVC_STOP "%SVC_DEF_AGENT%" "" 90
call :SVC_STOP "%SVC_REEL_AGENT%" "" 90
call :SVC_STOP "%SVC_DEF%" "" 90
call :SVC_STOP "%SVC_REEL%" "" 90
call :SVC_STOP "SQLBrowser" "" 90

call :ALF_STEP "2/6 Creating the local user and clearing Enterprise Manager"
set "ALF_VBS_SCRIPT=%VBS_CLIENT%"
set "ALF_VBS_TIMEOUT=600"
call :ALF_CSCRIPT
set "ALF_VBS_SCRIPT="
set "ALF_VBS_TIMEOUT="

call :ALF_STEP "3/6 Removing CLONEDP client aliases"
call :ALF_CSCRIPT "%VBS_PURGE%" 240

call :ALF_STEP "4/6 Flushing the name caches"
call :FLUSH_CACHES

call :ALF_STEP "5/6 Pointing Desktop\oasys\prefs.ini at the SQL server"
call :ALF_CSCRIPT "%VBS_PREFS%" 180

call :ALF_STEP "6/6 Verifying the workstation"
net user alfasteel > "%TMPO%" 2>&1
if not errorlevel 1 goto :CLIENT_USER_PRESENT
call :LOG "[ERR] local user alfasteel does not exist."
set /a SETUP_ERRORS+=1
goto :CLIENT_SVC_CHECK
:CLIENT_USER_PRESENT
type "%TMPO%" >> "%LOG%" 2>&1
call :LOG "  local user alfasteel exists."
:CLIENT_SVC_CHECK
call :VERIFY_CLIENT_SVC "%SVC_DEF%"
call :VERIFY_CLIENT_SVC "%SVC_REEL%"
call :VERIFY_NO_CLONEDP_INI
exit /b 0


:: ===========================================================================
:: Helpers
:: ===========================================================================

:: Every append puts "2>nul" before the file redirection so that a machine
:: which still hands this script a filtered token produces a quiet, degraded
:: run instead of an "Access denied" line after each message.
:LOG
echo [%TIME%] %~1
2>nul >> "%LOG%" echo [%TIME%] %~1
exit /b 0

:ALF_STEP
echo(
echo ==========================================================
echo  %~1
echo ==========================================================
2>nul >> "%LOG%" echo(
2>nul >> "%LOG%" echo [%TIME%] === %~1
exit /b 0

:: Locale-safe service state. sc.exe translates its labels but not the numeric
:: state codes, so the "STATE : 4  RUNNING" line is matched on ": 4 ".
:SVC_STATE
set "STATE=ABSENT"
sc query "%~1" > "%TMPQ%" 2>&1
findstr /c:": 1 " "%TMPQ%" >nul 2>&1
if not errorlevel 1 set "STATE=STOPPED"
findstr /c:": 2 " "%TMPQ%" >nul 2>&1
if not errorlevel 1 set "STATE=START_PENDING"
findstr /c:": 3 " "%TMPQ%" >nul 2>&1
if not errorlevel 1 set "STATE=STOP_PENDING"
findstr /c:": 4 " "%TMPQ%" >nul 2>&1
if not errorlevel 1 set "STATE=RUNNING"
exit /b 0

:: %1 service, %2 max seconds
:SVC_START
call :SVC_STATE "%~1"
if /i "!STATE!"=="ABSENT" goto :SVC_START_ABSENT
if /i "!STATE!"=="RUNNING" goto :SVC_START_ALREADY
call :LOG "Starting %~1 ..."
sc start "%~1" >> "%LOG%" 2>&1
call :SVC_STATE "%~1"
if /i "!STATE!"=="RUNNING" goto :SVC_START_POLL
call :POLL "%~1" RUNNING %~2
if not errorlevel 1 exit /b 0
set /a SETUP_ERRORS+=1
exit /b 0
:SVC_START_POLL
call :POLL "%~1" RUNNING %~2
if not errorlevel 1 exit /b 0
set /a SETUP_ERRORS+=1
exit /b 0
:SVC_START_ABSENT
call :LOG "Service %~1 is not installed - skipped."
exit /b 0
:SVC_START_ALREADY
call :LOG "Service %~1 already running."
exit /b 0

:: %1 service, %2 dependent service to stop first (may be empty), %3 max seconds
:SVC_STOP
call :SVC_STATE "%~1"
if /i "!STATE!"=="ABSENT" exit /b 0
if /i "!STATE!"=="STOPPED" goto :SVC_STOP_ALREADY
if "%~2"=="" goto :SVC_STOP_MAIN
call :SVC_STATE "%~2"
if /i "!STATE!"=="ABSENT" goto :SVC_STOP_MAIN
if /i "!STATE!"=="STOPPED" goto :SVC_STOP_MAIN
call :LOG "Stopping dependent service %~2 ..."
sc stop "%~2" >> "%LOG%" 2>&1
call :POLL "%~2" STOPPED 60
:SVC_STOP_MAIN
call :LOG "Stopping %~1 ..."
sc stop "%~1" >> "%LOG%" 2>&1
call :POLL "%~1" STOPPED %~3
if not errorlevel 1 exit /b 0
call :LOG "[ERR] %~1 did not stop cleanly - killing the process."
taskkill /f /fi "SERVICES eq %~1" >> "%LOG%" 2>&1
call :POLL "%~1" STOPPED 30
exit /b 0
:SVC_STOP_ALREADY
call :LOG "Service %~1 already stopped."
exit /b 0

:: %1 service, %2 wanted state, %3 max seconds. Never blocks longer than %3.
:POLL
set /a POLLED=0
:POLL_LOOP
call :SVC_STATE "%~1"
if /i "!STATE!"=="%~2" goto :POLL_REACHED
if /i "!STATE!"=="ABSENT" exit /b 0
if !POLLED! geq %~3 goto :POLL_TIMEOUT
ping -n 4 127.0.0.1 >nul
set /a POLLED+=3
goto :POLL_LOOP
:POLL_REACHED
call :LOG "  %~1 is %~2 after !POLLED!s."
exit /b 0
:POLL_TIMEOUT
call :LOG "[ERR] Timeout: %~1 still !STATE! after !POLLED!s, expected %~2."
exit /b 1

:: %1 instance service, %2 its agent service
:SQL_RESTART
call :SVC_STOP "%~1" "%~2" 120
call :FLUSH_CACHES
call :SVC_START "%~1" 180
exit /b 0

:FLUSH_CACHES
call :LOG "Flushing DNS / NetBIOS / ARP caches ..."
ipconfig /flushdns >> "%LOG%" 2>&1
nbtstat -R >> "%LOG%" 2>&1
nbtstat -RR >> "%LOG%" 2>&1
arp -d * >> "%LOG%" 2>&1
exit /b 0

:: %1 -S target (empty = default), %2 new @@SERVERNAME (e.g. tentest or tentest\REEL)
:: Idempotent: partial renames (PC + tentest both in sysservers) must not make osql exit 1
:: or every retry replays steps 2-4 with the same French 15015/15028 errors.
:OSQL_RENAME_INSTANCE
set "REN_INST=%~1"
set "REN_NEW=%~2"
call :VERIFY_NAME_CORE "%REN_INST%" "%REN_NEW%"
if errorlevel 1 goto :OSQL_RENAME_DO
call :LOG "  instance already reports %REN_NEW% - rename skipped."
exit /b 0
:OSQL_RENAME_DO
if /i not "%REN_INST%"==".\REEL" goto :OSQL_RENAME_RUN
call :SVC_STATE "%SVC_REEL%"
if /i "!STATE!"=="RUNNING" goto :OSQL_RENAME_RUN
call :LOG "[ERR] %SVC_REEL% is !STATE! - cannot rename REEL until the service is RUNNING."
set /a SETUP_ERRORS+=1
exit /b 0
:OSQL_RENAME_RUN
set "REN_SQL=%WORK%\alfasteel.rename.sql"
(
echo SET NOCOUNT ON
echo DECLARE @old sysname, @new sysname
echo SET @new = N'!REN_NEW!'
echo SELECT @old = @@SERVERNAME
echo IF UPPER(LTRIM(RTRIM(@old))) ^<^> UPPER(LTRIM(RTRIM(@new)))
echo BEGIN
echo   IF EXISTS ^(SELECT 1 FROM master.dbo.sysservers WHERE UPPER(RTRIM(srvname))=UPPER(LTRIM(RTRIM(@new))) AND srvid^<^>0^) EXEC sp_dropserver @new,'droplogins'
echo   IF EXISTS ^(SELECT 1 FROM master.dbo.sysservers WHERE srvname=@old^) EXEC sp_dropserver @old,'droplogins'
echo   EXEC sp_addserver @new,'local'
echo END
) > "%REN_SQL%"
set "OSQL_S="
if not "%REN_INST%"=="" set "OSQL_S=-S %REN_INST%"
osql -E %OSQL_S% -i "%REN_SQL%" > "%TMPO%" 2>&1
set "RC=!errorlevel!"
type "%TMPO%" >> "%LOG%" 2>&1
if not "!RC!"=="0" call :LOG "[WARN] osql %OSQL_S% rename script exited !RC! - verifying @@SERVERNAME anyway."
call :VERIFY_NAME_CORE "%REN_INST%" "%REN_NEW%"
if not errorlevel 1 exit /b 0
call :LOG "[ERR] Instance %REN_INST% still does not report %REN_NEW% after rename."
set /a SETUP_ERRORS+=1
exit /b 0

:: %1 -S target (empty for the default instance), %2 T-SQL
:OSQL
set "OSQL_S="
if not "%~1"=="" set "OSQL_S=-S %~1"
osql -E %OSQL_S% -l 20 -t 60 -Q "%~2" > "%TMPO%" 2>&1
set "RC=!errorlevel!"
type "%TMPO%" >> "%LOG%" 2>&1
type "%TMPO%"
if "!RC!"=="0" exit /b 0
call :LOG "[WARN] osql %OSQL_S% exited !RC! - caller decides if this is fatal."
exit /b 0

:: Renaming the instance invalidates every Windows login that was qualified
:: with the golden host name, so an account that could connect on the reference
:: PC as CLONEDP\user cannot connect as <newname>\user. The local
:: administrators group (SID S-1-5-32-544, BUILTIN\... in any language) is
:: name-independent, so granting it sysadmin survives every future rename.
:GRANT_LOCAL_ADMINS
call :LOG "Making sure the local administrators group is a SQL sysadmin ..."
call :GRANT_ADMINS_ON ""
call :GRANT_ADMINS_ON ".\REEL"
exit /b 0

:: Advisory only: it never increments the error count. The grant is normally
:: already in place from the golden image, and a failure here must not send a
:: perfectly good deploy down the retry path.
:GRANT_ADMINS_ON
set "OSQL_S="
if not "%~1"=="" set "OSQL_S=-S %~1"
set "ADMGRP="
for /f "usebackq tokens=* delims= " %%A in (`powershell -NoProfile -Command "([System.Security.Principal.SecurityIdentifier]'S-1-5-32-544').Translate([System.Security.Principal.NTAccount]).Value"`) do set "ADMGRP=%%A"
if not defined ADMGRP set "ADMGRP=BUILTIN\Administrateurs"
osql -E %OSQL_S% -l 20 -t 60 -Q "IF NOT EXISTS (SELECT 1 FROM master.dbo.syslogins WHERE loginname = '%ADMGRP%') EXEC sp_grantlogin '%ADMGRP%'; IF NOT EXISTS (SELECT 1 FROM master.dbo.syslogins WHERE loginname = '%ADMGRP%' AND sysadmin = 1) EXEC sp_addsrvrolemember '%ADMGRP%', 'sysadmin';" > "%TMPO%" 2>&1
set "RC=!errorlevel!"
type "%TMPO%" >> "%LOG%" 2>&1
if "!RC!"=="0" goto :GRANT_ADMINS_OK
call :LOG "  [WARN] could not confirm sysadmin for %ADMGRP% on instance %~1 (exit code !RC!) - not treated as an error"
exit /b 0
:GRANT_ADMINS_OK
call :LOG "  %ADMGRP% is sysadmin on instance %~1"
exit /b 0

:: Only meaningful when a target server name was recorded: a blank one means
:: "leave prefs.ini alone", so a remaining CLONEDP is then intentional.
::
:: This must never recurse over the whole of C:\Users. On a first boot that
:: scan walks a few hundred thousand files with a cold cache while Windows is
:: still busy, and it sat at step 8/8 for minutes with nothing on screen. The
:: only files Set_OasysPrefs.vbs touches - and the only ones that can still
:: name the golden host - live under Desktop\oasys, so check exactly those.
:VERIFY_NO_CLONEDP_INI
if not exist C:\alfasteel.sqlserver exit /b 0
call :LOG "Checking the oasys .ini files for a leftover CLONEDP ..."
type nul > "%TMPO%" 2>nul
set /a INI_DIRS=0
for /d %%U in ("C:\Users\*") do (
  if exist "%%~U\Desktop\oasys" set /a INI_DIRS+=1
  if exist "%%~U\Desktop\oasys" findstr /i /s /m /c:"clonedp" "%%~U\Desktop\oasys\*.ini" >> "%TMPO%" 2>nul
  if exist "%%~U\Bureau\oasys" set /a INI_DIRS+=1
  if exist "%%~U\Bureau\oasys" findstr /i /s /m /c:"clonedp" "%%~U\Bureau\oasys\*.ini" >> "%TMPO%" 2>nul
)
if !INI_DIRS! equ 0 goto :VERIFY_INI_NOTHING
if not exist "%TMPO%" goto :VERIFY_INI_SKIPPED
set "INI_SZ=1"
for %%F in ("%TMPO%") do set "INI_SZ=%%~zF"
if "!INI_SZ!"=="0" goto :VERIFY_INI_CLEAN
call :LOG "[ERR] CLONEDP is still referenced in:"
type "%TMPO%" >> "%LOG%" 2>&1
type "%TMPO%"
set /a SETUP_ERRORS+=1
exit /b 0
:VERIFY_INI_CLEAN
call :LOG "  no CLONEDP left in any oasys .ini file (!INI_DIRS! folder(s) checked)."
exit /b 0
:VERIFY_INI_NOTHING
call :LOG "  no Desktop\oasys folder found - nothing to check."
exit /b 0
:VERIFY_INI_SKIPPED
call :LOG "  scratch file unavailable - CLONEDP check skipped."
exit /b 0

:: %1 -S target, %2 expected @@SERVERNAME
:VERIFY_NAME
call :VERIFY_NAME_CORE "%~1" "%~2"
if errorlevel 1 goto :VERIFY_NAME_FAIL
call :LOG "  OK: %~2"
exit /b 0
:VERIFY_NAME_FAIL
call :LOG "[ERR] Instance %~1 does not report %~2 yet:"
type "%TMPO%"
set /a SETUP_ERRORS+=1
exit /b 0

:: exit /b 0 when @@SERVERNAME matches, 1 otherwise (no SETUP_ERRORS)
:VERIFY_NAME_CORE
set "OSQL_S="
if not "%~1"=="" set "OSQL_S=-S %~1"
osql -E %OSQL_S% -l 20 -t 60 -Q "SET NOCOUNT ON; IF UPPER(@@SERVERNAME)<>UPPER('%~2') BEGIN RAISERROR('@@SERVERNAME mismatch',16,1) END" > "%TMPO%" 2>&1
set "RC=!errorlevel!"
type "%TMPO%" >> "%LOG%" 2>&1
if "!RC!"=="0" exit /b 0
exit /b 1

:: Drop a bogus error count from an older kit when the machine is already OK.
:RECONCILE_ERRORS
if /i "%MODE%"=="CLIENT" goto :RECONCILE_CLIENT
call :VERIFY_NAME_CORE "" "%PCNAME%"
if errorlevel 1 exit /b 0
call :VERIFY_NAME_CORE ".\REEL" "%INST_REEL%"
if errorlevel 1 exit /b 0
call :LOG "[WARN] Clearing error count: both SQL instances report the expected names."
set /a SETUP_ERRORS=0
exit /b 0

:RECONCILE_CLIENT
net user alfasteel >nul 2>&1
if errorlevel 1 exit /b 0
call :SVC_STATE "%SVC_DEF%"
if /i "!STATE!"=="RUNNING" exit /b 0
call :SVC_STATE "%SVC_REEL%"
if /i "!STATE!"=="RUNNING" exit /b 0
call :LOG "[WARN] Clearing error count: client checks passed (alfasteel user, SQL services stopped)."
set /a SETUP_ERRORS=0
exit /b 0

:: Scratch and staging files on C:\ (keep Alfasteel_Setup.cmd and the log).
:CLEANUP_SCRATCH
del /f /q "%TMPQ%" "%TMPO%" "%VBSOUT%" "%VBSERR%" "%WORK%\alfasteel.rename.sql" >nul 2>&1
del /f /q "C:\alfasteel.scquery.tmp" "C:\alfasteel.osql.tmp" "C:\alfasteel.vbs.out" "C:\alfasteel.vbs.err" "C:\alfasteel.sqlquery.tmp" "C:\alfasteel.vbs" >nul 2>&1
del /f /q "C:\bcd~tmp.tmp" >nul 2>&1
exit /b 0

:: First-boot VBS copies from the USB; not needed after a successful run.
:CLEANUP_KIT_COPIES
del /f /q "C:\SQL_PurgeClonedpAliases.vbs" "C:\SQL_EmReset.vbs" "C:\Set_OasysPrefs.vbs" "C:\SQL_FixClient.vbs" "C:\SQL_WipeEmServers.vbs" "C:\Alfasteel_Client_FirstBoot.vbs" "C:\alfclientfb.vbs" >nul 2>&1
exit /b 0

:: %1 service that must NOT be running on a client workstation
:VERIFY_CLIENT_SVC
call :SVC_STATE "%~1"
if /i not "!STATE!"=="RUNNING" goto :VERIFY_CLIENT_SVC_OK
call :LOG "[ERR] %~1 is still running on a client workstation."
set /a SETUP_ERRORS+=1
exit /b 0
:VERIFY_CLIENT_SVC_OK
call :LOG "  %~1 is !STATE! - correct for a client."
exit /b 0

:: %1 script path, %2 timeout seconds; or set ALF_VBS_SCRIPT + ALF_VBS_TIMEOUT.
:: Label is not :RUN_VBS - that name was executed as an external command when
:: a quoted path on the same line confused cmd's parser after call :ALF_STEP.
:ALF_CSCRIPT
set "VBS_RUN=%~1"
set "VBS_TOUT=%~2"
if not defined VBS_RUN set "VBS_RUN=%ALF_VBS_SCRIPT%"
if not defined VBS_TOUT set "VBS_TOUT=%ALF_VBS_TIMEOUT%"
if not defined VBS_RUN goto :ALF_CSCRIPT_MISSING
if not exist "%VBS_RUN%" if exist "C:\Alfasteel_Client_FirstBoot.vbs" set "VBS_RUN=C:\Alfasteel_Client_FirstBoot.vbs"
if not exist "%VBS_RUN%" goto :ALF_CSCRIPT_MISSING
set /a VBS_TOUT_MS=!VBS_TOUT!*1000
call :LOG "Running %VBS_RUN% (timeout !VBS_TOUT!s) ..."
del /f /q "%VBSOUT%" "%VBSERR%" >nul 2>&1
where powershell.exe >nul 2>&1
if not errorlevel 1 goto :ALF_CSCRIPT_GUARDED
cscript //nologo //B "%VBS_RUN%" >> "%LOG%" 2>&1
set "RC=!errorlevel!"
if "!RC!"=="0" goto :ALF_CSCRIPT_OK
call :LOG "[ERR] %VBS_RUN% exited with code !RC!"
set /a SETUP_ERRORS+=1
exit /b 1
:ALF_CSCRIPT_GUARDED
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p = Start-Process -FilePath 'cscript.exe' -ArgumentList '//nologo','//B','%VBS_RUN%' -WindowStyle Hidden -PassThru -RedirectStandardOutput '%VBSOUT%' -RedirectStandardError '%VBSERR%'; if (-not $p.WaitForExit(!VBS_TOUT_MS!)) { try { $p.Kill() } catch { }; exit 258 }; exit $p.ExitCode"
set "RC=!errorlevel!"
if exist "%VBSOUT%" type "%VBSOUT%" >> "%LOG%" 2>&1
if exist "%VBSERR%" type "%VBSERR%" >> "%LOG%" 2>&1
if "!RC!"=="258" goto :ALF_CSCRIPT_KILLED
if not "!RC!"=="0" goto :ALF_CSCRIPT_FAILED
:ALF_CSCRIPT_OK
call :LOG "  %VBS_RUN% finished."
exit /b 0
:ALF_CSCRIPT_KILLED
call :LOG "[ERR] %VBS_RUN% was still running after !VBS_TOUT!s and was killed."
set /a SETUP_ERRORS+=1
exit /b 1
:ALF_CSCRIPT_FAILED
call :LOG "[ERR] %VBS_RUN% exited with code !RC!"
set /a SETUP_ERRORS+=1
exit /b 1
:ALF_CSCRIPT_MISSING
call :LOG "[ERR] MISSING %VBS_RUN% - copy kit VBS files next to deploy.bat on the Ventoy USB."
set /a SETUP_ERRORS+=1
exit /b 1
