# Alfasteel shared helpers (first-boot setup). Dot-source from Alfasteel-Setup.ps1.
# Requires Windows PowerShell 4+ (Windows 8.1).
# Native tools (osql, sc, cscript) are checked via $LASTEXITCODE; do not use $ErrorActionPreference Stop globally.

$ErrorActionPreference = 'Continue'

function Get-AlfKitRoot {
    if (Test-Path 'C:\Alfasteel-Lib.ps1') { return 'C:\' }
    $here = Split-Path -Parent $MyInvocation.PSCommandPath
    if ($here) { return $here }
    return (Get-Location).Path
}

function Initialize-AlfLog {
    param([string]$LogPath = 'C:\Alfasteel_Setup_log.txt')
    $dir = Split-Path -Parent $LogPath
    if ($dir -and -not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }
    try {
        Add-Content -Path $LogPath -Value '' -ErrorAction Stop
    } catch {
        $LogPath = Join-Path $env:TEMP 'Alfasteel_Setup_log.txt'
    }
    return $LogPath
}

function Write-AlfLog {
    param(
        [string]$LogPath,
        [string]$Message
    )
    $line = '[{0}] {1}' -f (Get-Date -Format 'HH:mm:ss.ff'), $Message
    Write-Host $line
    try { Add-Content -Path $LogPath -Value $line -ErrorAction SilentlyContinue } catch { }
}

function Write-AlfStep {
    param([string]$LogPath, [string]$Title)
    Write-Host ''
    Write-Host ('=' * 58)
    Write-Host " $Title"
    Write-Host ('=' * 58)
    Write-AlfLog -LogPath $LogPath -Message "=== $Title"
}

function Get-AlfServiceState {
    param([string]$ServiceName)
    $out = & sc.exe query $ServiceName 2>&1 | Out-String
    if ($out -match ': 4 ') { return 'RUNNING' }
    if ($out -match ': 1 ') { return 'STOPPED' }
    if ($out -match ': 2 ') { return 'START_PENDING' }
    if ($out -match ': 3 ') { return 'STOP_PENDING' }
    if ($out -match '1060') { return 'ABSENT' }
    return 'ABSENT'
}

function Wait-AlfServiceState {
    param(
        [string]$ServiceName,
        [string]$Wanted,
        [int]$MaxSeconds = 120
    )
    $waited = 0
    while ($waited -le $MaxSeconds) {
        $st = Get-AlfServiceState -ServiceName $ServiceName
        if ($st -eq $Wanted -or $st -eq 'ABSENT') { return $true }
        Start-Sleep -Seconds 3
        $waited += 3
    }
    return $false
}

function Start-AlfService {
    param(
        [string]$LogPath,
        [string]$ServiceName,
        [int]$MaxSeconds = 240
    )
    $st = Get-AlfServiceState -ServiceName $ServiceName
    if ($st -eq 'ABSENT') {
        Write-AlfLog -LogPath $LogPath -Message "Service $ServiceName is not installed - skipped."
        return
    }
    if ($st -eq 'RUNNING') {
        Write-AlfLog -LogPath $LogPath -Message "Service $ServiceName already running."
        return
    }
    Write-AlfLog -LogPath $LogPath -Message "Starting $ServiceName ..."
    & sc.exe start $ServiceName | Out-Null
    if (-not (Wait-AlfServiceState -ServiceName $ServiceName -Wanted 'RUNNING' -MaxSeconds $MaxSeconds)) {
        throw "Timeout starting $ServiceName"
    }
}

function Stop-AlfService {
    param(
        [string]$LogPath,
        [string]$ServiceName,
        [string]$Dependent = '',
        [int]$MaxSeconds = 90
    )
    $st = Get-AlfServiceState -ServiceName $ServiceName
    if ($st -eq 'ABSENT' -or $st -eq 'STOPPED') {
        Write-AlfLog -LogPath $LogPath -Message "Service $ServiceName already stopped."
        return
    }
    if ($Dependent) {
        $ds = Get-AlfServiceState -ServiceName $Dependent
        if ($ds -eq 'RUNNING') {
            Write-AlfLog -LogPath $LogPath -Message "Stopping dependent $Dependent ..."
            & sc.exe stop $Dependent | Out-Null
            Wait-AlfServiceState -ServiceName $Dependent -Wanted 'STOPPED' -MaxSeconds 60 | Out-Null
        }
    }
    Write-AlfLog -LogPath $LogPath -Message "Stopping $ServiceName ..."
    & sc.exe stop $ServiceName | Out-Null
    if (-not (Wait-AlfServiceState -ServiceName $ServiceName -Wanted 'STOPPED' -MaxSeconds $MaxSeconds)) {
        Write-AlfLog -LogPath $LogPath -Message "[ERR] $ServiceName did not stop cleanly - killing process."
        & taskkill.exe /f /fi "SERVICES eq $ServiceName" | Out-Null
        Wait-AlfServiceState -ServiceName $ServiceName -Wanted 'STOPPED' -MaxSeconds 30 | Out-Null
    }
}

function Restart-AlfSqlInstance {
    param(
        [string]$LogPath,
        [string]$SqlService,
        [string]$AgentService
    )
    Stop-AlfService -LogPath $LogPath -ServiceName $SqlService -Dependent $AgentService -MaxSeconds 120
    Flush-AlfNetworkCaches -LogPath $LogPath
    Start-AlfService -LogPath $LogPath -ServiceName $SqlService -MaxSeconds 180
}

function Flush-AlfNetworkCaches {
    param([string]$LogPath)
    Write-AlfLog -LogPath $LogPath -Message 'Flushing DNS / NetBIOS / ARP caches ...'
    & ipconfig.exe /flushdns | Out-Null
    & nbtstat.exe -R | Out-Null
    & nbtstat.exe -RR | Out-Null
    & arp.exe -d '*' | Out-Null
}

function Invoke-AlfOsql {
    param(
        [string]$LogPath,
        [string]$ServerInstance = '',
        [string]$QueryFile,
        [int]$LoginTimeout = 20,
        [int]$QueryTimeout = 60
    )
    $args = @('-E', '-l', $LoginTimeout, '-t', $QueryTimeout)
    if ($ServerInstance) { $args += @('-S', $ServerInstance) }
    $args += @('-i', $QueryFile)
    $tmp = Join-Path $env:TEMP 'alfasteel.osql.out'
    & osql.exe @args 2>&1 | Tee-Object -FilePath $tmp
    $rc = $LASTEXITCODE
    if (Test-Path $tmp) { Get-Content $tmp | Add-Content -Path $LogPath -ErrorAction SilentlyContinue }
    return $rc
}

function Test-AlfServerName {
    param(
        [string]$LogPath,
        [string]$ServerInstance = '',
        [string]$ExpectedName
    )
    $q = @"
SET NOCOUNT ON;
IF UPPER(@@SERVERNAME) <> UPPER(N'$($ExpectedName.Replace("'", "''"))')
BEGIN
  RAISERROR('@@SERVERNAME mismatch', 16, 1);
END
"@
    $qf = Join-Path $env:TEMP 'alfasteel.verify.sql'
    Set-Content -Path $qf -Value $q -Encoding ASCII
    $args = @('-E', '-l', '20', '-t', '60', '-i', $qf)
    if ($ServerInstance) { $args += @('-S', $ServerInstance) }
    & osql.exe @args 2>&1 | Add-Content -Path $LogPath
    return ($LASTEXITCODE -eq 0)
}

function Invoke-AlfRenameInstance {
    param(
        [string]$LogPath,
        [string]$ServerInstance = '',
        [string]$NewName
    )
    if (Test-AlfServerName -LogPath $LogPath -ServerInstance $ServerInstance -ExpectedName $NewName) {
        Write-AlfLog -LogPath $LogPath -Message "  instance already reports $NewName - rename skipped."
        return $true
    }
    $escaped = $NewName.Replace("'", "''")
    $sql = @"
SET NOCOUNT ON;
DECLARE @old sysname, @new sysname;
SET @new = N'$escaped';
SELECT @old = @@SERVERNAME;
IF UPPER(LTRIM(RTRIM(@old))) <> UPPER(LTRIM(RTRIM(@new)))
BEGIN
  IF EXISTS (SELECT 1 FROM master.dbo.sysservers WHERE UPPER(RTRIM(srvname)) = UPPER(LTRIM(RTRIM(@new))) AND srvid <> 0)
    EXEC sp_dropserver @new, 'droplogins';
  IF EXISTS (SELECT 1 FROM master.dbo.sysservers WHERE srvname = @old)
    EXEC sp_dropserver @old, 'droplogins';
  EXEC sp_addserver @new, 'local';
END
"@
    $sqlFile = Join-Path $env:TEMP 'alfasteel.rename.sql'
    Set-Content -Path $sqlFile -Value $sql -Encoding ASCII
    $rc = Invoke-AlfOsql -LogPath $LogPath -ServerInstance $ServerInstance -QueryFile $sqlFile
    if ($rc -ne 0) {
        Write-AlfLog -LogPath $LogPath -Message "[WARN] osql rename exited $rc - verifying @@SERVERNAME anyway."
    }
    if (Test-AlfServerName -LogPath $LogPath -ServerInstance $ServerInstance -ExpectedName $NewName) {
        return $true
    }
    Write-AlfLog -LogPath $LogPath -Message "[ERR] Instance '$ServerInstance' still does not report $NewName after rename."
    return $false
}

function Invoke-AlfCscript {
    param(
        [string]$LogPath,
        [string]$ScriptPath,
        [int]$TimeoutSeconds = 300
    )
    if (-not (Test-Path $ScriptPath)) {
        Write-AlfLog -LogPath $LogPath -Message "[ERR] MISSING $ScriptPath"
        return $false
    }
    Write-AlfLog -LogPath $LogPath -Message "Running $ScriptPath (timeout ${TimeoutSeconds}s) ..."
    $out = Join-Path $env:TEMP 'alfasteel.vbs.out'
    $err = Join-Path $env:TEMP 'alfasteel.vbs.err'
    Remove-Item $out, $err -Force -ErrorAction SilentlyContinue
    $p = Start-Process -FilePath 'cscript.exe' -ArgumentList '//nologo', '//B', $ScriptPath `
        -WindowStyle Hidden -PassThru -RedirectStandardOutput $out -RedirectStandardError $err
    if (-not $p.WaitForExit($TimeoutSeconds * 1000)) {
        try { $p.Kill() } catch { }
        Write-AlfLog -LogPath $LogPath -Message "[ERR] $ScriptPath was still running after ${TimeoutSeconds}s and was killed."
        return $false
    }
    if (Test-Path $out) { Get-Content $out | Add-Content -Path $LogPath }
    if (Test-Path $err) { Get-Content $err | Add-Content -Path $LogPath }
    if ($p.ExitCode -ne 0) {
        Write-AlfLog -LogPath $LogPath -Message "[ERR] $ScriptPath exited with code $($p.ExitCode)"
        return $false
    }
    Write-AlfLog -LogPath $LogPath -Message "  $ScriptPath finished."
    return $true
}

function Grant-AlfSqlAdmins {
    param([string]$LogPath, [string]$ServerInstance = '')
    try {
        $adm = ([System.Security.Principal.SecurityIdentifier]'S-1-5-32-544').Translate([System.Security.Principal.NTAccount]).Value
    } catch {
        $adm = 'BUILTIN\Administrateurs'
    }
    $admEsc = $adm.Replace("'", "''")
    $q = "IF NOT EXISTS (SELECT 1 FROM master.dbo.syslogins WHERE loginname = '$admEsc') EXEC sp_grantlogin '$admEsc'; IF NOT EXISTS (SELECT 1 FROM master.dbo.syslogins WHERE loginname = '$admEsc' AND sysadmin = 1) EXEC sp_addsrvrolemember '$admEsc', 'sysadmin';"
    $qf = Join-Path $env:TEMP 'alfasteel.grant.sql'
    Set-Content -Path $qf -Value $q -Encoding ASCII
    $args = @('-E', '-l', '20', '-t', '60', '-i', $qf)
    if ($ServerInstance) { $args += @('-S', $ServerInstance) }
    & osql.exe @args 2>&1 | Add-Content -Path $LogPath
    if ($LASTEXITCODE -ne 0) {
        Write-AlfLog -LogPath $LogPath -Message "[WARN] could not confirm sysadmin for $adm on '$ServerInstance' (not treated as error)."
    } else {
        Write-AlfLog -LogPath $LogPath -Message "  $adm is sysadmin on instance '$ServerInstance'"
    }
}

function Test-AlfNoClonedpIni {
    param([string]$LogPath)
    if (-not (Test-Path 'C:\alfasteel.sqlserver')) { return $true }
    Write-AlfLog -LogPath $LogPath -Message 'Checking oasys .ini files for leftover CLONEDP ...'
    $hits = @()
    $users = Join-Path $env:SystemDrive 'Users'
    Get-ChildItem -Path $users -Directory -ErrorAction SilentlyContinue | ForEach-Object {
        foreach ($desk in @('Desktop', 'Bureau')) {
            $oasys = Join-Path $_.FullName "$desk\oasys"
            if (Test-Path $oasys) {
                Get-ChildItem -Path $oasys -Filter '*.ini' -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
                    if (Select-String -Path $_.FullName -Pattern 'clonedp' -SimpleMatch -Quiet) {
                        $hits += $_.FullName
                    }
                }
            }
        }
    }
    if ($hits.Count -gt 0) {
        Write-AlfLog -LogPath $LogPath -Message '[ERR] CLONEDP still referenced in:'
        $hits | ForEach-Object { Write-AlfLog -LogPath $LogPath -Message "  $_" }
        return $false
    }
    Write-AlfLog -LogPath $LogPath -Message '  no CLONEDP left in oasys .ini files.'
    return $true
}

function Restore-AlfUacOnly {
    if (Test-Path 'C:\alfasteel.uac.bak') {
        $lua = (Get-Content 'C:\alfasteel.uac.bak' -Raw).Trim()
        if ($lua -eq '0x0') { $v = 0 } else { $v = 1 }
        Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name EnableLUA -Value $v -Type DWord -Force
    } else {
        Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name EnableLUA -Value 1 -Type DWord -Force
    }
}

function Ensure-AlfSetupShell {
    Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' `
        -Name Shell -Value 'cmd.exe /c C:\Alfasteel_Setup.cmd' -Force
}

function Stop-AlfExplorerDesktop {
    Get-Process -Name explorer -ErrorAction SilentlyContinue | ForEach-Object {
        try { $_.Kill() } catch { }
    }
}

function Test-AlfIsAdmin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Test-AlfPowerShellVersion {
    param([string]$LogPath)
    $maj = $PSVersionTable.PSVersion.Major
    if ($maj -lt 4) {
        Write-AlfLog -LogPath $LogPath -Message "[ERR] Windows PowerShell 4+ is required (found $maj)."
        return $false
    }
    return $true
}

function Test-AlfNetBiosName {
    param(
        [string]$Name,
        [string]$LogPath,
        [string]$Label = 'Computer name'
    )
    $n = $Name.Trim()
    if (-not $n) {
        Write-AlfLog -LogPath $LogPath -Message "[ERR] $Label is empty."
        return $false
    }
    if ($n.Length -gt 15) {
        Write-AlfLog -LogPath $LogPath -Message "[ERR] $Label '$n' is longer than 15 characters (NetBIOS limit)."
        return $false
    }
    if ($n -notmatch '^[A-Za-z0-9][A-Za-z0-9\-]*$') {
        Write-AlfLog -LogPath $LogPath -Message "[ERR] $Label '$n' must use letters, numbers, and hyphen only."
        return $false
    }
    return $true
}

function Clear-AlfStaleSetupLock {
    param(
        [string]$ActivePath,
        [string]$LogPath,
        [int]$StaleMinutes = 120
    )
    if (-not (Test-Path $ActivePath)) { return $true }
    try {
        $age = ((Get-Date) - (Get-Item -LiteralPath $ActivePath).LastWriteTime).TotalMinutes
        if ($age -gt $StaleMinutes) {
            Write-AlfLog -LogPath $LogPath -Message "[WARN] Removing stale setup lock (${StaleMinutes}m+ old)."
            Remove-Item -LiteralPath $ActivePath -Force -ErrorAction Stop
            return $true
        }
        Write-AlfLog -LogPath $LogPath -Message '[ERR] Setup lock exists and looks recent - another run may be in progress.'
        Write-AlfLog -LogPath $LogPath -Message "      If no setup window is open, delete $ActivePath and reboot."
        return $false
    } catch {
        Write-AlfLog -LogPath $LogPath -Message "[WARN] Could not read setup lock - removing: $($_.Exception.Message)"
        Remove-Item -LiteralPath $ActivePath -Force -ErrorAction SilentlyContinue
        return $true
    }
}

function Test-AlfSetupPreflight {
    param(
        [string]$LogPath,
        [string]$Mode
    )
    $ok = $true
    if (-not (Test-AlfPowerShellVersion -LogPath $LogPath)) { $ok = $false }

    $osql = Join-Path $env:WINDIR 'System32\osql.exe'
    if (-not (Test-Path -LiteralPath $osql)) {
        Write-AlfLog -LogPath $LogPath -Message "[ERR] osql.exe not found at $osql - SQL setup cannot run."
        $ok = $false
    }

    $common = @(
        'C:\Set_OasysPrefs.vbs',
        'C:\SQL_PurgeClonedpAliases.vbs'
    )
    if ($Mode -eq 'SERVER') {
        $common += @('C:\SQL_EmReset.vbs')
    } else {
        $clientVbs = 'C:\alfclientfb.vbs'
        if (-not (Test-Path $clientVbs)) { $clientVbs = 'C:\Alfasteel_Client_FirstBoot.vbs' }
        $common += @($clientVbs, 'C:\SQL_WipeEmServers.vbs')
        if (-not (Test-Path 'C:\alfasteel.client.pw')) {
            Write-AlfLog -LogPath $LogPath -Message '[ERR] C:\alfasteel.client.pw is missing (client deploy password).'
            $ok = $false
        }
    }
    foreach ($f in $common) {
        if (-not (Test-Path -LiteralPath $f)) {
            Write-AlfLog -LogPath $LogPath -Message "[ERR] Required file missing: $f"
            $ok = $false
        }
    }
    return $ok
}
