' Point the factory application at the SQL server this PC must use.
'
' Rewrites PATH= and SERVERNAME= in every *.ini under Desktop\oasys
' (Public desktop and each user profile), keeping the instance suffix:
'   PATH=clonedp\REEL   ->  PATH=<newname>\REEL
'   SERVERNAME=clonedp  ->  SERVERNAME=<newname>
'
' An EMPTY value is filled in as well: the application blanks PATH= and
' SERVERNAME= whenever a connection attempt fails, so after the CLONEDP cache
' break the file often reads "PATH=" with nothing after it. The instance is then
' taken from the pristine <name>.alfasteel.bak that deploy.bat saved before the
' first boot, or from DEFAULT_INSTANCE if no backup exists.
'
' Values that are file paths (contain ":" or "/", or start with "\\") are left
' alone, so a real PATH= to a folder is never damaged. The first change to a
' file leaves a <name>.alfasteel.bak next to it.
'
' Target name: first command line argument, else the contents of
' C:\alfasteel.sqlserver written by deploy.bat. No target means "do nothing".

Option Explicit

Const DEFAULT_INSTANCE = "\REEL"

Dim fso, sh, logPath, target, filesChanged, linesChanged, filesScanned

Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
logPath = ChooseLogPath()
filesChanged = 0
linesChanged = 0
filesScanned = 0

target = TargetName()
If target = "" Then
  LogLine "no target server name given - prefs.ini left unchanged"
  WScript.Quit 0
End If

LogLine "target server name: " & target
ScanDesktops
LogLine "done: " & filesScanned & " ini file(s) scanned, " & _
        linesChanged & " line(s) changed in " & filesChanged & " file(s)"

If filesScanned = 0 Then
  LogLine "WARNING: no Desktop\oasys\*.ini found - check that oasys was copied to the desktop"
End If
WScript.Quit 0


' --- SUBROUTINES ---

Function TargetName()
  Dim tf, v
  TargetName = ""
  If WScript.Arguments.Count > 0 Then
    TargetName = Trim(WScript.Arguments(0))
    Exit Function
  End If
  If Not fso.FileExists("C:\alfasteel.sqlserver") Then Exit Function
  On Error Resume Next
  Set tf = fso.OpenTextFile("C:\alfasteel.sqlserver", 1)
  If Err.Number <> 0 Then Exit Function
  v = Trim(tf.ReadAll)
  tf.Close
  v = Trim(Replace(Replace(v, vbCr, ""), vbLf, ""))
  TargetName = v
End Function

Sub ScanDesktops()
  Dim usersDir, profile, name
  usersDir = "C:\Users"
  ScanOneUser usersDir & "\Public"
  If Not fso.FolderExists(usersDir) Then Exit Sub
  For Each profile In fso.GetFolder(usersDir).SubFolders
    name = UCase(profile.Name)
    If name <> "PUBLIC" And name <> "DEFAULT" And name <> "DEFAULT USER" And name <> "ALL USERS" Then
      ScanOneUser profile.Path
    End If
  Next
End Sub

' The desktop folder is named "Desktop" on disk even on French Windows
' ("Bureau" is only the display name), but older upgraded profiles can differ.
Sub ScanOneUser(profilePath)
  Dim deskName, oasys
  For Each deskName In Array("Desktop", "Bureau")
    oasys = profilePath & "\" & deskName & "\oasys"
    If fso.FolderExists(oasys) Then ScanFolder fso.GetFolder(oasys), 0
  Next
End Sub

Sub ScanFolder(folder, depth)
  Dim f, sub_
  If depth > 3 Then Exit Sub
  For Each f In folder.Files
    If LCase(fso.GetExtensionName(f.Name)) = "ini" Then UpdateIni f.Path
  Next
  For Each sub_ In folder.SubFolders
    ScanFolder sub_, depth + 1
  Next
End Sub

Sub UpdateIni(path)
  Dim tf, txt, lines, i, changedHere, key, value, newValue, out, backup

  filesScanned = filesScanned + 1
  On Error Resume Next
  Err.Clear
  Set tf = fso.OpenTextFile(path, 1, False, 0)
  If Err.Number <> 0 Then
    LogLine "cannot read " & path & ": " & Err.Description
    Exit Sub
  End If
  txt = tf.ReadAll
  tf.Close
  On Error GoTo 0

  ' Normalise to single line feeds for parsing, write back as CRLF.
  txt = Replace(txt, vbCrLf, vbLf)
  txt = Replace(txt, vbCr, vbLf)
  lines = Split(txt, vbLf)

  changedHere = 0
  For i = 0 To UBound(lines)
    key = KeyOf(lines(i))
    If key <> "" Then
      value = Trim(Mid(lines(i), InStr(lines(i), "=") + 1))
      If Not LooksLikePath(value) Then
        newValue = target & SuffixFor(path, key, value)
        If StrComp(newValue, value, vbTextCompare) <> 0 Then
          If value = "" Then
            LogLine path & ": " & Trim(key) & " was empty  ->  " & Trim(key) & "=" & newValue
          Else
            LogLine path & ": " & key & "=" & value & "  ->  " & key & "=" & newValue
          End If
          lines(i) = key & "=" & newValue
          changedHere = changedHere + 1
        End If
      End If
    End If
  Next

  If changedHere = 0 Then Exit Sub

  On Error Resume Next
  backup = path & ".alfasteel.bak"
  If Not fso.FileExists(backup) Then
    fso.CopyFile path, backup, False
    If Err.Number <> 0 Then
      LogLine "cannot back up " & path & ": " & Err.Description & " - not modified"
      Exit Sub
    End If
  End If

  ' robocopy keeps source attributes, so the file can arrive read-only.
  Err.Clear
  fso.GetFile(path).Attributes = 0
  Err.Clear
  Set out = fso.CreateTextFile(path, True, False)
  If Err.Number <> 0 Then
    LogLine "cannot write " & path & ": " & Err.Description
    Exit Sub
  End If
  out.Write Join(lines, vbCrLf)
  out.Close
  If Err.Number <> 0 Then
    LogLine "write failed on " & path & ": " & Err.Description
    Exit Sub
  End If
  filesChanged = filesChanged + 1
  linesChanged = linesChanged + changedHere
  LogLine "updated " & path & " (backup: " & backup & ")"
End Sub

' Returns the key exactly as written (keeping the original spacing) for
' PATH= and SERVERNAME= lines only, or "" for anything else.
Function KeyOf(line)
  Dim eq, raw, name
  KeyOf = ""
  If Left(LTrim(line), 1) = ";" Then Exit Function
  eq = InStr(line, "=")
  If eq = 0 Then Exit Function
  raw = Left(line, eq - 1)
  name = UCase(Trim(raw))
  If name = "PATH" Or name = "SERVERNAME" Then KeyOf = raw
End Function

Function LooksLikePath(value)
  If value = "" Then
    LooksLikePath = False
    Exit Function
  End If
  LooksLikePath = (InStr(value, ":") > 0) Or (InStr(value, "/") > 0) Or (Left(value, 2) = "\\")
End Function

' The instance to keep. The application blanks PATH= and SERVERNAME= whenever a
' connection attempt fails, so an empty value is recovered from the pristine
' .alfasteel.bak that deploy.bat took before Windows first booted, and falls
' back to the REEL instance this image has always used.
Function SuffixFor(path, key, value)
  Dim backupValue
  If value <> "" Then
    SuffixFor = InstanceSuffix(value)
    Exit Function
  End If
  backupValue = ValueFromFile(path & ".alfasteel.bak", key)
  If backupValue <> "" And Not LooksLikePath(backupValue) Then
    SuffixFor = InstanceSuffix(backupValue)
    If SuffixFor <> "" Then Exit Function
  End If
  SuffixFor = DEFAULT_INSTANCE
End Function

Function ValueFromFile(path, key)
  Dim tf, txt, lines, line, wanted
  ValueFromFile = ""
  If Not fso.FileExists(path) Then Exit Function
  wanted = UCase(Trim(key))
  On Error Resume Next
  Set tf = fso.OpenTextFile(path, 1, False, 0)
  If Err.Number <> 0 Then Exit Function
  txt = tf.ReadAll
  tf.Close
  On Error GoTo 0
  txt = Replace(Replace(txt, vbCrLf, vbLf), vbCr, vbLf)
  lines = Split(txt, vbLf)
  For Each line In lines
    If KeyOf(line) <> "" Then
      If UCase(Trim(KeyOf(line))) = wanted Then
        ValueFromFile = Trim(Mid(line, InStr(line, "=") + 1))
        If ValueFromFile <> "" Then Exit Function
      End If
    End If
  Next
End Function

Function InstanceSuffix(value)
  Dim p
  InstanceSuffix = ""
  p = InStr(value, "\")
  If p > 0 Then InstanceSuffix = Mid(value, p)
End Function

Function ChooseLogPath()
  Dim candidates, p, probe
  candidates = Array("C:\Alfasteel_Setup_log.txt", _
                     sh.ExpandEnvironmentStrings("%TEMP%") & "\Alfasteel_Setup_log.txt")
  For Each p In candidates
    On Error Resume Next
    Err.Clear
    Set probe = fso.OpenTextFile(p, 8, True)
    If Err.Number = 0 Then
      probe.Close
      On Error GoTo 0
      ChooseLogPath = p
      Exit Function
    End If
    On Error GoTo 0
  Next
  ChooseLogPath = ""
End Function

Sub LogLine(msg)
  Dim f
  On Error Resume Next
  If logPath = "" Then Exit Sub
  Set f = fso.OpenTextFile(logPath, 8, True)
  If Err.Number <> 0 Then Exit Sub
  f.WriteLine "[" & Time & "] OasysPrefs: " & msg
  f.Close
End Sub
