@echo off
@echo off
:: Alfasteel kit 3.0 - WinPE entry. Deployment engine is Deploy-WinPE.bat (batch, no PowerShell required in WinPE).
setlocal
cd /d "%~dp0"
if not exist "%~dp0Deploy-WinPE.bat" (
  echo [ERR] Missing Deploy-WinPE.bat next to deploy.bat
  exit /b 1
)
cmd /c "%~dp0Deploy-WinPE.bat"
exit /b %ERRORLEVEL%
