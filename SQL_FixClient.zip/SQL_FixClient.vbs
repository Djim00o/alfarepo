' After SQL rename: remove CLONEDP ConnectTo aliases so legacy config.ini cannot still connect.
' Run 64-bit cscript so /reg:32 and /reg:64 both address the real hives.

Option Explicit

Dim fso, sh, sysRoot, sysCscript, scriptDir, purgeScript

Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
sysRoot = sh.ExpandEnvironmentStrings("%SystemRoot%")
sysCscript = sysRoot & "\System32\cscript.exe"
If fso.FileExists(sysRoot & "\Sysnative\cscript.exe") Then
  sysCscript = sysRoot & "\Sysnative\cscript.exe"
End If

scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
purgeScript = scriptDir & "\SQL_PurgeClonedpAliases.vbs"
If fso.FileExists(purgeScript) Then
  sh.Run """" & sysCscript & """ //nologo //B """ & purgeScript & """", 0, True
  WScript.Quit 0
End If
LogLine "ERROR: missing SQL_PurgeClonedpAliases.vbs next to " & WScript.ScriptFullName
WScript.Quit 1

' Same file as Alfasteel_Setup.cmd, with the same fallback, so a repair done by
' hand ends up in the log the operator already reads.
Sub LogLine(msg)
  Dim candidates, p, f
  candidates = Array("C:\Alfasteel_Setup_log.txt", _
                     sh.ExpandEnvironmentStrings("%TEMP%") & "\Alfasteel_Setup_log.txt")
  For Each p In candidates
    On Error Resume Next
    Err.Clear
    Set f = fso.OpenTextFile(p, 8, True)
    If Err.Number = 0 Then
      f.WriteLine "[" & Time & "] SQL_FixClient: " & msg
      f.Close
      On Error GoTo 0
      Exit Sub
    End If
    On Error GoTo 0
  Next
End Sub
