# Alfasteel first-boot setup (kit 3.1). SERVER = 8 steps, CLIENT = 6 steps. Single Server.wim for both.
# Launched only via Alfasteel_Setup.cmd (Winlogon shell).

param([string]$ElevatedFlag = '')

$KitRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $KitRoot) { $KitRoot = 'C:\' }
. (Join-Path $KitRoot 'Alfasteel-Lib.ps1')

$LogPath = Initialize-AlfLog
$MarkPath = 'C:\alfasteel.setup.done'
$ActivePath = 'C:\alfasteel.setup.active'
$TriesPath = 'C:\alfasteel.setup.tries'
$MaxTries = 3
$ErrorCount = 0

function Exit-AlfPreflightFailed {
    Remove-Item $ActivePath -Force -ErrorAction SilentlyContinue
    Write-Host ''
    Write-Host 'Preflight failed. Desktop restored. Fix the errors in the log, then reboot or run:'
    Write-Host '  C:\Alfasteel_Setup.cmd'
    Restore-AlfShellAndUac
    Start-Process explorer.exe
    exit 1
}

function Finish-WithErrors {
    param([int]$Errors)
    Remove-Item $ActivePath -Force -ErrorAction SilentlyContinue
    Write-AlfLog -LogPath $LogPath -Message "[ERR] Setup finished with $Errors error(s)."
    $tries = 0
    if (Test-Path $TriesPath) {
        $raw = (Get-Content $TriesPath -Raw).Trim()
        if ($raw -match '^\d+$') { $tries = [int]$raw }
    }
    $tries++
    Set-Content -Path $TriesPath -Value $tries -Encoding ASCII
    if ($tries -ge $MaxTries) {
        Write-Host ''
        Write-Host "ATTENTION: $Errors erreur(s) apres $tries tentatives."
        Write-Host "Log: $LogPath"
        Restore-AlfShellAndUac
        Start-Process explorer.exe
        exit 1
    }
    Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -Name Shell -Value 'cmd.exe /c C:\Alfasteel_Setup.cmd' -Force
    Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name EnableLUA -Value 0 -Type DWord -Force
    Write-Host "Rebooting for attempt $tries of $MaxTries in 20 seconds ..."
    Start-Sleep -Seconds 20
    & shutdown.exe /r /t 5 /c 'Alfasteel setup will retry'
    exit 1
}

function Restore-AlfShellAndUac {
    $shell = 'explorer.exe'
    if (Test-Path 'C:\alfasteel.shell.bak') {
        $shell = (Get-Content 'C:\alfasteel.shell.bak' -Raw).Trim()
    }
    if ($shell -match '^cmd\.exe') { $shell = 'explorer.exe' }
    Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -Name Shell -Value $shell -Force
    Restore-AlfUacOnly
}

# UAC back to image value for the next boot; keep setup shell until we finish (no explorer during run).
Restore-AlfUacOnly
Ensure-AlfSetupShell
Stop-AlfExplorerDesktop

$Mode = 'SERVER'
if (Test-Path 'C:\alfasteel.mode') {
    $Mode = (Get-Content 'C:\alfasteel.mode' -Raw).Trim()
}
if ($Mode -notin @('SERVER', 'CLIENT')) { $Mode = 'SERVER' }

$PcName = $env:COMPUTERNAME
if (Test-Path 'C:\alfasteel.pcname') {
    $PcName = (Get-Content 'C:\alfasteel.pcname' -Raw).Trim()
}
$ReelName = '{0}\REEL' -f $PcName

Write-AlfLog -LogPath $LogPath -Message "=========================================================="
Write-AlfLog -LogPath $LogPath -Message "Alfasteel setup 3.1.2  mode=$Mode  name=$PcName"
if (Test-Path 'C:\kit-version.txt') {
    $kv = (Get-Content 'C:\kit-version.txt' -Raw).Trim()
    Write-AlfLog -LogPath $LogPath -Message "kit-version: $kv"
}
if (Test-Path 'C:\Alfasteel_deploy_info.txt') {
    Get-Content 'C:\Alfasteel_deploy_info.txt' | Add-Content -Path $LogPath
}

Write-Host ''
Write-Host ('=' * 58)
if ($Mode -eq 'CLIENT') {
    Write-Host '  CLIENT  -  Alfasteel  6 etapes / 6 steps'
    Write-Host '  Connexion / logon: utilisateur alfasteel (pas pc-com)'
} else {
    Write-Host '  SERVEUR / SERVER  -  Alfasteel  8 etapes / 8 steps'
}
Write-Host "  PC: $PcName    mode=$Mode"
Write-Host "  Log: $LogPath"
Write-Host ('=' * 58)

if (-not (Test-AlfIsAdmin)) {
    if ($ElevatedFlag -ne 'ELEVATED') {
        Write-AlfLog -LogPath $LogPath -Message 'Restarting elevated ...'
        Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', 'C:\Alfasteel_Setup.cmd', 'ELEVATED' -Verb RunAs -Wait
        exit 0
    }
    Write-AlfLog -LogPath $LogPath -Message '[ERR] Administrator rights are required but elevation did not succeed.'
    Exit-AlfPreflightFailed
}

if (Test-Path $MarkPath) {
    Write-AlfLog -LogPath $LogPath -Message 'Setup already completed.'
    Start-Process explorer.exe
    exit 0
}

if (-not (Clear-AlfStaleSetupLock -ActivePath $ActivePath -LogPath $LogPath)) {
    Restore-AlfShellAndUac
    exit 1
}
Set-Content -Path $ActivePath -Value ((Get-Date).ToString('o')) -Encoding ASCII

if (-not (Test-AlfNetBiosName -Name $PcName -LogPath $LogPath -Label 'PC name')) {
    Exit-AlfPreflightFailed
}
if ($Mode -eq 'CLIENT' -and (Test-Path 'C:\alfasteel.sqlserver')) {
    $sqlSrv = (Get-Content 'C:\alfasteel.sqlserver' -Raw).Trim()
    if ($sqlSrv -and -not (Test-AlfNetBiosName -Name $sqlSrv -LogPath $LogPath -Label 'SQL server name')) {
        Exit-AlfPreflightFailed
    }
}
if (-not (Test-AlfSetupPreflight -LogPath $LogPath -Mode $Mode)) {
    Exit-AlfPreflightFailed
}

Remove-Item 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce\AlfasteelSetup' -Force -ErrorAction SilentlyContinue

try {
    if ($Mode -eq 'CLIENT') {
        Invoke-AlfClientSetup -LogPath $LogPath -ErrorCount ([ref]$ErrorCount)
    } else {
        Invoke-AlfServerSetup -LogPath $LogPath -PcName $PcName -ReelName $ReelName -ErrorCount ([ref]$ErrorCount)
    }
} catch {
    Write-AlfLog -LogPath $LogPath -Message "[ERR] $($_.Exception.Message)"
    $ErrorCount++
}

Remove-Item $ActivePath -Force -ErrorAction SilentlyContinue

if ($ErrorCount -gt 0) {
    if ($Mode -eq 'SERVER' -and (Test-AlfServerReconcile -LogPath $LogPath -PcName $PcName -ReelName $ReelName)) {
        $ErrorCount = 0
    }
    if ($Mode -eq 'CLIENT' -and (Test-AlfClientReconcile -LogPath $LogPath)) {
        $ErrorCount = 0
    }
}

if ($ErrorCount -gt 0) {
    Finish-WithErrors -Errors $ErrorCount
}

Write-AlfLog -LogPath $LogPath -Message 'Setup finished with no errors.'
Set-Content -Path $MarkPath -Value ((Get-Date).ToString()) -Encoding ASCII
Restore-AlfShellAndUac
Remove-Item 'C:\alfasteel.pcname', 'C:\alfasteel.mode', 'C:\alfasteel.client.pw', 'C:\alfasteel.retire.users', 'C:\alfasteel.shell.bak', 'C:\alfasteel.sqlserver', 'C:\alfasteel.uac.bak', $TriesPath -Force -ErrorAction SilentlyContinue
@(
    'C:\SQL_PurgeClonedpAliases.vbs', 'C:\SQL_EmReset.vbs', 'C:\Set_OasysPrefs.vbs',
    'C:\SQL_WipeEmServers.vbs', 'C:\Alfasteel_Client_FirstBoot.vbs', 'C:\alfclientfb.vbs'
) | ForEach-Object { Remove-Item $_ -Force -ErrorAction SilentlyContinue }

Write-Host 'Setup complete. Rebooting in 15 seconds ...'
Start-Sleep -Seconds 15
& shutdown.exe /r /t 5 /c 'Alfasteel setup complete'
exit 0

function Invoke-AlfServerSetup {
    param($LogPath, $PcName, $ReelName, [ref]$ErrorCount)
    $svcDef = 'MSSQLSERVER'
    $svcReel = 'MSSQL$REEL'
    $svcDefAg = 'SQLSERVERAGENT'
    $svcReelAg = 'SQLAgent$REEL'

    Write-AlfStep -LogPath $LogPath -Title '1/8 Waiting for the SQL Server services to start'
    try { Start-AlfService -LogPath $LogPath -ServiceName $svcDef } catch { $ErrorCount.Value++ }
    try { Start-AlfService -LogPath $LogPath -ServiceName $svcReel } catch { $ErrorCount.Value++ }

    Write-AlfStep -LogPath $LogPath -Title "2/8 Renaming the default instance to $PcName"
    if (-not (Invoke-AlfRenameInstance -LogPath $LogPath -ServerInstance '' -NewName $PcName)) { $ErrorCount.Value++ }

    Write-AlfStep -LogPath $LogPath -Title "3/8 Renaming the REEL instance to $ReelName"
    $st = Get-AlfServiceState -ServiceName $svcReel
    if ($st -ne 'RUNNING') {
        Write-AlfLog -LogPath $LogPath -Message "[ERR] $svcReel is $st - cannot rename REEL."
        $ErrorCount.Value++
    } elseif (-not (Invoke-AlfRenameInstance -LogPath $LogPath -ServerInstance '.\REEL' -NewName $ReelName)) {
        $ErrorCount.Value++
    }

    Write-AlfStep -LogPath $LogPath -Title '4/8 Restarting both instances so the new names take effect'
    try { Restart-AlfSqlInstance -LogPath $LogPath -SqlService $svcReel -AgentService $svcReelAg } catch { $ErrorCount.Value++ }
    try { Restart-AlfSqlInstance -LogPath $LogPath -SqlService $svcDef -AgentService $svcDefAg } catch { $ErrorCount.Value++ }

    Write-AlfStep -LogPath $LogPath -Title '5/8 Removing CLONEDP client aliases'
    if (-not (Invoke-AlfCscript -LogPath $LogPath -ScriptPath 'C:\SQL_PurgeClonedpAliases.vbs' -TimeoutSeconds 240)) { $ErrorCount.Value++ }

    Write-AlfStep -LogPath $LogPath -Title '6/8 Rebuilding Enterprise Manager and breaking the CLONEDP name cache'
    if (-not (Invoke-AlfCscript -LogPath $LogPath -ScriptPath 'C:\SQL_EmReset.vbs' -TimeoutSeconds 900)) { $ErrorCount.Value++ }

    Write-AlfStep -LogPath $LogPath -Title "7/8 Pointing Desktop\oasys\prefs.ini at $PcName"
    if (-not (Invoke-AlfCscript -LogPath $LogPath -ScriptPath 'C:\Set_OasysPrefs.vbs' -TimeoutSeconds 180)) { $ErrorCount.Value++ }

    Write-AlfStep -LogPath $LogPath -Title '8/8 Verifying the instance names'
    if (-not (Test-AlfServerName -LogPath $LogPath -ServerInstance '' -ExpectedName $PcName)) { $ErrorCount.Value++ }
    if (-not (Test-AlfServerName -LogPath $LogPath -ServerInstance '.\REEL' -ExpectedName $ReelName)) { $ErrorCount.Value++ }
    if (-not (Test-AlfNoClonedpIni -LogPath $LogPath)) { $ErrorCount.Value++ }
    Grant-AlfSqlAdmins -LogPath $LogPath -ServerInstance ''
    Grant-AlfSqlAdmins -LogPath $LogPath -ServerInstance '.\REEL'
}

function Invoke-AlfClientSetup {
    param($LogPath, [ref]$ErrorCount)
    Stop-AlfExplorerDesktop
    $svcDef = 'MSSQLSERVER'
    $svcReel = 'MSSQL$REEL'
    $svcDefAg = 'SQLSERVERAGENT'
    $svcReelAg = 'SQLAgent$REEL'

    Write-AlfStep -LogPath $LogPath -Title '1/6 Making sure no local SQL service is running'
    Stop-AlfService -LogPath $LogPath -ServiceName $svcDefAg -MaxSeconds 90
    Stop-AlfService -LogPath $LogPath -ServiceName $svcReelAg -MaxSeconds 90
    Stop-AlfService -LogPath $LogPath -ServiceName $svcDef -MaxSeconds 90
    Stop-AlfService -LogPath $LogPath -ServiceName $svcReel -MaxSeconds 90
    Stop-AlfService -LogPath $LogPath -ServiceName 'SQLBrowser' -MaxSeconds 90

    Write-AlfStep -LogPath $LogPath -Title '2/6 Creating the local user and clearing Enterprise Manager'
    $clientVbs = 'C:\alfclientfb.vbs'
    if (-not (Test-Path $clientVbs)) { $clientVbs = 'C:\Alfasteel_Client_FirstBoot.vbs' }
    if (-not (Invoke-AlfCscript -LogPath $LogPath -ScriptPath $clientVbs -TimeoutSeconds 600)) { $ErrorCount.Value++ }

    Write-AlfStep -LogPath $LogPath -Title '3/6 Removing CLONEDP client aliases'
    if (-not (Invoke-AlfCscript -LogPath $LogPath -ScriptPath 'C:\SQL_PurgeClonedpAliases.vbs' -TimeoutSeconds 240)) { $ErrorCount.Value++ }

    Write-AlfStep -LogPath $LogPath -Title '4/6 Flushing the name caches'
    Flush-AlfNetworkCaches -LogPath $LogPath

    Write-AlfStep -LogPath $LogPath -Title '5/6 Pointing Desktop\oasys\prefs.ini at the SQL server'
    if (-not (Invoke-AlfCscript -LogPath $LogPath -ScriptPath 'C:\Set_OasysPrefs.vbs' -TimeoutSeconds 180)) { $ErrorCount.Value++ }

    Write-AlfStep -LogPath $LogPath -Title '6/6 Verifying the workstation'
    $nu = & net.exe user alfasteel 2>&1
    $nu | Add-Content -Path $LogPath
    if ($LASTEXITCODE -ne 0) {
        Write-AlfLog -LogPath $LogPath -Message '[ERR] local user alfasteel does not exist.'
        $ErrorCount.Value++
    }
    foreach ($s in @($svcDef, $svcReel)) {
        $st = Get-AlfServiceState -ServiceName $s
        if ($st -eq 'RUNNING') {
            Write-AlfLog -LogPath $LogPath -Message "[ERR] $s is still running on a client."
            $ErrorCount.Value++
        }
    }
    if (-not (Test-AlfNoClonedpIni -LogPath $LogPath)) { $ErrorCount.Value++ }
}

function Test-AlfServerReconcile {
    param($LogPath, $PcName, $ReelName)
    if ((Test-AlfServerName -LogPath $LogPath -ServerInstance '' -ExpectedName $PcName) -and
        (Test-AlfServerName -LogPath $LogPath -ServerInstance '.\REEL' -ExpectedName $ReelName)) {
        Write-AlfLog -LogPath $LogPath -Message '[WARN] Clearing error count: both SQL instances report expected names.'
        return $true
    }
    return $false
}

function Test-AlfClientReconcile {
    param($LogPath)
    $userOk = $false
    & net.exe user alfasteel 2>&1 | Out-Null
    if ($LASTEXITCODE -eq 0) { $userOk = $true }
    $sqlOk = (Get-AlfServiceState -ServiceName 'MSSQLSERVER') -ne 'RUNNING' -and
             (Get-AlfServiceState -ServiceName 'MSSQL$REEL') -ne 'RUNNING'
    if ($userOk -and $sqlOk) {
        Write-AlfLog -LogPath $LogPath -Message '[WARN] Clearing error count: client checks passed.'
        return $true
    }
    return $false
}
