@echo off
@echo off
:: The line above is duplicated on purpose: if this file is ever re-saved with a
:: UTF-8 BOM, cmd.exe swallows the first line and echo would stay on.
setlocal
:: One-time golden-image prep. Run from an elevated Command Prompt
:: on the reference PC BEFORE capture. Grants sysadmin to the localized
:: BUILTIN Administrators group (SID S-1-5-32-544) on both SQL instances.

for /f "delims=" %%I in ('powershell -NoProfile -Command "([System.Security.Principal.SecurityIdentifier]'S-1-5-32-544').Translate([System.Security.Principal.NTAccount]).Value"') do set "SQL_LOGIN=%%I"

if not defined SQL_LOGIN (
  echo [ERR] Could not resolve BUILTIN\Administrators group.
  exit /b 1
)

echo [*] Using login: %SQL_LOGIN%

osql -E -Q "EXEC sp_grantlogin '%SQL_LOGIN%'; EXEC sp_addsrvrolemember '%SQL_LOGIN%', 'sysadmin';"
if errorlevel 1 exit /b 1

osql -E -S .\REEL -Q "EXEC sp_grantlogin '%SQL_LOGIN%'; EXEC sp_addsrvrolemember '%SQL_LOGIN%', 'sysadmin';"
if errorlevel 1 exit /b 1

osql -E -Q "EXEC sp_helpsrvrolemember 'sysadmin'"
osql -E -S .\REEL -Q "EXEC sp_helpsrvrolemember 'sysadmin'"

endlocal
exit /b 0
