@echo off
@echo off
:: The line above is duplicated on purpose: if this file is ever re-saved with a
:: UTF-8 BOM, cmd.exe swallows the first line and echo would stay on.
setlocal enabledelayedexpansion
:: Capture the golden OS from WinPE onto this USB (same drive as this script).
:: Usage: E:\capture-image.bat Server
::    or: E:\capture-image.bat Client
::
:: Do NOT assume C: is the OS. This script finds \Windows\System32\config\SYSTEM
:: and writes Server.wim or Client.wim next to this .bat.

set "KIND=%~1"
if /i "%KIND%"=="" set "KIND=Server"
if /i not "%KIND%"=="Server" if /i not "%KIND%"=="Client" (
  echo [ERR] Usage: %~nx0 Server
  echo           %~nx0 Client
  exit /b 1
)

set "DEPLOY_VOL=%~d0"
if /i "%DEPLOY_VOL%"=="X:" (
  echo [ERR] Run from the Ventoy data drive, not X:
  exit /b 1
)
if not "%DEPLOY_VOL:~-1%"=="\" set "DEPLOY_VOL=%DEPLOY_VOL%\"
set "USB_VOL=%DEPLOY_VOL:~0,2%"
set "WIM_FILE=%KIND%.wim"
set "OS_DIR="
set /a OS_CANDIDATES=0

echo [*] Looking for Windows install to capture...
for %%L in (C D E F G H I J K L M N O P Q R S T U V W Y Z) do (
  if /i not "%%L:"=="%USB_VOL%" if /i not "%%L:"=="X:" (
    if exist "%%L:\Windows\System32\config\SYSTEM" if exist "%%L:\Windows\System32\winload.exe" (
      set /a OS_CANDIDATES+=1
      set "OS_DIR=%%L:\"
      set "OS_LAST=%%L:"
    )
  )
)

if !OS_CANDIDATES! gtr 1 (
  echo [ERR] Found !OS_CANDIDATES! Windows installs. Unplug extra drives or specify the source letter.
  echo     Last match was !OS_LAST! - fix the loop in capture-image.bat if you need manual pick.
  exit /b 1
)

if not defined OS_DIR (
  echo [ERR] No offline Windows install found.
  echo     Skip the USB volume and X:, look for \Windows\System32\config\SYSTEM.
  exit /b 1
)

echo [*] Capture source: %OS_DIR%
echo [*] Output WIM:     %DEPLOY_VOL%%WIM_FILE%
echo [*] Compression:    fast  ^(use max only if you need a smaller file^)
echo.
pause

dism /Capture-Image /ImageFile:"%DEPLOY_VOL%%WIM_FILE%" /CaptureDir:%OS_DIR% /Name:"%KIND% OS" /Compress:fast /CheckIntegrity
if errorlevel 1 (
  echo [ERR] Capture failed.
  exit /b 1
)

echo.
echo [*] Capture complete: %DEPLOY_VOL%%WIM_FILE%
dir "%DEPLOY_VOL%%WIM_FILE%"
endlocal
exit /b 0
