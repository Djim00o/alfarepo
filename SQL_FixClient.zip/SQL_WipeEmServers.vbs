' Remove all Enterprise Manager / SQL Service Manager registrations (no servers added).
' Use on CLIENT PCs that only connect to a remote SQL server.
'
' The whole SQLEW tree is deleted in both registry views so Enterprise Manager
' starts blank. New profiles inherit the already-wiped Default hive, which
' deploy.bat cleaned offline in WinPE.

Option Explicit

Dim fso, sh, sysRoot, wowCscript, logPath, app, grp, i, n, purgeScript

Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
sysRoot = sh.ExpandEnvironmentStrings("%SystemRoot%")
wowCscript = sysRoot & "\SysWOW64\cscript.exe"

On Error Resume Next

If fso.FileExists(wowCscript) Then
  If InStr(LCase(WScript.FullName), "\system32\cscript.exe") > 0 Then
    sh.Run """" & wowCscript & """ //nologo //B """ & WScript.ScriptFullName & """", 0, True
    WScript.Quit 0
  End If
End If

logPath = ChooseLogPath()
LogLine "start"

purgeScript = fso.GetParentFolderName(WScript.ScriptFullName) & "\SQL_PurgeClonedpAliases.vbs"
If fso.FileExists(purgeScript) Then
  sh.Run "cscript //nologo //B """ & purgeScript & """", 0, True
  LogLine "ran SQL_PurgeClonedpAliases.vbs"
End If

LogLine "deleting the whole Enterprise Manager tree (both registry views)"
sh.Run "%ComSpec% /c reg delete ""HKCU\Software\Microsoft\MSSQLServer\SQLEW"" /f /reg:32", 0, True
sh.Run "%ComSpec% /c reg delete ""HKCU\Software\Microsoft\MSSQLServer\SQLEW"" /f /reg:64", 0, True

' Belt and braces: SQLDMO drops anything Enterprise Manager still holds open.
Set app = CreateObject("SQLDMO.Application")
If Err.Number = 0 Then
  For Each grp In app.ServerGroups
    i = grp.RegisteredServers.Count
    Do While i >= 1
      n = grp.RegisteredServers.Item(i).Name
      LogLine "SQLDMO remove: " & n
      grp.RegisteredServers.Remove n
      i = i - 1
    Loop
  Next
End If
Err.Clear

LogLine "done (no local servers registered)"
WScript.Quit 0


' --- SUBROUTINES ---

Function ChooseLogPath()
  Dim candidates, p, probe
  candidates = Array("C:\Alfasteel_Setup_log.txt", _
                     sh.ExpandEnvironmentStrings("%TEMP%") & "\Alfasteel_Setup_log.txt")
  For Each p In candidates
    Err.Clear
    Set probe = fso.OpenTextFile(p, 8, True)
    If Err.Number = 0 Then
      probe.Close
      ChooseLogPath = p
      Exit Function
    End If
  Next
  ChooseLogPath = ""
End Function

Sub LogLine(msg)
  Dim f
  On Error Resume Next
  If logPath = "" Then Exit Sub
  Set f = fso.OpenTextFile(logPath, 8, True)
  If Err.Number <> 0 Then Exit Sub
  f.WriteLine "[" & Time & "] WipeEmServers: " & msg
  f.Close
End Sub
